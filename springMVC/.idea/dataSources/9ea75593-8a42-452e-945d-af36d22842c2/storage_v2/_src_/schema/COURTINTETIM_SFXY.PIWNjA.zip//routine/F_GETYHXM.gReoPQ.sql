create FUNCTION                   F_GETYHXM(nScFy number,nYhDm number) return varchar2 is
  strMC nvarchar2(200);
  /*获取用户姓名 杨元胜*/
begin
  SELECT YHXM INTO strMC FROM B_YHDM  WHERE SCFY=nScFy AND YHDM = nYhDm;
  RETURN strMC;
end;

/

