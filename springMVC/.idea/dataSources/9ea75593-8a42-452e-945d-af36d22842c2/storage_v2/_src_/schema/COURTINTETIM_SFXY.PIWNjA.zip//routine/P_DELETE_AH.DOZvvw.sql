create procedure P_DELETE_AH(v_ajbs in number := 16 --案件标识
                                     ) as
begin
  declare
    cursor cur_a is
      SELECT TABLE_NAME
        FROM CAT
       WHERE TABLE_TYPE = 'TABLE'
         AND TABLE_NAME NOT LIKE '%_JB' AND TABLE_NAME <>'B_AJSCJL'
         AND TABLE_NAME IN (SELECT TABLE_NAME
                              FROM USER_TAB_COLS
                             WHERE COLUMN_NAME = 'AJBS');
  begin
    for line_a in cur_a loop
      -- dbms_output.put_line( 'DELETE FROM '||line_a.TABLE_NAME||' WHERE AJBS='||v_ajbs);
      execute immediate 'DELETE FROM ' || line_a.TABLE_NAME ||
                        ' WHERE AJBS=' || v_ajbs;
    end loop;
    COMMIT;
  end;
end P_DELETE_AH;
/

