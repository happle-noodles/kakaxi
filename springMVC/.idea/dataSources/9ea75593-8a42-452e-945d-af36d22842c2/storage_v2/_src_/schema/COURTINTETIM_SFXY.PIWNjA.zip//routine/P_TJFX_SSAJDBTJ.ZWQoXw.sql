create PROCEDURE P_TJFX_SSAJDBTJ(fytj varchar2,jnsjqj varchar2,qnsjqj varchar2, rt out pkg_row.myRow) as
/*月结案情况 杨元胜
fytj 查询法院
jnsjqj 今年时间区间
qnsjqj 去年时间区间
rt   返回数据集
*/
v_scfy varchar2(200);
BEGIN
 v_scfy:='B_TJHZ.cjfy=b_fy.dm and b_fy.dm between 4166 and 4208 and '|| fytj;

insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'刑事申诉案件',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'民事申诉案件',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'行政申诉案件',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'赔偿申诉案件',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'执行申诉案件',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'总计',-1,0,0 from dual;

--今年刑事案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=23 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''刑事申诉案件'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS';

--去年刑事案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=23 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''刑事申诉案件'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS';

--今年民事案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=24 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''民事申诉案件'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS';

--去年民事案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=24 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''民事申诉案件'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS';

--今年行政案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=25 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''行政申诉案件'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS';

--去年行政案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=25 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''行政申诉案件'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS';

--今年赔偿案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=27 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''赔偿申诉案件'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS';

--去年赔偿案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=27 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''赔偿申诉案件'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS';

--今年执行案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=26 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''执行申诉案件'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS';

--去年执行案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=26 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''执行申诉案件'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS';

--今年总计
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB BETWEEN 23 and 27 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''总计'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS';
--去年总计
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB BETWEEN 23 and 27 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''总计'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS';

    update b_tempaytj set jnjal= round(100*jnyj/jnsls,2) where jnsls>0;
    update b_tempaytj set qnjal= round(100*qnyj/qnsls,2) where qnsls>0;

  -- open rt for select * from b_tempaytj;
   open rt for select * from b_tempaytj WHERE (JNSLS>0 OR QNSLS>0);
END P_TJFX_SSAJDBTJ;

/

