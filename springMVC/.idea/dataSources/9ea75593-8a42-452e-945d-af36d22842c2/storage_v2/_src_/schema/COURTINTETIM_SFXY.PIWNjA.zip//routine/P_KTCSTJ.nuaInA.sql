create procedure P_KTCSTJ(strscfy number,strksrq varchar2,strjsrq varchar2,rt out pkg_row.myRow )
as

xs_ktcs number;
xs_ktajs number;

ms_ktcs number;
ms_ktajs number;

xz_ktcs number;
xz_ktajs number;

hj_ktcs number;
hj_ktajs number;

begin


select count(*) as ktcs into xs_ktcs from b_Ftsyjl  where ftyt=1 and kplb in(1,2,3) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd');
select count (*) ktajs into xs_ktajs from (select count(*) as ktcs from b_Ftsyjl where ftyt=1 and kplb in(1,2,3) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd')group by ajbs) a;
insert into B_TEMPTJFX (kplb,xs,jc) values(0001,xs_ktcs,xs_ktajs);

select count(*) as ktcs into ms_ktcs from b_Ftsyjl  where ftyt=1 and kplb in(7,8,9) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd');
select count (*) ktajs into ms_ktajs from (select count(*) as ktcs from b_Ftsyjl where ftyt=1 and kplb in(7,8,9) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd')group by ajbs) a;
insert into B_TEMPTJFX (kplb,xs,jc) values(0002,ms_ktcs,ms_ktajs);

select count(*) as ktcs into xz_ktcs from b_Ftsyjl  where ftyt=1 and kplb in(13,14,15) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd');
select count (*) ktajs into xz_ktajs from (select count(*) as ktcs from b_Ftsyjl where ftyt=1 and kplb in(13,14,15) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd')group by ajbs) a;
insert into B_TEMPTJFX (kplb,xs,jc) values(0003,xz_ktcs,xz_ktajs);

select count(*) as ktcs into hj_ktcs from b_Ftsyjl  where ftyt=1 and kplb in(1,2,3,7,8,9,13,14,15) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd');
select count (*) ktajs into hj_ktajs from (select count(*) as ktcs from b_Ftsyjl where ftyt=1 and kplb in(1,2,3,7,8,9,13,14,15) and scfy=strScfy and pqrq between to_date(strksrq,'yyyy-mm-dd') and to_date(strjsrq,'yyyy-mm-dd')group by ajbs) a;
insert into B_TEMPTJFX (kplb,xs,jc) values(0004,hj_ktcs,hj_ktajs);

open rt for select kplb,xs,jc from B_TEMPTJFX;
end P_KTCSTJ;
/

