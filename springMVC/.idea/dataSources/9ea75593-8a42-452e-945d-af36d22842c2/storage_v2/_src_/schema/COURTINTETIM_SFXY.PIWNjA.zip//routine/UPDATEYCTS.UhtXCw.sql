create procedure UPDATEYCTS(nAjbs in number:=16) is
/*计算延长天数天数 欧伟*/
begin
   UPDATE  B_AJZTXX m SET YCTS=(SELECT trunc(SUM(A.YCQJ)) AS YCTS from  B_YCSXJL  A where AJBS=nAjbs and nvl(m.sxqsrq,m.larq)<a.pzrq) WHERE AJBS=nAjbs;
end UPDATEYCTS;

/

