create PROCEDURE AyTjHz (qsrq VARCHAR2,jsrq VARCHAR2,sjqj VARCHAR2) AS
/*兵团分院管辖法院案由统计汇总 刘帅
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
*/
v_xstj VARCHAR2(200);
v_jctj varchar2(200);
v_yjtj varchar2(200);
v_qjz VARCHAR2(100);
v_cxtj varchar2(500);
BEGIN
 v_qjz:=sjqj||'#'||qsrq||' 至 '||jsrq;
 select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
 select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
 select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';

 v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
 v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
 v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
 v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
 v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
 v_cxtj :='A.SCFY=B_AYTJHZ.CJFY AND A.FZKPLB=B_AYTJHZ.KPLB AND nvl(A.LAAY,-1)=B_AYTJHZ.LAAY';

 execute immediate 'DELETE FROM B_AYTJHZ WHERE SJQJ like ''%'||sjqj||'%''';
 --插入时间区间及案由

 execute immediate 'INSERT INTO B_AYTJHZ (SJQJ,CJFY,KPLB,LAAY,AYMC) SELECT '''||v_qjz||''' as SJQJ,SCFY,
  FZKPLB,nvl(LAAY,-1) AS LAAY,NVL((SELECT AYNR FROM B_AY WHERE B_AY.AYDM=B_AJZTXX.LAAY),''其他'') AS AYMC FROM B_AJZTXX WHERE KPLB IN (1,2,3,4,7,8,9,13,14,15,16,17,18) AND
  ('||v_xstj||' or '||v_jctj||') GROUP BY SCFY,FZKPLB,LAAY';

  --受理数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS SLS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE ('||v_xstj||' or '||v_jctj||') GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.SLS=A.SLS where B_AYTJHZ.SJQJ='''||v_qjz||'''';

 --新收数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS XSS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_xstj||' GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.XSS=A.XSS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --旧存数

 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS JCS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_jctj||' GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.JCS=A.JCS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --已结数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS YJS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.YJS=A.YJS where B_AYTJHZ.SJQJ='''||v_qjz||'''';

 --一审判决数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS YSPJS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND (FZKPLB IN (1,7,13) AND JAFS=1) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.YSPJS=A.YSPJS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --维持数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS WCS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND (FZKPLB IN (2,3,8,9,14,15) AND JAFS=1) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.WCS=A.WCS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --改判数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS GPS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND (FZKPLB IN (2,3,8,9,14,15) AND JAFS=2) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.GPS=A.GPS where B_AYTJHZ.SJQJ='''||v_qjz||'''';

 --发回重审数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS FHCSS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND (B_AJZTXX.FZKPLB IN (2,3,8,9,14,15) AND B_AJZTXX.JAFS=3) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.FHCSS=A.FHCSS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --撤诉数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS CSS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((B_AJZTXX.FZKPLB=1 AND JAFS in(4,5,9))or (B_AJZTXX.FZKPLB=2 AND JAFS in(5,6,112,107,108,109,110)) or (B_AJZTXX.FZKPLB=3 AND JAFS in(5,6,107,108,109,110,113,116,117)) OR (B_AJZTXX.FZKPLB in(7,13) AND JAFS in(4,5)) OR (B_AJZTXX.FZKPLB =8 AND JAFS in(6,7,110)) OR (B_AJZTXX.FZKPLB =9 AND JAFS in(6,7,106)) OR (B_AJZTXX.FZKPLB in (14,15) AND JAFS in(6,7)))
 GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.CSS=A.CSS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --调解数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS TJS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((B_AJZTXX.FZKPLB IN (1,7,13) AND B_AJZTXX.JAFS=7) OR (B_AJZTXX.FZKPLB IN (2,3) AND B_AJZTXX.JAFS=8) OR (B_AJZTXX.FZKPLB IN (8,9,14,15) AND B_AJZTXX.JAFS=9)) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.TJS=A.TJS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --驳回数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS BHS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((B_AJZTXX.FZKPLB=1 AND B_AJZTXX.JAFS IN (3,12,13)) OR (B_AJZTXX.FZKPLB IN (7,13) AND B_AJZTXX.JAFS=3) OR (B_AJZTXX.FZKPLB IN (8,9,14,15) AND B_AJZTXX.JAFS=5)) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.BHS=A.BHS where B_AYTJHZ.SJQJ='''||v_qjz||'''';
 --其他数
 execute immediate 'merge into B_AYTJHZ
  using (SELECT COUNT(*) AS QTS,FZKPLB,SCFY,LAAY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((B_AJZTXX.FZKPLB=1 AND B_AJZTXX.JAFS IN (NULL,2,6,8,9,10,11,14,15,16,17,18,19,20,21,22,23,24,255)) OR (B_AJZTXX.FZKPLB IN (2,3) AND B_AJZTXX.JAFS IN (NULL,4,7,9,255))
  OR (B_AJZTXX.FZKPLB IN (7,13) AND B_AJZTXX.JAFS IN (NULL,2,6,8,255)) OR (B_AJZTXX.FZKPLB IN (8,9,14,15) AND B_AJZTXX.JAFS IN (NULL,4,8,10,255))) GROUP BY SCFY,FZKPLB,LAAY) A
  ON ('||v_cxtj||') when matched then update set B_AYTJHZ.QTS=A.QTS where B_AYTJHZ.SJQJ='''||v_qjz||'''';

END AyTjHz;
/

