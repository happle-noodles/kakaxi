create PROCEDURE GuiDangXinXiTongJi(nscfy number,qsrq varchar2,jsrq varchar2,ntsdm number,rt out pkg_row.myRow) as
v_yjtj varchar2(200);
v_kplb varchar2(100);
v_scfy varchar2(200);
begin
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
  v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
  v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
  v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);

  if ntsdm>4165 then
    execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) SELECT TSDM,TSMC FROM B_TSDM WHERE '||v_scfy||' ORDER BY TSDM,XSSX';
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.CBSPT)B
    ON(A.DM=B.CBSPT) when matched then update set A.YJ=B.SL';--部门应归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NOT NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.DM=B.CBSPT) when matched then update set A.XS=B.SL';--部门已归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.DM=B.CBSPT) when matched then update set A.JC=B.SL';--部门未归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL and months_between(sysdate,JARQ)>=1 GROUP BY B_AJZTXX.CBSPT)B
    ON(A.DM=B.CBSPT) when matched then update set A.XSYJ=B.SL';--部门超期一月未归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL and months_between(sysdate,JARQ)>=2 GROUP BY B_AJZTXX.CBSPT)B
    ON(A.DM=B.CBSPT) when matched then update set A.XSWJ=B.SL';--部门超期二月未归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL and months_between(sysdate,JARQ)>=3 GROUP BY B_AJZTXX.CBSPT)B
    ON(A.DM=B.CBSPT) when matched then update set A.JCYJ=B.SL';--部门超期三月未归档
  else
    execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) SELECT YHDM,YHXM FROM B_YHDM WHERE '||v_scfy||' AND TSDM='||ntsdm||'  ORDER BY XSSX';
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.YJ=B.SL';--人员应归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NOT NULL GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.XS=B.SL';--人员已应归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.JC=B.SL';--人员未应归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL and months_between(sysdate,JARQ)>=1 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.XSYJ=B.SL';--人员超期一月未归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL and months_between(sysdate,JARQ)>=2 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.XSWJ=B.SL';--人员超期二月未归档
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NULL and months_between(sysdate,JARQ)>=3 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.JCYJ=B.SL';--人员超期三月未归档
  end if;
  INSERT INTO B_TEMPTJFX(DM,MC) values(-1,'合计');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT SUM(YJ) AS YJ,SUM(XS)AS XS,SUM(JC) AS JC,SUM(XSYJ)AS XSYJ,SUM(XSWJ)AS XSWJ,SUM(JCYJ)AS JCYJ FROM B_TEMPTJFX)B
    ON(A.DM=-1) when matched then update set A.YJ=B.YJ,A.XS=B.XS,A.JC=B.JC,A.XSYJ=B.XSYJ,A.XSWJ=B.XSWJ,A.JCYJ=B.JCYJ';--人员应归档

    open rt for SELECT * FROM  B_TEMPTJFX where YJ>0 OR XS>0 OR JC>0 OR XSYJ>0 OR XSWJ>0 OR JCYJ>0;
end;
/

