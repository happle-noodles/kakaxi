create view V_PC_BB_AJXX as
  select AJBS,KPLB,AJLB,AH,to_char(LARQ,'yyyy"年"MM"月"dd"日"')LARQ,to_char(JARQ,'yyyy"年"MM"月"dd"日"')JARQ,(select AYNR from B_AY where AYDM=B_AJZTXX.LAAY)LAAY,to_char((select SDSZRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')SDSQRQ,
(select MC from B_DM where BH=(CASE AJLB WHEN 1 THEN 'GF2009-07204' WHEN 2 THEN 'GF2009-07302' END) AND DM=B_AJZTXX.AJLY)AJLY,(select MC from B_DM where BH='GF2009-02001' AND DM=B_AJZTXX.AJSJ)AJSJ,(select MC from B_DM where BH='GF2009-02075' AND DM=B_AJZTXX.GXYJ)GXYJ,
(select MC from B_DM where BH='GF2009-07206' AND DM=B_AJZTXX.SCYJ)SCYJ,(select MC from B_DM where BH='GF2009-07206' AND DM=B_AJZTXX.SPYJ)SPYJ,(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SCR AND SCFY=B_AJZTXX.SCFY)SCR,to_char(SCRQ,'yyyy"年"MM"月"dd"日"')SCRQ,
(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SPR AND SCFY=B_AJZTXX.SCFY)SPR,to_char(LASPRQ,'yyyy"年"MM"月"dd"日"')SPRQ,(select LABZ from B_AJFZXX where AJBS=B_AJZTXX.AJBS)LABZ,(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SADJR AND SCFY=B_AJZTXX.SCFY)LAR,
(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SPR AND SCFY=B_AJZTXX.SCFY)LATTZ,(select to_char(SDCLRQ,'yyyy"年"MM"月"dd"日"') from B_AJFZXX where AJBS=B_AJZTXX.AJBS)SDCLRQ,
(select (select MC from B_DM where BH='GF2009-07305' AND DM=B_AJFZXX.QQPCLX) from B_AJFZXX where AJBS=B_AJZTXX.AJBS)QQPCLX,JDPCJE/10000 AS JDPCJE,
(select to_char(LAYJRQ,'yyyy"年"MM"月"dd"日"') from B_LAYJHTAQK where SFBZ=(select MAX(SFBZ) from B_LAYJHTAQK where  AJBS=B_AJZTXX.AJBS))YJSPTRQ,(select TSMC from B_TSDM where TSDM=B_AJZTXX.CBSPT AND SCFY=B_AJZTXX.SCFY)CBSPT,(select YHXM from B_YHDM where YHDM=B_AJZTXX.CBR AND SCFY=B_AJZTXX.SCFY)JSR,
(select (select YHXM from B_YHDM where YHDM=B_SPZZCY.YCY and SCFY=B_AJZTXX.SCFY)SPY from B_SPZZCY where SFBZ=(select MAX(SFBZ) from B_SPZZCY where JS=3 AND AJBS=B_AJZTXX.AJBS))SPZ,(select YHXM from B_YHDM where YHDM=B_AJZTXX.CBR AND SCFY=B_AJZTXX.SCFY)CBR,(SELECT WMSYS.WM_CONCAT((SELECT YHXM FROM B_YHDM WHERE SCFY=B_AJZTXX.SCFY AND YHDM=B_SPZZCY.YCY)) FROM B_SPZZCY WHERE AJBS=B_AJZTXX.AJBS AND JS IN(3,4,5,6,7) AND YCY<>B_AJZTXX.CBR) AS HYTQTCY,SJYMC AS SJY,
FDSXTS,SJSLTS AS SLTS,(SELECT MC FROM B_DM where BH='GF2009-01048' AND DM=B_AJZTXX.CSXYY)CSXYY,CSXTS,to_char((select CBRBPRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')CBRBPRQ,to_char((select SPZSQRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')SPZSQRQ,to_char((select TZSQRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')TZSQRQ,
to_char((select YZSQRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')YZSQRQ,
--(select to_char(TLRQ,'yyyy"年"MM"月"dd"日"') AS SWHJDRQ from B_SWHTL where SFBZ=(select MAX(SFBZ) from B_SWHTL where  AJBS=B_AJZTXX.AJBS))SWHJDRQ,
to_char((select SWHJDRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')SWHJDRQ,
to_char((select YZQFRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')YZQFRQ,(select to_char(PYRQ,'yyyy"年"MM"月"dd"日"') AS HYTHYRQ from B_AJPY where SFBZ=(select MAX(SFBZ) from B_AJPY where  AJBS=B_AJZTXX.AJBS))HYTHYRQ,(select MC from B_DM where BH=(case AJLB when 2 then 'GF2009-07309' else (case ajly when 5 then 'GF2009-07210' else 'GF2009-07209' end) end) AND DM=B_AJZTXX.JAFS)JAFS,
(select to_char(SDRQ,'yyyy"年"MM"月"dd"日"') from B_SDJL where SFBZ=(select MAX(SFBZ) from B_SDJL where AJBS=B_AJZTXX.AJBS AND  WSLB=1))CPWSSDSJ,
(select (select YHXM from B_YHDM where YHDM=B_SDJL.SDR AND SCFY=B_SDJL.SCFY) from B_SDJL where SFBZ=(select MAX(SFBZ) from B_SDJL where AJBS=B_AJZTXX.AJBS AND  WSLB=1)) CPWSSDSDR,(select AYNR  from B_AY where AYDM=B_AJZTXX.JAAY)JAAY,(select JABZ from B_AJFZXX where AJBS=B_AJZTXX.AJBS)JABZ,(select MC from B_DM where BH='GF2009-07411' AND DM=B_AJZTXX.PCFS)PCFS
 from B_AJZTXX where KPLB=17
/

