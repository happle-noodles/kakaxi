create PROCEDURE P_TJFX_YSAJDBTJ(fytj varchar2,jnsjqj varchar2,qnsjqj varchar2, rt out pkg_row.myRow) as
/*月结案情况 杨元胜
fytj 查询法院
jnsjqj 今年时间区间
qnsjqj 去年时间区间
rt   返回数据集
*/
v_scfy varchar2(200);
BEGIN
 v_scfy:='B_TJHZ.cjfy=b_fy.dm and b_fy.dm between 4166 and 4208 and '|| fytj;

insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'刑事',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'民事',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'行政',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'总计',-1,0,0 from dual;

--今年民事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=7 AND
	SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''民事'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNPJS=B.PJS,A.JNCSS=B.CDS,A.JNWCS=B.SSXSS';

--去年民事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=7 AND
	SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''民事'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNPJS=B.PJS,A.QNCSS=B.CDS,A.QNWCS=B.SSXSS';

--今年刑事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=1 AND
	SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''刑事'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNPJS=B.PJS,A.JNCSS=B.CDS,A.JNWCS=B.SSXSS';

--去年刑事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=1 AND
	SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''刑事'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNPJS=B.PJS,A.QNCSS=B.CDS,A.QNWCS=B.SSXSS';

--今年行政一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=13 AND
	SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''行政'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNPJS=B.PJS,A.JNCSS=B.CDS,A.JNWCS=B.SSXSS';

--去年行政一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=13 AND
	SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''行政'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNPJS=B.PJS,A.QNCSS=B.CDS,A.QNWCS=B.SSXSS';

--今年总计
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB in (1,7,13) AND
	SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''总计'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNPJS=B.PJS,A.JNCSS=B.CDS,A.JNWCS=B.SSXSS';

--去年总计
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(PJS) AS PJS,sum(CDS) AS CDS,SUM(SSXSS) AS SSXSS
	FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB IN (1,7,13) AND
	SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''总计'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNPJS=B.PJS,A.QNCSS=B.CDS,A.QNWCS=B.SSXSS';
    
  if(fytj='1=1') then
    execute immediate'update b_tempaytj set JNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=2 AND SJQJ LIKE '''||jnsjqj||''') where (AYMC=''刑事'')';
    execute immediate'update b_tempaytj set JNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=8 AND SJQJ LIKE '''||jnsjqj||''') where (AYMC=''民事'')';
    execute immediate'update b_tempaytj set JNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=14 AND SJQJ LIKE '''||jnsjqj||''') where (AYMC=''行政'')';
    execute immediate'update b_tempaytj set JNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB IN（2,8,14) AND SJQJ LIKE '''||jnsjqj||''') where (AYMC=''总计'')';
    execute immediate'update b_tempaytj set QNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=2 AND SJQJ LIKE '''||qnsjqj||''') where (AYMC=''刑事'')';
    execute immediate'update b_tempaytj set QNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=8 AND SJQJ LIKE '''||qnsjqj||''') where (AYMC=''民事'')';
    execute immediate'update b_tempaytj set QNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=14 AND SJQJ LIKE '''||qnsjqj||''') where (AYMC=''行政'')';
    execute immediate'update b_tempaytj set QNWCS=(SELECT SUM(XSS) FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB IN（2,8,14) AND SJQJ LIKE '''||qnsjqj||''') where (AYMC=''总计'')';
  end if;  
  
    
    update b_tempaytj set QNCSS=QNYJ-QNTJS-QNPJS;
    update b_tempaytj set JNCSS=JNYJ-JNTJS-JNPJS;

    update b_tempaytj set jnjal= round(100*jnyj/jnsls,2) where jnsls>0;
    update b_tempaytj set qnjal= round(100*qnyj/qnsls,2) where qnsls>0;
	--调撤率
	update b_tempaytj set jnbhs=round(100*jntjs/jnyj,2) where jnyj>0;
	update b_tempaytj set qnbhs=round(100*qntjs/qnyj,2) where qnyj>0;
	--判决率
	update b_tempaytj set jngps=round(100*jnpjs/jnyj,2) where jnyj>0;
	update b_tempaytj set qngps=round(100*qnpjs/qnyj,2) where qnyj>0;
	--裁定率
	update b_tempaytj set jnfhcss=round(100*jncss/jnyj,2) where jnyj>0;
	update b_tempaytj set qnfhcss=round(100*qncss/qnyj,2) where qnyj>0;
	--上诉率
	update b_tempaytj set jnqts=round(100*jnwcs/jnyj,2) where jnyj>0;
	update b_tempaytj set qnqts=round(100*qnwcs/qnyj,2) where qnyj>0;

  -- open rt for select * from b_tempaytj;
   open rt for select * from b_tempaytj WHERE (JNSLS>0 OR QNSLS>0);
END P_TJFX_YSAJDBTJ;

/

