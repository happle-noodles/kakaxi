create PROCEDURE P_JXKH_DETAILE(ncjfy number, n_zbbs number,qsrq varchar2,jsrq varchar2,n_bz number,v_group varchar2,pttj varchar2,lx number,rt out pkg_row.myRow) as
/*统计分析二级页面分组信息 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_tj varchar2(4500);
v_fztj varchar2(500);


v_fzlm varchar2(220);
v_scfy varchar2(400);

v_jafsmc varchar2(1600);
v_ajlymc varchar2(1500);
v_ysfy varchar2(200);
v_temp varchar2(200);
v_kplb varchar2(100);


v_fz varchar2(1600);

begin
   select gsnr into v_ajlymc   from b_tjfxgs where gsmc='案件来源名称';
   select gsnr into v_jafsmc   from b_tjfxgs where gsmc='结案方式名称';
   select gsnr into v_ysfy   from b_tjfxgs where gsmc='原审法院名称';

   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
        DBMS_OUTPUT.put_line('123');
 if n_bz=1
   then
  case
       --一审判决案件改判发回重审率
       when n_zbbs in(1478,4) then
            v_fz:= v_yjtj|| ' and  kplb in(2,8,14) and ((jafs=2 and nvl(gpyy,0)<>5) or( jafs=3 and ((kplb=2 and nvl(fhcsyy,0)<>7) or (kplb in(8,14) and nvl(fhcsyy,0)<>8)))) and  '||ncjfy||' in (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS and ROWNUM=1)' ;
        --生效案件改判发回重审率
        when n_zbbs in(1479,5) then
             v_fz:= v_yjtj|| 'and  kplb in(3,9,15) and ((jafs=2 and nvl(gpyy,0)<>5) or( jafs=3 and ((kplb=2 and nvl(fhcsyy,0)<>7) or (kplb in(9,15) and nvl(fhcsyy,0)<>8)))) and '||ncjfy||' in  (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS and ROWNUM=1)' ;
        --司法赔偿案件
        when n_zbbs in(1480,6) then
             v_fz:= v_yjtj|| ' and KPLB = 17 and jafs=101 and '||ncjfy||'in(select (select dm from b_fy where fymc=b.mc) as dm from b_pcywjg a,b_yastml b where a.ajbs=b.ajbs and a.pcywjg=b.xh and a.ajbs=b_ajztxx.ajbs and ROWNUM=1) '; --全兵团系统没有
        --法官因审判执行案件被追究刑事责任
        when n_zbbs in(1482,7) then
             v_fz:='1=2';
        --法院年人均结案数
        when n_zbbs in(1483,8) then
             v_fz:= v_yjtj|| ' and  (KPLB<19 OR (KPLB>19 AND KPLB<30) or kplb>33) and scfy='||ncjfy;
        --审结率
        when n_zbbs in(1484,9) then
             v_fz:= v_yjtj|| ' and kplb<>4 and (KPLB<19 OR (KPLB>19 AND KPLB<30) or kplb>33) and scfy='||ncjfy;
         --法定期限内结案率
        when n_zbbs in(1485,10) then
             v_fz:= v_yjtj|| ' and kplb<>4 and ((nvl(YCTS,0)<=0 and nvl(CSXTS,0)<=0) or kplb=12 or kplb=22) and (KPLB<19 OR (KPLB>19 AND KPLB<30)) and scfy='||ncjfy;
          --平均审理时间指数
         when n_zbbs in(1486,11) then
            v_fz:= v_yjtj|| ' and KPLB IN(1,2,3,7,8,9,13,14,15,18) and nvl(sjslts,0)>0 and fdsxts>0 and scfy='||ncjfy;
          --结案均衡度
         when n_zbbs in(1487,12) then
           v_fz :='1=2';
          --一审服判息诉率
          when n_zbbs in(1488,13) then
           v_fz :=v_xstj|| ' and  kplb in(2,8,14) and '||ncjfy||' in  (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND jbfy='||ncjfy||' AND ROWNUM=1)';
           --调解率(民事一二再审)
          when n_zbbs in(1489,14) then
           v_fz :=v_yjtj|| ' and ((kplb=7 and jafs=7) or (kplb in(8,9) and jafs=9)) and scfy='||ncjfy;
           --撤诉率
          when n_zbbs in(1490,15) then
           v_fz :=v_yjtj|| ' and ((KPLB=1 AND JAFS in(4,5,9))or (KPLB=2 AND JAFS in(5,6,112,107,108,109,110)) or (KPLB=3 AND JAFS in(5,6,107,108,109,110,113,116,117)) OR (KPLB in(7,13) AND JAFS in(4,5)) OR (KPLB =8 AND JAFS in(6,7,110)) OR (KPLB =9 AND JAFS in(6,7,106)) OR (KPLB in (14,15) AND JAFS in(6,7))) and scfy='||ncjfy;
           --裁判案件自动履行率
          when n_zbbs in(1493,16) then
           v_fz :=v_xstj||' AND FZKPLB=16 AND AJLB=1 and AH NOT LIKE ''%执保%''  and AH NOT LIKE ''%执异%'' and AH NOT LIKE ''%执协%'' and AH NOT LIKE ''%执请%'' and AH NOT LIKE ''%执监%'' and AH NOT LIKE ''%执复%'' and '||ncjfy|| 'in (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS  and ROWNUM=1)' ;
           --调解案件申请执行率
          when n_zbbs in(1494,17) then
           v_fz :=v_xstj|| ' and  kplb=16 and  AJLB=1  AND AH NOT LIKE ''%执协%''  AND AH NOT LIKE ''%执监%''  AND AH NOT LIKE ''%执异%''  AND AH NOT LIKE ''%执复%''  AND AH NOT LIKE ''%执请%'' AND AH NOT LIKE ''%执保%'' and  (select jbfy from b_ysqk where b_ysqk.ajbs=b_ajztxx.ajbs and rownum=1)='||ncjfy||' and exists (select ajbs from b_ysqk where b_ysqk.ajbs=b_ajztxx.ajbs and rownum=1 and exists (select ajbs from b_ajztxx where ah=b_ysqk.ah and jarq is not null and ((KPLB in(7,13) AND JAFS=7) OR (KPLB in(8,9,14,15) and JAFS=9) OR(KPLB in(12) AND JAFS=6))))';
            --再审审查率
          when n_zbbs in(1499,18) then
           v_fz :=v_xstj||' AND FZKPLB IN(23,24,25) and  '||ncjfy||' in (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS and ROWNUM=1)' ;
           --涉诉信访
           when n_zbbs in(1501) then
           v_fz :='1=2';
          --司法建议
          when n_zbbs in(1502,21) then
            v_fz :=v_yjtj|| ' and  ajbs in(select ajbs from b_sfjy) and scfy='||ncjfy;
        --信息录入错误率
          when n_zbbs in(1503) then
           v_fz :='1=2';
        else
         v_fz:='1=2';
       end case;
  else
       --分母
       case
       --一审判决案件改判发回重审率
        when n_zbbs in(1478,4) then
             v_fz:= v_yjtj|| ' and  kplb in(1,7,13) and jafs=1 and scfy='||ncjfy;
        --生效案件改判发回重审率
        when n_zbbs in(1479,5) then
             v_fz:= v_yjtj|| ' and  kplb in(1,13,7,2,8,14) and scfy='||ncjfy;
         --司法赔偿案件
        when n_zbbs in(1480,6) then
             v_fz:= v_yjtj|| ' AND 1=2 and scfy='||ncjfy;
         --法官因审判执行案件被追究刑事责任
        when n_zbbs in(1482,7) then
             v_fz:='1=2';
         --法院年人均结案数
        when n_zbbs in(1483,8) then
             v_fz:='1=2';
        --审结率
        when n_zbbs in(1484,9) then
           v_fz:= '('||v_yjtj|| ' or  '||v_wjtj ||') and kplb<>4  and (KPLB<19 OR (KPLB>19 AND KPLB<30) or kplb>33) and scfy='||ncjfy;
          --法定期限内结案率
        when n_zbbs in(1485,10) then
           v_fz:= v_yjtj|| ' and kplb<>4  and (KPLB<19 OR (KPLB>19 AND KPLB<30)) and scfy='||ncjfy;
           --平均审理时间指数
        when n_zbbs in(1486,11) then
            v_fz:= v_yjtj|| ' and KPLB IN(1,2,3,7,8,9,13,14,15,18) and nvl(sjslts,0)>0 and fdsxts>0 and scfy='||ncjfy;
           --结案均衡度
        when n_zbbs in(1487,12) then
           v_fz:='1=2';
          --一审服判息诉率
        when n_zbbs in(1488,13) then
            v_fz:= v_yjtj|| ' and  kplb in(1,13,7) and scfy='||ncjfy;
          --调解率(民事一二再审)
        when n_zbbs in(1489,14) then
            v_fz:= v_yjtj|| ' and  kplb in(7,8,9) and scfy='||ncjfy;
          --撤诉率
        when n_zbbs in(1490,15) then
           v_fz:= v_yjtj|| ' and kplb in(1,2,3,7,8,9,13,14,15) and scfy='||ncjfy;
          --裁判案件自动履行率
        when n_zbbs in(1493,16) then
           v_fz :=v_yjtj|| ' and  kplb in(1,2,3,7,8,9,13,14,15,12,21) and scfy='||ncjfy;
        --调解案件申请执行率
        when n_zbbs in(1494,17) then
           v_fz :=v_yjtj|| ' and ((kplb=7 and jafs=7) or (kplb in(8,9) and jafs=9)) and scfy='||ncjfy;
         --再审审查率
        when n_zbbs in(1499,18) then
           v_fz :=v_yjtj|| ' and kplb in(1,2,7,8,13,14) and scfy='||ncjfy;
         --涉诉信访
        when n_zbbs in(1501) then
           v_fz :='1=2';
        --司法建议
        when n_zbbs in(1502,21) then
           v_fz :='1=2';
           --信息录入错误率
        when n_zbbs in(1503) then
           v_fz :='1=2';
        else
        v_fz:='1=2';
       end case;
  end if;
 if lx=1
  then
      case
         when v_group='KPLB'THEN
          v_fzlm:='NVL((SELECT MC FROM B_KPLB B WHERE B.KPLB=A.KPLB),''未知案件类型'') AS MC';
          v_tj:='select count(*) AS SZ,'||v_fzlm||',NVL(KPLB,-1) AS DM from (SELECT (case when kplb =18 then nvl(ajlb,0)+kplb+4 else kplb end) as kplb  FROM b_ajztxx  where '||v_fz||') A group by '||v_group||' order by kplb';
           when v_group='SSYY'THEN
          v_fzlm:='NVL((SELECT MC FROM B_DM  B WHERE B.BH=''GF2014-00001'' AND  B.DM=b_ajztxx.SSYY),''未知诉讼语言'') AS MC';
          v_tj:='select count(ajbs) AS SZ,'||v_fzlm||',NVL(SSYY,-1) AS DM from b_ajztxx  where '||v_fz||' group by '||v_group;
          when v_group='LAAY'THEN
          v_fzlm:='NVL((SELECT AYNR FROM B_AY  B WHERE  B.AYDM=b_ajztxx.LAAY),''无案由'') AS MC';
          v_tj:='select count(ajbs) AS SZ,'||v_fzlm||',NVL(LAAY,-1) AS DM from b_ajztxx  where '||v_fz||' group by '||v_group;
          when  v_group='JAFS'THEN
          v_tj:='select count(*) AS SZ,A.JAFSMC AS MC,A.JAFSMC AS DM from (SELECT '||v_jafsmc||'AS JAFSMC from b_ajztxx  where '||v_fz||') A group by A.JAFSMC';
          when  v_group='AJLY'THEN
          v_tj:='select count(*) AS SZ,A.AJLYMC AS MC,A.AJLYMC AS DM from (SELECT '||v_ajlymc||'AS AJLYMC from b_ajztxx  where '||v_fz||') A group by A.AJLYMC';
          when  v_group='YSFY'THEN
          v_tj:='select count(*) AS SZ,A.YSFYMC AS MC,A.YSFYMC AS DM from (SELECT '||v_ysfy||'AS YSFYMC from b_ajztxx  where '||v_fz||') A group by A.YSFYMC';
       end case;
  else
          v_fz:=v_fz||pttj;
          v_tj:='select rownum as rowno, scfy,ajbs,kplb,ajlb,ah,(select aynr from b_ay b where b_ajztxx.laay=b.aydm) as laay,to_char(larq,''yyyy-mm-dd'') as larq,to_char(jarq,''yyyy-mm-dd'') as jarq,sjymc,dsrmc,jabdje,qsbdje,
          '||v_jafsmc||' as jafs,(select yhxm from b_yhdm b where b_ajztxx.cbr=b.yhdm and b.scfy=b_ajztxx.scfy) AS CBR from b_ajztxx  where '||v_fz;
  end if;

        DBMS_OUTPUT.put_line('fisish:'||v_tj);
   open rt for v_tj;
end P_JXKH_DETAILE;
/

