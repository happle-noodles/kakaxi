create PROCEDURE P_TJFX_DZJZSASCTJ(nscfy number,qsrq varchar2,jsrq varchar2,zfjbz varchar2,fyjb number,rt out pkg_row.myRow) as
/*电子卷宗随案生成统计 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_tytj varchar2(100);
v_yjtj1 varchar2(200);



jssj date;
begin
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_yjtj1:=v_yjtj;
   jssj:=to_date(jsrq,'yyyy-mm-dd')-90;

   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_tytj :='exists (select 1 from v_dzjz where ajbs=m.ajbs';
   if zfjbz=2
     then
          v_tytj:=v_tytj||' and zfjbz=''正卷''';
      elsif zfjbz=3
      then
         v_tytj:=v_tytj||' and zfjbz=''副卷''';
      end if;

    v_tytj:=v_tytj||')';

   if fyjb=3
     then
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT 1,1,'全兵团法院',1,-1 FROM dual ;
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT dm,dm,fyjx,1,5 FROM B_fy where dm=nscfy;
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT 2,2,'中级人民法院',2,-2 FROM dual ;
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT 3,3,'垦区人民法院',3,-3 FROM dual;
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT dm||'+', dm,replace(fyjx,'中级人民',''),xssx+100,-4 FROM B_fy where dm between 4166 and 4208 and fyjb=2;
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb,ajlb) SELECT dm,dm,fyjx,xssx+200,fyjb,sjdm FROM B_fy where dm between 4167 and 4208;
       v_scfy :='scfy between 4166 and 4208';
    elsif fyjb=2
      then
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT dm||'+', dm,replace(fyjx,'中级人民',''),xssx+100,-4 FROM B_fy where dm =nscfy  and fyjb=2;
       INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb,ajlb) SELECT dm,dm,fyjx,xssx+200,fyjb,sjdm FROM B_fy where dm=nscfy or sjdm=nscfy;
       v_scfy:='scfy in (select dm from B_TEMPTJFX)';
     else
      INSERT INTO B_TEMPTJFX(tsmc,DM,MC,XSSX,Kplb) SELECT dm,dm,fyjx,xssx,5 FROM B_fy where dm=nscfy;
      v_scfy:='scfy='||nscfy;
    end if;


    execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx m  WHERE '||v_scfy||'and '||v_kplb||' AND '|| v_yjtj ||' group by scfy)B
     ON(A.DM=nvl(B.scfy,-2) and a.kplb>0)
     when matched then update set A.xs=B.SL ';--已结数

      execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx m WHERE '||v_scfy||' and '||v_kplb||' AND '|| v_yjtj ||' and '||v_tytj ||'  group by scfy)B
     ON(A.DM=nvl(B.scfy,-2) and a.kplb>0)
     when matched then update set A.xsyj=B.SL ';--已结数

    execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx m  WHERE '||v_scfy||' and '||v_kplb||' AND '|| v_wjtj ||' group by scfy)B
     ON(A.DM=nvl(B.scfy,-2) and a.kplb>0)
     when matched then update set A.jc=B.SL ';--已结数

      execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx m WHERE '||v_scfy||' and '||v_kplb||' AND '|| v_wjtj ||' and '||v_tytj ||'  group by scfy)B
     ON(A.DM=nvl(B.scfy,-2) and a.kplb>0)
     when matched then update set A.jcyj=B.SL ';--已结数


     if to_date(qsrq,'yyyy-mm-dd')<=jssj
       then
           v_yjtj1 :=replace(v_yjtj1,'＆QsRq＆',qsrq);
           v_yjtj1 :=replace(v_yjtj1,'＆JsRq＆',to_char(jssj,'yyyy-mm-dd'));

           execute immediate ' merge into B_TEMPTJFX  A
            using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx m  WHERE '||v_scfy||' and '||v_kplb||' AND '|| v_yjtj1 ||' group by scfy)B
           ON(A.DM=nvl(B.scfy,-2) and a.kplb>0)
           when matched then update set A.sls=B.SL ';--已结数

            execute immediate ' merge into B_TEMPTJFX  A
           using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx m WHERE '||v_scfy||' and '||v_kplb||' AND '|| v_yjtj1 ||' and '||v_tytj ||'  group by scfy)B
           ON(A.DM=nvl(B.scfy,-2) and a.kplb>0)
           when matched then update set A.yj=B.SL ';--已结数


       end if;



     update B_TEMPTJFX a set xs=(select sum(xs) from B_TEMPTJFX where kplb>0 and (ajlb= a.dm or dm=a.dm)),jc=(select sum(jc) from B_TEMPTJFX where kplb>0 and (ajlb= a.dm or dm=a.dm)),xsyj=(select sum(xsyj) from B_TEMPTJFX where kplb>0 and (ajlb= a.dm or dm=a.dm)),jcyj=(select sum(jcyj) from B_TEMPTJFX where kplb>0 and (ajlb= a.dm or dm=a.dm)),sls=(select sum(sls) from B_TEMPTJFX where kplb>0 and (ajlb= a.dm or dm=a.dm)),yj=(select sum(yj) from B_TEMPTJFX where kplb>0 and (ajlb= a.dm or dm=a.dm))  where kplb=-4;
     update B_TEMPTJFX a set xs=(select sum(xs) from B_TEMPTJFX where kplb=2 ),jc=(select sum(jc) from B_TEMPTJFX where kplb=2 ),xsyj=(select sum(xsyj) from B_TEMPTJFX where kplb=2 ),sls=(select sum(sls) from B_TEMPTJFX where kplb=2 ),yj=(select sum(yj) from B_TEMPTJFX where kplb=2 ),jcyj=(select sum(jcyj) from B_TEMPTJFX where kplb=2 ) where kplb=-2;
     update B_TEMPTJFX a set xs=(select sum(xs) from B_TEMPTJFX where kplb=1 ),jc=(select sum(jc) from B_TEMPTJFX where kplb=1 ),xsyj=(select sum(xsyj) from B_TEMPTJFX where kplb=1 ),sls=(select sum(sls) from B_TEMPTJFX where kplb=1 ),yj=(select sum(yj) from B_TEMPTJFX where kplb=1 ),jcyj=(select sum(jcyj) from B_TEMPTJFX where kplb=1 ) where kplb=-3;
     update B_TEMPTJFX a set xs=(select sum(xs) from B_TEMPTJFX where kplb>0 ),jc=(select sum(jc) from B_TEMPTJFX where kplb>0 ),xsyj=(select sum(xsyj) from B_TEMPTJFX where kplb>0 ),sls=(select sum(sls) from B_TEMPTJFX where kplb>0 ),yj=(select sum(yj) from B_TEMPTJFX where kplb>0 ),jcyj=(select sum(jcyj) from B_TEMPTJFX where kplb>0 ) where kplb=-1;

     update B_TEMPTJFX set xswj=xs-xsyj,jcwj=jc-jcyj,wj=sls-yj;


     open rt for SELECT tsmc,DM,MC,ajlb,kplb,XS,xsyj,xswj,jc,jcyj,jcwj,sls,yj,wj FROM  B_TEMPTJFX  order by XSSX;

end P_TJFX_DZJZSASCTJ;
/

