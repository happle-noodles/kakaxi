create trigger B_AJXXZDYCXTJ_YXTJCSXX_TRIGGER
  before insert
  on B_AJXXZDYCXTJ_YXTJCSXX
  for each row
  declare
  -- local variables here
begin
  select S_XGYW.nextval into :new.SFBZ from B_AJZTXX where ROWNUM<=1;
end B_AJXXZDYCXTJ_YXTJCSXX_TRIGGER ;
/

