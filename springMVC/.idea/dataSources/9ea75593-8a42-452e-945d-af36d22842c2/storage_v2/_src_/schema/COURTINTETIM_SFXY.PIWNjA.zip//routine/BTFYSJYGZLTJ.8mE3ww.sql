create PROCEDURE BtFySjyGzlTj(nscfy number,qsrq varchar2,jsrq varchar2,ndqsrq varchar2,ndjsrq varchar2, rt out pkg_row.myRow) as
v_scfy varchar2(200);
v_kplb varchar2(100);
v_gdjsrq varchar(200);
v_ndxstj varchar2(200);
v_ndyjtj varchar2(200);
v_ndwjtj varchar2(200);
v_ndjctj varchar2(200);

v_yxstj varchar2(200);

begin
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
  v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
  dbms_output.put_line(ndjsrq);
  v_gdjsrq :=to_char(add_months(to_timestamp(ndjsrq,'yyyy-mm-dd'), -1),'yyyy-mm-dd');
  dbms_output.put_line(v_gdjsrq);

   select gsnr into v_ndxstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_ndyjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_ndwjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_ndjctj  from b_tjfxgs where gsmc='旧存A';
   v_yxstj:=v_ndxstj;
   v_yxstj :=replace(v_yxstj,'＆QsRq＆',qsrq);
   v_yxstj :=replace(v_yxstj,'＆JsRq＆',jsrq);

   v_ndxstj :=replace(v_ndxstj,'＆QsRq＆',ndqsrq);
   v_ndxstj :=replace(v_ndxstj,'＆JsRq＆',ndjsrq);
   v_ndyjtj :=replace(v_ndyjtj,'＆QsRq＆',ndqsrq);
   v_ndyjtj :=replace(v_ndyjtj,'＆JsRq＆',ndjsrq);
   v_ndwjtj :=replace(v_ndwjtj,'＆JsRq＆',ndjsrq);
   v_ndjctj :=replace(v_ndjctj,'＆QsRq＆',ndqsrq);


  execute immediate'INSERT INTO B_TEMPYJAQKTJ (BMMC,BMBS,AJLX) SELECT YHXM||''#''||(SELECT TSMC FROM B_TSDM WHERE SCFY=B_YHDM.SCFY AND TSDM=B_YHDM.TSDM),YHDM,1 AJLX FROM B_YHDM  where scfy='||nscfy||' ORDER BY (SELECT XSSX FROM B_TSDM WHERE SCFY=B_YHDM.SCFY AND TSDM=B_YHDM.TSDM),XSSX';
  INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('合计#',-1,1);
  INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('未分配书记员#承办部门',0,1);
  execute immediate'INSERT INTO B_TEMPYJAQKTJ (BMMC,BMBS,AJLX) SELECT ''#''||TSMC,TSDM,2 AJLX FROM B_TSDM  where scfy='||nscfy||' ORDER BY XSSX';
  INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('未分配书记员#无承办部门',-1,2);

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,SADJR FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||') AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.SADJR)B
    ON(A.BMBS=B.SADJR)
    when matched then update set A.NDXS=B.SL WHERE AJLX=1';--年度立案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||') AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.NDJC=B.SL WHERE AJLX=1';--年度记录数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.NDYJ=B.SL WHERE AJLX=1';--年度应归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd''))  AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.NDWJ=B.SL WHERE AJLX=1';--年度已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.NDQT=B.SL WHERE AJLX=1';--年度未归档数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||')  AND '||v_scfy||' AND '||v_kplb||')B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.NDXS=B.SL WHERE AJLX=1';--合计立案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||')  AND '||v_scfy||' AND '||v_kplb||') )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.NDJC=B.SL WHERE AJLX=1';--合计记录数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||')  )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.NDYJ=B.SL WHERE AJLX=1';--合计应归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||')  )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.NDWJ=B.SL WHERE AJLX=1';--合计已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.NDQT=B.SL WHERE AJLX=1';--合计未归档数

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,labmbs as CBSPT FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||') AND '||v_scfy||' AND '||v_kplb||' AND SADJR IS NULL GROUP BY B_AJZTXX.labmbs)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.NDXS=B.SL WHERE AJLX=2';--庭室年度立案数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
     using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||') AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.NDJC=B.SL WHERE AJLX=2';--庭室年度记录数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.NDYJ=B.SL WHERE AJLX=2';--庭室年度应归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.NDWJ=B.SL WHERE AJLX=2';--庭室年度已归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.NDQT=B.SL WHERE AJLX=2';--庭室年度未归档数

    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  ('||v_ndxstj||' OR '||v_ndjctj||')  AND '||v_scfy||' AND '||v_kplb||' AND SADJR IS NULL and LABMBS IS NULL)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.NDXS=B.SL WHERE AJLX=2';--无庭室年度立案数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
     using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE   ('||v_ndxstj||' OR '||v_ndjctj||') AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.NDJC=B.SL WHERE AJLX=2';--无庭室年度记录数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.NDYJ=B.SL WHERE AJLX=2';--无庭室年度应归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.NDWJ=B.SL WHERE AJLX=2';--无庭室年度已归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||ndqsrq||''',''yyyy-MM-dd'') AND to_date('''||v_gdjsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.NDQT=B.SL WHERE AJLX=2';--无庭室年度未归档数



     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,SADJR FROM B_AJZTXX WHERE '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.SADJR)B
    ON(A.BMBS=B.SADJR)
    when matched then update set A.XS=B.SL WHERE AJLX=1';--月份立案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A

    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.JC=B.SL WHERE AJLX=1';--月份记录数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.YJ=B.SL WHERE AJLX=1';--月份应归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||jsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.WJ=B.SL WHERE AJLX=1';--月份已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||jsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') GROUP BY B_SPZZCY.YCY )B
    ON(A.BMBS=B.YCY)
    when matched then update set A.QT=B.SL WHERE AJLX=1';--月份未归档数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE   '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.XS=B.SL WHERE AJLX=1';--合计月份立案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE   '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||') )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.JC=B.SL WHERE AJLX=1';--合计月份记录数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||')  )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.YJ=B.SL WHERE AJLX=1';--合计月份应归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||jsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||')  )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.WJ=B.SL WHERE AJLX=1';--合计已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE JS=8 AND AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||jsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||') )B
    ON(A.BMBS=-1 and A.AJLX=1)
    when matched then update set A.QT=B.SL WHERE AJLX=1';--合计月份未归档数

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,LABMBS AS CBSPT FROM B_AJZTXX WHERE   '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||' AND SADJR IS NULL GROUP BY B_AJZTXX.LABMBS)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.XS=B.SL WHERE AJLX=2';--庭室月份立案数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
     using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE   '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.JC=B.SL WHERE AJLX=2';--庭室月份记录数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.YJ=B.SL WHERE AJLX=2';--庭室月份应归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||jsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.WJ=B.SL WHERE AJLX=2';--庭室月份已归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||jsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT)
    when matched then update set A.QT=B.SL WHERE AJLX=2';--庭室月份未归档数

    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE   '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||' AND LABMBS IS NULL and SADJR IS NULL)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.XS=B.SL WHERE AJLX=2';--无庭室月份立案数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
     using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE   '||v_yxstj||' AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.JC=B.SL WHERE AJLX=2';--无庭室月份记录数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  (JARQ IS NOT NULL AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.YJ=B.SL WHERE AJLX=2';--无庭室月份应归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||jsrq||''',''yyyy-MM-dd'')) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.WJ=B.SL WHERE AJLX=2';--无庭室月份已归档数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  (JARQ IS NOT NULL and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||jsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) AND JARQ  BETWEEN to_date('''||qsrq||''',''yyyy-MM-dd'') AND to_date('''||jsrq||''',''yyyy-MM-dd'')) AND '||v_scfy||' AND '||v_kplb||' AND SJYMC IS NULL and CBSPT is null)B
    ON(A.BMBS=-1 AND A.AJLX=2)
    when matched then update set A.QT=B.SL WHERE AJLX=2';--无庭室月份未归档数

  open rt for select * from B_TEMPYJAQKTJ where (NDXS>0 OR NDJC>0 OR NDYJ>0 OR NDWJ>0 OR NDQT>0 OR BMBS=0 or XS>0 OR JC>0 OR YJ>0 OR WJ>0 OR QT>0);
end BtFySjyGzlTj;
/

