create PROCEDURE                   P_YJWSB_XSYJ(qsrq varchar2,jsrq varchar2,rt out pkg_row.myRow) as
/*一级网上报新收、已经 杨元胜
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);



   INSERT INTO B_TEMPTJFX(DM) SELECT DISTINCT SCFY FROM B_AJZTXX;
   execute immediate 'UPDATE B_TEMPTJFX A SET A.XS=(SELECT COUNT(AJBS) FROM   b_ajztxx B  WHERE '|| v_xstj || ' AND A.DM=B.SCFY  group by B.SCFY)';/*新收已结 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.YJ=(SELECT COUNT(AJBS) FROM   b_ajztxx B  WHERE '|| v_yjtj || ' AND A.DM=B.SCFY  group by B.SCFY)';/*新收未结*/

   open rt for SELECT DM AS SCFY,XS,YJ FROM  B_TEMPTJFX;
end P_YJWSB_XSYJ;

/

