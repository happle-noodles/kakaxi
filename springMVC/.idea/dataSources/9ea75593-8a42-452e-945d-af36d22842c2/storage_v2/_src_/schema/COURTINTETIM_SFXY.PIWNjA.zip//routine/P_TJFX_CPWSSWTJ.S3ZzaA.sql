create PROCEDURE P_TJFX_CPWSSWTJ(nscfy number,qsrq varchar2,jsrq varchar2,tsdm number,kplb varchar2,rt out pkg_row.myRow) as
/*裁判文书上网分析 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);

begin
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';


   v_kplb :=kplb;
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);


  if tsdm=0
  then
     execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) select a.yhdm,a.yhxm from B_YHDM a,b_tsdm b  WHERE a.SCFY='||nscfy||' and b.scfy='||nscfy||' and a.tsdm=b.tsdm order by b.xssx,a.xssx ';
     INSERT INTO B_TEMPTJFX(dm,MC,XSSX) SELECT -2,'待分案',1000 from dual;
  else
      execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) select a.yhdm,a.yhxm from B_YHDM a,b_tsdm b  WHERE a.SCFY='||nscfy||' and b.scfy='||nscfy||' and a.tsdm=b.tsdm and a.tsdm='||tsdm||' order by b.xssx,a.xssx ';
  end if;

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.YJ=B.SL ';--已结数
   
   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_wjtj ||' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.WJ=B.SL ';/*未结*/

     execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND NVL(cpwssfsw,0)=1 group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.YJYC=B.SL ';/*文书上网*/

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND NVL(cpwssfsw,0)=2 group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.YJZZ=B.SL ';/*文书未上网*/
     
   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND  NVL(cpwssfsw,0)=0 group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.SXBGS=B.SL ';/*信息未录入*/
     
   insert into B_TEMPTJFX(DM,MC,XSSX)values(0,'合计',0);

    update B_TEMPTJFX set YJ=(select sum(YJ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set WJ=(select sum(WJ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set YJYC=(select sum(YJYC) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set YJZZ=(select sum(YJZZ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set SXBGS=(select sum(SXBGS) from B_TEMPTJFX) where DM=0;


    update B_TEMPTJFX A SET A.SLS=NVL(A.YJ,0)+NVL(A.WJ,0);/*受理数*/
    update B_TEMPTJFX A SET A.JAL=100*NVL(A.YJ,0)/A.SLS WHERE  A.SLS>0;/*结案率*/

    open rt for SELECT DM,MC,NVL(SLS,0) AS SLS,NVL(YJ,0) AS YJ,NVL(YJYC,0) AS YJYC,NVL(YJZZ,0) AS YJZZ,NVL(SXBGS,0) AS SXBGS  FROM  B_TEMPTJFX where sls>0 ;

end P_TJFX_CPWSSWTJ;
/

