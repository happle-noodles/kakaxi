create PROCEDURE P_TJFX_CASE_DETAILE_INFO(nScfy varchar2, qsrq varchar2,jsrq varchar2,zhtj varchar2,pttj varchar2,rt out pkg_row.myRow) as
/*统计分析二级页面分组信息 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_tj varchar2(4500);
v_fztj varchar2(400);
v_sql varchar2(400);
str VARCHAR2 (200);
v_scfy varchar2(400);
v_jafs varchar2(1600);
j INT := 0;
i INT := 1;
len INT := 0;

begin
  if nScfy='1' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='全兵团法院';
   elsif nScfy='2' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='兵团中级人民法院';
   elsif nScfy='3' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='兵团基层人民法院';
   elsif instr(nScfy,'+')>0 then
     select gsnr into v_scfy from b_tjfxgs where gsmc='中院地区';
     v_scfy :=replace(v_scfy,'＆SCFY＆',replace(nScfy,'+'));
   else
      v_scfy:='SCFY='||nScfy;
   end if;
    v_scfy:=v_scfy||' and (KPLB<19 OR (KPLB>19 AND KPLB<30) OR KPLB>39)';
    select gsnr into v_jafs from b_tjfxgs where gsjc='JAFSMC';
  len := LENGTH(zhtj);
  /* 替换组合条件*/
  while j<len
     loop
       j := INSTR (zhtj, '#', i);
        IF j = 0
        THEN
             j := len;
             str := SUBSTR (zhtj, i);
            IF i >= len
            THEN
                EXIT;
            END IF;
        ELSE
            str := SUBSTR (zhtj, i, j - i);
            i := j + 1;
        END IF;

       v_sql:= 'select gsnr  from b_tjfxgs where gsjc='''||str||'''';
       execute immediate v_sql into v_fztj;
       if length(v_fztj)=0
         then
           exit;
         end if;

        if 'YJ'=str or 'WJ'=str or 'XS'=str or 'JC'=str or 'SLS'=str then
           v_fztj :=replace(v_fztj,'＆QsRq＆',qsrq);
           v_fztj :=replace(v_fztj,'＆JsRq＆',jsrq);
       end if;

       v_tj:=v_tj||' and '||v_fztj ||' and '||v_scfy;
    END LOOP;

       /* 获取分组列显示名称*/
          v_tj:='select scfy,ajbs,kplb,ajlb,ah,(select aynr from b_ay b where b_ajztxx.laay=b.aydm) as laay,(select aynr from b_ay b where b_ajztxx.jaay=b.aydm) as jaay,to_char(larq,''yyyy-mm-dd'') as larq,to_char(jarq,''yyyy-mm-dd'') as jarq,sjymc,dsrmc,jabdje,qsbdje,
          '|| v_jafs ||' as jafs,(select yhxm from b_yhdm b where b_ajztxx.cbr=b.yhdm and b.scfy=b_ajztxx.scfy) AS CBR,(select ah from b_ysqk where b_ysqk.ajbs=b_ajztxx.ajbs and rownum=1) as ysah,(select cbrmc from B_ajztxx zt where ah=(select ah from b_ysqk where b_ysqk.ajbs=b_ajztxx.ajbs and rownum=1) and rownum=1) as yscbr,(select to_char(gdrq,''yyyy-MM-dd'') from b_ajfzxx where b_ajztxx.ajbs=b_ajfzxx.ajbs) as gdrq,sjslts,spzzcy,fdsxts from b_ajztxx  where '||pttj||v_tj;

   open rt for v_tj;

end P_TJFX_CASE_DETAILE_INFO;
/

