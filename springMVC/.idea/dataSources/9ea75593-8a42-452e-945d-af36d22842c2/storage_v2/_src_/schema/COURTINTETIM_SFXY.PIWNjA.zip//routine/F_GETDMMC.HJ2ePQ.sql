create FUNCTION                   F_GETDMMC(strDM number,strBH varchar2) return varchar2 is
  strMC nvarchar2(200);
  /*根据bh和值获取名称 杨元胜*/
begin
  SELECT MC INTO strMC FROM B_DM  WHERE BH = strBH AND DM=strDM;
  RETURN strMC;
end;

/

