create PROCEDURE P_TJFX_SSYYXXTJ (qsrq varchar2,jsrq varchar2,rt out pkg_row.myRow) AS
/*诉讼语言统计（吴东）
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/

v_scfy varchar2(200);
v_kplb varchar2(100);
v_sls varchar2(200);

BEGIN
   select gsnr into v_scfy  from b_tjfxgs where gsmc='全兵团法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   select gsnr into v_sls  from b_tjfxgs where gsmc='受理数';

   v_sls :=replace(v_sls,'＆QsRq＆',qsrq);
   v_sls :=replace(v_sls,'＆JsRq＆',jsrq);

  INSERT INTO B_TEMPTJFX(DM,MC,XSSX) select dm,fyjx,XSSX+1 from b_fy where dm BETWEEN 4166 and 4208 ORDER by XSSX;

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||'  group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.SLS=B.SL ';--总数

/*维吾尔语*/
  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 2 group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.HYS=B.SL ';--维吾尔语总数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 2 and kplb in(1,2,40,3,45,4,5) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.XSYJ=B.SL ';--维吾尔语刑事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 2 and kplb in(7,8,9,41,44,21,50,12) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.XSWJ=B.SL ';--维吾尔语民事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 2 and kplb in(13,14,15,42,28,47) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JCYJ=B.SL ';--维吾尔语行政数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 2 and kplb in(16) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JCWJ=B.SL ';--维吾尔语执行数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 and kplb in(17,18,29,22,48,49,51,52) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.SJSLTS=B.SL ';--维吾尔语其他数

/*哈萨克语*/
  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.CSS=B.SL ';--哈萨克语总数


  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 and kplb in(1,2,40,3,45,4,5) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.XSJAL=B.SL ';--哈萨克语刑事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 and kplb in(7,8,9,41,44,21,50,12) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JCJAL=B.SL ';--哈萨克语民事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 and kplb in(13,14,15,42,28,47) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JAL=B.SL ';--哈萨克语行政数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 and kplb in(16) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.XS=B.SL ';--哈萨克语执行数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 3 and kplb in(17,18,29,22,48,49,51,52) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JC=B.SL ';--哈萨克语其他数

/*蒙语*/
  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 4 group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.TJS=B.SL ';--蒙语总数


  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 4 and kplb in(1,2,40,3,45,4,5) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJ=B.SL ';--YJ蒙语刑事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 4 and kplb in(7,8,9,41,44,21,50,12) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.WJ=B.SL ';--蒙语民事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 4 and kplb in(13,14,15,42,28,47) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.WJCSX=B.SL ';--蒙语行政数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 4 and kplb in(16) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJCSX=B.SL ';--蒙语执行数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 4 and kplb in(17,18,29,22,48,49,51,52) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.WJYC=B.SL ';--蒙语其他数


/*维汉双语*/
 execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 6  group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.TCS=B.SL ';--维汉双语总数

 execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 6 and kplb in(1,2,40,3,45,4,5) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJYC=B.SL ';--维汉双语刑事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 6 and kplb in(7,8,9,41,44,21,50,12) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.WJZZ=B.SL ';--维汉双语民事数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 6 and kplb in(13,14,15,42,28,47) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJZZ=B.SL ';--维汉双语行政数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 6 and kplb in(16) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJKT=B.SL ';--维汉双语执行数

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(1) AS SL,SCFY FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_sls ||' AND ssyy = 6 and kplb in(17,18,29,22,48,49,51,52) group by SCFY)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.SXNSJ=B.SL ';--维汉双语其他数

     INSERT INTO B_TEMPTJFX(MC,SLS,HYS,XSYJ,XSWJ,JCYJ,JCWJ,SJSLTS,CSS,XSJAL,JCJAL,JAL,XS,JC,TJS,YJ,WJ,WJCSX,YJCSX,WJYC,TCS,YJYC,WJZZ,YJZZ,YJKT,SXNSJ,XSSX)
     select '小计',SUM(SLS),SUM(HYS),SUM(XSYJ),SUM(XSWJ),SUM(JCYJ),SUM(JCWJ),SUM(SJSLTS),SUM(CSS),SUM(XSJAL),SUM(JCJAL),SUM(JAL),SUM(XS),SUM(JC),SUM(TJS),SUM(YJ),SUM(WJ),SUM(WJCSX),SUM(YJCSX),SUM(WJYC),SUM(TCS),SUM(YJYC),SUM(WJZZ),SUM(YJZZ),SUM(YJKT),SUM(SXNSJ),min(xssx)-1 from B_TEMPTJFX;

  open rt for SELECT * FROM B_TEMPTJFX ORDER by XSSX;
END P_TJFX_SSYYXXTJ;
/

