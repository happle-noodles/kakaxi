create view V_MSTS_BB_AJXX as
  select AJBS,KPLB,AH,to_char(LARQ,'yyyy"年"MM"月"dd"日"')LARQ,to_char(JARQ,'yyyy"年"MM"月"dd"日"')JARQ,(select AYNR  from B_AY where AYDM=B_AJZTXX.LAAY)LAAY,
(select to_char(LAYJRQ,'yyyy"年"MM"月"dd"日"')YJSPTRQ from B_LAYJHTAQK where SFBZ=(select MAX(SFBZ) from B_LAYJHTAQK where  AJBS=B_AJZTXX.AJBS))YJSPTRQ,(select TSMC from B_TSDM where TSDM=B_AJZTXX.CBSPT AND SCFY=B_AJZTXX.SCFY)CBSPT,
(select YHXM from B_YHDM where YHDM=B_AJZTXX.CBR AND SCFY=B_AJZTXX.SCFY)JSR,(select (select YHXM from B_YHDM where YHDM=B_SPZZCY.YCY and SCFY=B_AJZTXX.SCFY)SPY from B_SPZZCY where SFBZ=(select MAX(SFBZ) from B_SPZZCY where JS=3 AND AJBS=B_AJZTXX.AJBS))SPZ,
(select YHXM from B_YHDM where YHDM=B_AJZTXX.CBR AND SCFY=B_AJZTXX.SCFY)CBR,(SELECT WMSYS.WM_CONCAT((SELECT YHXM FROM B_YHDM WHERE SCFY=B_AJZTXX.SCFY AND YHDM=B_SPZZCY.YCY)) FROM B_SPZZCY WHERE AJBS=B_AJZTXX.AJBS AND JS IN(3,4,5,6,7) AND YCY<>B_AJZTXX.CBR) AS HYTQTCY,SJYMC AS SJY,(select (select MC from B_YASTML where XH=B_HBQK.HBSQR AND SCFY=B_HBQK.SCFY AND AJBS=B_HBQK.AJBS) from B_HBQK where SFBZ=(select max(SFBZ) from B_HBQK where B_HBQK.AJBS=B_AJZTXX.AJBS))HBSQR,
(select HBYY from B_HBQK where SFBZ=(select max(SFBZ) from B_HBQK where B_HBQK.AJBS=B_AJZTXX.AJBS))HBYY,
(select (select MC from B_DM where BH='GF2009-01015' AND DM=B_HBQK.HBJG)HBJG from B_HBQK where SFBZ=(select max(SFBZ) from B_HBQK where B_HBQK.AJBS=B_AJZTXX.AJBS))HBJG,FDSXTS,SJSLTS AS SLTS,
(SELECT MC FROM B_DM where BH='GF2009-01048' AND DM=B_AJZTXX.CSXYY)CSXYY,CSXTS,to_char((select CBRBPRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')CBRBPRQ,to_char((select SPZSQRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')SPZSQRQ,to_char((select TZSQRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')TZSQRQ,
to_char((select YZSQRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')YZSQRQ,
--(select to_char(TLRQ,'yyyy"年"MM"月"dd"日"') AS SWHJDRQ from B_SWHTL where SFBZ=(select MAX(SFBZ) from B_SWHTL where  AJBS=B_AJZTXX.AJBS))SWHJDRQ,
to_char((select SWHJDRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')SWHJDRQ,
to_char((select YZQFRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')YZQFRQ,(select to_char(PYRQ,'yyyy"年"MM"月"dd"日"') AS HYTHYRQ from B_AJPY where SFBZ=(select MAX(SFBZ) from B_AJPY where  AJBS=B_AJZTXX.AJBS))HYTHYRQ,
(select MC from B_DM where BH='GF2009-03511' AND DM=B_AJZTXX.JAFS)JAFS,(select to_char(SDRQ,'yyyy"年"MM"月"dd"日"') from B_SDJL where SFBZ=(select MAX(SFBZ) from B_SDJL where AJBS=B_AJZTXX.AJBS AND  WSLB=1))CPWSSDSJ,
(select (select YHXM from B_YHDM where YHDM=B_SDJL.SDR AND SCFY=B_SDJL.SCFY) from B_SDJL where SFBZ=(select MAX(SFBZ) from B_SDJL where AJBS=B_AJZTXX.AJBS AND  WSLB=1)) CPWSSDSDR,(select AYNR  from B_AY where AYDM=B_AJZTXX.JAAY)JAAY,JABDJE/10000 AS JABDJE,
(select JABZ from B_AJFZXX where AJBS=B_AJZTXX.AJBS)JABZ,to_char((select SDSZRQ from B_AJFZXX where AJBS=B_AJZTXX.AJBS),'yyyy"年"MM"月"dd"日"')SDSQRQ,SQBDJE/10000 AS SQBDJE,(select MC from B_DM where BH='GF2009-03006' AND DM=B_AJZTXX.AJSJ)AJSJ,
(select MC from B_DM where BH='GF2009-03506' AND DM=B_AJZTXX.SCYJ)SCYJ,(select MC from B_DM where BH='GF2009-02205' AND DM=B_AJZTXX.SPYJ)SPYJ,
(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SCR AND SCFY=B_AJZTXX.SCFY)SCR,to_char(SCRQ,'yyyy"年"MM"月"dd"日"')SCRQ,
(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SPR AND SCFY=B_AJZTXX.SCFY)SPR,to_char(LASPRQ,'yyyy"年"MM"月"dd"日"')SPRQ,AJSLF AS YSSLF,(select YJJE from B_SSFCDQK where SFBZ=(select MAX(SFBZ) from B_SSFCDQK where AJBS=B_AJZTXX.AJBS))YJJE,
(select to_char(YJRQ,'yyyy"年"MM"月"dd"日"') from B_SSFCDQK where SFBZ=(select MAX(SFBZ) from B_SSFCDQK where AJBS=B_AJZTXX.AJBS))YJRQ,(select SUM(SQJJJE) from B_SSFSFJZQK  where SQJZLX=1 AND AJBS=B_AJZTXX.AJBS)MJJE,
(select SUM(SQJJJE) from B_SSFSFJZQK  where SQJZLX=2 AND AJBS=B_AJZTXX.AJBS)JJJE,(select SUM(SQJJJE) from B_SSFSFJZQK  where SQJZLX=3 AND AJBS=B_AJZTXX.AJBS)HJJE,
((select SUM(JE) from B_SSFJNJL where AJBS=B_AJZTXX.AJBS AND TF=2)-NVL((select SUM(JE) from B_SSFJNJL where TF=1 and AJBS=B_AJZTXX.AJBS),0)) AS SSSLF,(select (select MC from B_DM where BH='GF2009-01099' AND DM=B_SSFSFJZQK.JJDX) from B_SSFSFJZQK  where SFBZ=(select MAX(SFBZ) from B_SSFSFJZQK where AJBS=B_AJZTXX.AJBS))JJDX,
(select LABZ from B_AJFZXX where AJBS=B_AJZTXX.AJBS)LABZ,(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SADJR AND SCFY=B_AJZTXX.SCFY)LAR,(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SPR AND SCFY=B_AJZTXX.SCFY)LATTZ,
(select to_char(GGRQ,'yyyy"年"MM"月"dd"日"') from B_SDJL where SFBZ=(select MAX(SFBZ) from B_SDJL where AJBS=B_AJZTXX.AJBS))GGRQ
 from B_AJZTXX where KPLB=21
/

