create PROCEDURE YDAJSJQk2017(nscfy number,qsrq varchar2,jsrq varchar2,ndqsrq varchar2,ndjsrq varchar2, rt out pkg_row.myRow) as
v_xstj varchar2(200);
v_jctj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);

v_ndxstj varchar2(200);
v_ndjctj varchar2(200);
v_ndyjtj varchar2(200);
v_ndwjtj varchar2(200);


v_scfy varchar2(200);
v_kplb varchar2(100);

v_qnxstj varchar2(200);
v_qnqsrq varchar(20);
v_qnjsrq varchar(20);

v_ndqnxstj varchar2(200);
v_ndqnqsrq varchar(20);
v_ndqnjsrq varchar(20);

v_qttj varchar2(500);
v_qttj1 varchar2(800);

BEGIN
  v_qnqsrq:=to_char(add_months(to_date(qsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');
  v_qnjsrq:=to_char(add_months(to_date(jsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');

  v_ndqnqsrq:=to_char(add_months(to_date(ndqsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');
  v_ndqnjsrq:=to_char(add_months(to_date(ndjsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');

   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_qnxstj:=v_xstj;
   v_ndxstj :=v_xstj;
   v_ndjctj :=v_jctj;
   v_ndyjtj :=v_yjtj;
   v_ndwjtj :=v_wjtj;
   v_ndqnxstj :=v_xstj;
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);

   v_ndxstj :=replace(v_ndxstj,'＆QsRq＆',ndqsrq);
   v_ndxstj :=replace(v_ndxstj,'＆JsRq＆',ndjsrq);
   v_ndjctj :=replace(v_ndjctj,'＆QsRq＆',ndqsrq);
   v_ndyjtj :=replace(v_ndyjtj,'＆QsRq＆',ndqsrq);
   v_ndyjtj :=replace(v_ndyjtj,'＆JsRq＆',ndjsrq);
   v_ndwjtj :=replace(v_ndwjtj,'＆JsRq＆',ndjsrq);

   v_qnxstj :=replace(v_qnxstj,'＆QsRq＆',v_qnqsrq);
   v_qnxstj :=replace(v_qnxstj,'＆JsRq＆',v_qnjsrq);

   v_ndqnxstj :=replace(v_ndqnxstj,'＆QsRq＆',v_ndqnqsrq);
   v_ndqnxstj :=replace(v_ndqnxstj,'＆JsRq＆',v_ndqnjsrq);

   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);

INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('立案一庭',6,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('立案二庭',18,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('刑庭',1,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民一庭',2,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民二庭',3,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民三庭',23,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('行政庭',4,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('赔偿办',9,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('审监一庭',7,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('审监二庭',19,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('执行庭',255,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('研究室',11,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('合计',-1,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('减刑',-2,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('待分案',-3,0);
/*
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('立案一庭',6,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('立案二庭',18,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('刑庭',1,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民一庭',2,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民二庭',3,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民三庭',23,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('行政庭',4,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('赔偿办',9,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('审监一庭',7,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('审监二庭',19,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('执行庭',255,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('研究室',11,0);

*/
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_xstj||' AND '||v_scfy||' AND '||v_kplb||' AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.XS=B.SL WHERE AJLX=1';--今年一般案件新收数

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnxstj||' AND '||v_scfy||' AND '||v_kplb||' AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNXS=B.SL WHERE AJLX=1';--去年一般案件新收数

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' AND '||v_kplb||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.JC=B.SL WHERE AJLX=1';--今年一般案件旧存数

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.YJ=B.SL WHERE AJLX=1';--今年一般案件已结数

     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.WJ=B.SL WHERE AJLX=1';--今年一般案件未结数

   --待分案
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_xstj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.XS=B.SL WHERE AJLX=0';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.JC=B.SL WHERE AJLX=0';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.YJ=B.SL WHERE AJLX=0';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.WJ=B.SL WHERE AJLX=0';


   select gsnr into v_qttj  from b_tjfxgs where gsmc='改判数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.GP=B.SL WHERE AJLX=1';--今年一般案件改判数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
   select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.TC=B.SL WHERE AJLX=1';--今年一般案件调撤数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='发回重审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.FH=B.SL WHERE AJLX=1';--今年一般案件发回重审数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='维持数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.WC=B.SL WHERE AJLX=1';--今年一般案件维持数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='判决数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.PJ=B.SL WHERE AJLX=1';--今年一般案件判决数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='驳回数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.BH=B.SL WHERE AJLX=1';--今年一般案件驳回数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='再审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.ZS=B.SL WHERE AJLX=1';--今年一般案件再审数



   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndxstj||' AND '||v_scfy||' AND '||v_kplb||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDXS=B.SL WHERE AJLX=1';--年度一般案件新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndqnxstj||' AND '||v_scfy||' AND '||v_kplb||' AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNNDXS=B.SL WHERE AJLX=1';--去年年度一般案件新收数
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' AND '||v_kplb||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDJC=B.SL WHERE AJLX=1';--年度一般案件旧存数
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDYJ=B.SL WHERE AJLX=1';--年度一般案件已结数
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' AND '||v_kplb||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDWJ=B.SL WHERE AJLX=1';--年度一般案件未结数

      --待分案
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_ndxstj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDXS=B.SL WHERE AJLX=0';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDJC=B.SL WHERE AJLX=0';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDYJ=B.SL WHERE AJLX=0';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,-3 as CBSPT FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' AND '||v_kplb||' and  CBSPT is null)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDWJ=B.SL WHERE AJLX=0';


   select gsnr into v_qttj  from b_tjfxgs where gsmc='改判数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDGP=B.SL WHERE AJLX=1';--年度一般案件改判数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
   select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND ('|| v_qttj ||' or '|| v_qttj1 ||')  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDTC=B.SL WHERE AJLX=1';--年度一般案件调撤数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='发回重审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDFH=B.SL WHERE AJLX=1';--年度一般案件发回重审数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='维持数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDWC=B.SL WHERE AJLX=1';--年度一般案件维持数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='判决数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDPJ=B.SL WHERE AJLX=1';--年度一般案件判决数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='驳回数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDBH=B.SL WHERE AJLX=1';--年度一般案件驳回数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='再审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDZS=B.SL WHERE AJLX=1';--年度一般案件再审数

   --update B_TEMPYJAQKTJ SET NDQT=NDYJ-NVL(NDGP,0)-NVL(NDTC,0)-NVL(NDFH,0)-NVL(NDWC,0)-NVL(NDPJ,0) -NVL(NDBH,0) -NVL(NDZS,0) WHERE NDYJ>0; --年度其他
   --UPDATE B_TEMPYJAQKTJ SET NDXSTB=round((NDXS-QNNDXS)*100.0/QNNDXS,2) WHERE QNNDXS>0 ;--年度新收同比
   --UPDATE B_TEMPYJAQKTJ SET NDJAL=ROUND(YJ*100.0/(NDYJ+NDWJ),2) WHERE (NDYJ+NDWJ)>0;--年度结案率
   --UPDATE B_TEMPYJAQKTJ SET NDTCL=ROUND(TC*100.0/NDYJ,2) WHERE NDYJ>0 and AJLX=1;--年度调撤率

   --特殊处理

   --执行局处理
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_xstj||' AND '||v_scfy ||' AND '||v_kplb||'  AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.XS=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般案件新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnxstj||' AND '||v_scfy ||' AND '||v_kplb||' AND KPLB<>4 and CBSPT in(5,21,24) )B ON(A.BMBS=255) when matched then update set A.QNXS=B.SL WHERE AJLX=1 AND BMBS=255';--去年执行局一般新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy ||' AND '||v_kplb||'  AND KPLB<>4 and CBSPT in(5,21,24) )B ON(A.BMBS=255) when matched then update set A.JC=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy ||' AND '||v_kplb||'  AND KPLB<>4 and CBSPT in(5,21,24) )B ON(A.BMBS=255) when matched then update set A.YJ=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy ||' AND '||v_kplb||'  AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.WJ=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般未结数




   select gsnr into v_qttj  from b_tjfxgs where gsmc='改判数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.GP=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件改判数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
   select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND ('|| v_qttj ||' or '|| v_qttj1 ||')   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.TC=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件调撤数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='发回重审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.FH=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件发回重审数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='维持数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.WC=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件维持数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='判决数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||' AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.PJ=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件判决数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='驳回数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.BH=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件驳回数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='再审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.ZS=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件再审数

   update B_TEMPYJAQKTJ SET QT=YJ-NVL(GP,0)-NVL(TC,0)-NVL(FH,0)-NVL(WC,0)-NVL(PJ,0) -NVL(BH,0) -NVL(ZS,0) WHERE YJ>0; --今年其他
   UPDATE B_TEMPYJAQKTJ SET XSTB=round((XS-QNXS)*100.0/QNXS,2) WHERE QNXS>0 ;--新收同比
   UPDATE B_TEMPYJAQKTJ SET JAL=ROUND(YJ*100.0/(YJ+WJ),2) WHERE (YJ+WJ)>0;--结案率
   UPDATE B_TEMPYJAQKTJ SET TCL=ROUND(TC*100.0/YJ,2) WHERE YJ>0 and AJLX=1;--调撤率

   --执行局年度计算
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndxstj||' AND '||v_scfy ||' AND '||v_kplb||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDXS=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般案件新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndqnxstj||' AND '||v_scfy ||' AND '||v_kplb||'   AND KPLB<>4 and CBSPT in(5,21,24) )B ON(A.BMBS=255) when matched then update set A.QNNDXS=B.SL WHERE AJLX=1 AND BMBS=255';--去年执行局一般新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy ||' AND '||v_kplb||'  AND KPLB<>4 and CBSPT in(5,21,24) )B ON(A.BMBS=255) when matched then update set A.NDJC=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy ||' AND '||v_kplb||'   AND KPLB<>4 and CBSPT in(5,21,24) )B ON(A.BMBS=255) when matched then update set A.NDYJ=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy ||' AND '||v_kplb||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDWJ=B.SL WHERE AJLX=1 AND BMBS=255';--今年执行局一般未结数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='改判数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDGP=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件改判数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
   select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND ('|| v_qttj ||' or '|| v_qttj1 ||')  AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDTC=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件调撤数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='发回重审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDFH=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件发回重审数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='维持数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDWC=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件维持数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='判决数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDPJ=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件判决数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='驳回数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'  AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDBH=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件驳回数

   select gsnr into v_qttj  from b_tjfxgs where gsmc='再审数';
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' AND '|| v_qttj ||'   AND KPLB<>4 and CBSPT in(5,21,24))B ON(A.BMBS=255) when matched then update set A.NDZS=B.SL WHERE AJLX=1 AND BMBS=255';--今年一般案件再审数

 update B_TEMPYJAQKTJ SET NDQT=NDYJ-NVL(NDGP,0)-NVL(NDTC,0)-NVL(NDFH,0)-NVL(NDWC,0)-NVL(NDPJ,0) -NVL(NDBH,0) -NVL(NDZS,0) WHERE NDYJ>0; --年度其他
   UPDATE B_TEMPYJAQKTJ SET NDXSTB=round((NDXS-QNNDXS)*100.0/QNNDXS,2) WHERE QNNDXS>0 ;--年度新收同比
   UPDATE B_TEMPYJAQKTJ SET NDJAL=ROUND(NDYJ*100.0/(NDYJ+NDWJ),2) WHERE (NDYJ+NDWJ)>0;--年度结案率
   UPDATE B_TEMPYJAQKTJ SET NDTCL=ROUND(NDTC*100.0/NDYJ,2) WHERE NDYJ>0 and AJLX=1;--年度调撤率

   --减刑假释计算
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_xstj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7)B ON(A.BMBS=-2) when matched then update set A.XS=B.SL WHERE AJLX=1 AND BMBS=-2';--今年减刑假释新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnxstj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.QNXS=B.SL WHERE AJLX=1 AND BMBS=-2';--去年减刑假释新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.JC=B.SL WHERE AJLX=1 AND BMBS=-2';--今年减刑假释旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.YJ=B.SL WHERE AJLX=1 AND BMBS=-2';--今年减刑假释已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7)B ON(A.BMBS=-2) when matched then update set A.WJ=B.SL WHERE AJLX=1 AND BMBS=-2';--今年减刑假释未结数
   update B_TEMPYJAQKTJ SET QT=YJ WHERE AJLX=1 AND BMBS=-2;--减刑假释其他结案方式
   UPDATE B_TEMPYJAQKTJ SET XSTB=round((XS-QNXS)*100.0/QNXS,2) WHERE QNXS>0 and AJLX=1 AND BMBS=-2 ;--减刑假释新收同比
   UPDATE B_TEMPYJAQKTJ SET JAL=ROUND(YJ*100.0/(YJ+WJ),2) WHERE (YJ+WJ)>0 and AJLX=1 AND BMBS=-2;--减刑假释结案率
   --减刑假释年度计算
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndxstj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7)B ON(A.BMBS=-2) when matched then update set A.NDXS=B.SL WHERE AJLX=1 AND BMBS=-2';--年度减刑假释新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndqnxstj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.QNNDXS=B.SL WHERE AJLX=1 AND BMBS=-2';--年度去年减刑假释新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.NDJC=B.SL WHERE AJLX=1 AND BMBS=-2';--年度减刑假释旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.NDYJ=B.SL WHERE AJLX=1 AND BMBS=-2';--年度减刑假释已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' and KPLB=4 and CBSPT=7 )B ON(A.BMBS=-2) when matched then update set A.NDWJ=B.SL WHERE AJLX=1 AND BMBS=-2';--年度减刑假释未结数
   update B_TEMPYJAQKTJ SET NDQT=NDYJ WHERE AJLX=1 AND BMBS=-2;--年度减刑假释其他结案方式
   UPDATE B_TEMPYJAQKTJ SET NDXSTB=round((NDXS-QNNDXS)*100.0/QNNDXS,2) WHERE QNNDXS>0 and AJLX=1 AND BMBS=-2 ;--年度减刑假释新收同比
   UPDATE B_TEMPYJAQKTJ SET NDJAL=ROUND(NDYJ*100.0/(NDYJ+NDWJ),2) WHERE (NDYJ+NDWJ)>0 and AJLX=1 AND BMBS=-2;--年度减刑假释结案率

   UPDATE B_TEMPYJAQKTJ SET XS=(SELECT SUM(NVL(XS,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET QNXS=(SELECT SUM(NVL(QNXS,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET JC=(SELECT SUM(NVL(JC,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET GP=(SELECT SUM(NVL(GP,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET TC=(SELECT SUM(NVL(TC,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET FH=(SELECT SUM(NVL(FH,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET WC=(SELECT SUM(NVL(WC,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET PJ=(SELECT SUM(NVL(PJ,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET BH=(SELECT SUM(NVL(BH,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET ZS=(SELECT SUM(NVL(ZS,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET YJ=(SELECT SUM(NVL(YJ,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET WJ=(SELECT SUM(NVL(WJ,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   update B_TEMPYJAQKTJ SET QT=YJ-NVL(GP,0)-NVL(TC,0)-NVL(FH,0)-NVL(WC,0)-NVL(PJ,0) -NVL(BH,0) -NVL(ZS,0) WHERE YJ>0 AND BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET XSTB=round((XS-QNXS)*100.0/QNXS,2) WHERE QNXS>0 AND BMBS=-1 AND AJLX=1 ;
   UPDATE B_TEMPYJAQKTJ SET JAL=ROUND(YJ*100.0/(YJ+WJ),2) WHERE (YJ+WJ)>0 AND BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET TCL=ROUND(TC*100.0/YJ,2) WHERE YJ>0  AND BMBS=-1 AND AJLX=1;

   UPDATE B_TEMPYJAQKTJ SET NDXS=(SELECT SUM(NVL(NDXS,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET QNNDXS=(SELECT SUM(NVL(QNNDXS,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDJC=(SELECT SUM(NVL(NDJC,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDGP=(SELECT SUM(NVL(NDGP,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDTC=(SELECT SUM(NVL(NDTC,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDFH=(SELECT SUM(NVL(NDFH,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDWC=(SELECT SUM(NVL(NDWC,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDPJ=(SELECT SUM(NVL(NDPJ,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDBH=(SELECT SUM(NVL(NDBH,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDZS=(SELECT SUM(NVL(NDZS,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDYJ=(SELECT SUM(NVL(NDYJ,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDWJ=(SELECT SUM(NVL(NDWJ,0)) FROM B_TEMPYJAQKTJ) WHERE BMBS=-1 AND AJLX=1;
   update B_TEMPYJAQKTJ SET NDQT=NDYJ-NVL(NDGP,0)-NVL(NDTC,0)-NVL(NDFH,0)-NVL(NDWC,0)-NVL(NDPJ,0) -NVL(NDBH,0) -NVL(NDZS,0) WHERE NDYJ>0 AND BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDXSTB=round((NDXS-QNNDXS)*100.0/QNNDXS,2) WHERE QNNDXS>0 AND BMBS=-1 AND AJLX=1 ;
   UPDATE B_TEMPYJAQKTJ SET NDJAL=ROUND(NDYJ*100.0/(NDYJ+NDWJ),2) WHERE (NDYJ+NDWJ)>0 AND BMBS=-1 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDTCL=ROUND(NDTC*100.0/NDYJ,2) WHERE NDYJ>0 and BMBS=-1 AND AJLX=1;


   UPDATE B_TEMPYJAQKTJ SET XS=(SELECT SUM(NVL(XS,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET QNXS=(SELECT SUM(NVL(QNXS,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET JC=(SELECT SUM(NVL(JC,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET GP=(SELECT SUM(NVL(GP,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET TC=(SELECT SUM(NVL(TC,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET FH=(SELECT SUM(NVL(FH,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET WC=(SELECT SUM(NVL(WC,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET PJ=(SELECT SUM(NVL(PJ,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET BH=(SELECT SUM(NVL(BH,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET ZS=(SELECT SUM(NVL(ZS,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET YJ=(SELECT SUM(NVL(YJ,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET WJ=(SELECT SUM(NVL(WJ,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   update B_TEMPYJAQKTJ SET QT=YJ-NVL(GP,0)-NVL(TC,0)-NVL(FH,0)-NVL(WC,0)-NVL(PJ,0) -NVL(BH,0) -NVL(ZS,0) WHERE YJ>0 AND BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET XSTB=round((XS-QNXS)*100.0/QNXS,2) WHERE QNXS>0 AND BMBS=7 AND AJLX=1 ;
   UPDATE B_TEMPYJAQKTJ SET JAL=ROUND(YJ*100.0/(YJ+WJ),2) WHERE (YJ+WJ)>0 AND BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET TCL=ROUND(TC*100.0/YJ,2) WHERE YJ>0  AND BMBS=7 AND AJLX=1;

   UPDATE B_TEMPYJAQKTJ SET NDXS=(SELECT SUM(NVL(NDXS,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET QNNDXS=(SELECT SUM(NVL(QNNDXS,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDJC=(SELECT SUM(NVL(NDJC,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDGP=(SELECT SUM(NVL(NDGP,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDTC=(SELECT SUM(NVL(NDTC,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDFH=(SELECT SUM(NVL(NDFH,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDWC=(SELECT SUM(NVL(NDWC,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDPJ=(SELECT SUM(NVL(NDPJ,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDBH=(SELECT SUM(NVL(NDBH,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDZS=(SELECT SUM(NVL(NDZS,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDYJ=(SELECT SUM(NVL(NDYJ,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDWJ=(SELECT SUM(NVL(NDWJ,0)) FROM B_TEMPYJAQKTJ where BMBS in(7,18)) WHERE BMBS=7 AND AJLX=1;
   update B_TEMPYJAQKTJ SET NDQT=NDYJ-NVL(NDGP,0)-NVL(NDTC,0)-NVL(NDFH,0)-NVL(NDWC,0)-NVL(NDPJ,0) -NVL(NDBH,0) -NVL(NDZS,0) WHERE NDYJ>0 AND BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDXSTB=round((NDXS-QNNDXS)*100.0/QNNDXS,2) WHERE QNNDXS>0 AND BMBS=7 AND AJLX=1 ;
   UPDATE B_TEMPYJAQKTJ SET NDJAL=ROUND(NDYJ*100.0/(NDYJ+NDWJ),2) WHERE (NDYJ+NDWJ)>0 AND BMBS=7 AND AJLX=1;
   UPDATE B_TEMPYJAQKTJ SET NDTCL=ROUND(NDTC*100.0/NDYJ,2) WHERE NDYJ>0 and BMBS=7 AND AJLX=1;



   --申诉信访处理
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_xstj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSXS=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSJC=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSYJ=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSWJ=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉未结数
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndxstj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.NDSSXS=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.NDSSJC=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.NDSSYJ=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.NDSSWJ=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉未结数
    --dbms_output.put_line('SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ=1 AND (djsj>=to_date('||qsrq||',''yyyy-mm-dd'') and djsj<=to_date('||jsrq||',''yyyy-mm-dd''))');
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ=1 AND (djsj>=to_date('''||qsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||jsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.XFLX=B.SL WHERE AJLX=1 AND BMBS=-1';--今年信访来信数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ!=1 AND (djsj>=to_date('''||qsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||jsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.XFLF=B.SL WHERE AJLX=1 AND BMBS=-1';--今年信访来访数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ=1 AND (djsj>=to_date('''||ndqsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||ndjsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.NDXFLX=B.SL WHERE AJLX=1 AND BMBS=-1';--年度信访来信数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ!=1 AND (djsj>=to_date('''||ndqsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||ndjsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.NDXFLF=B.SL WHERE AJLX=1 AND BMBS=-1';--年度信访来访数
   update B_TEMPYJAQKTJ set XF=(NVL(XFLX,0)+NVL(XFLF,0)) WHERE AJLX=1 AND BMBS=-1;
   update B_TEMPYJAQKTJ set NDXF=(NVL(NDXFLX,0)+NVL(NDXFLF,0)) WHERE AJLX=1 AND BMBS=-1;
   open rt for select * from B_TEMPYJAQKTJ;
END YDAJSJQk2017;
/

