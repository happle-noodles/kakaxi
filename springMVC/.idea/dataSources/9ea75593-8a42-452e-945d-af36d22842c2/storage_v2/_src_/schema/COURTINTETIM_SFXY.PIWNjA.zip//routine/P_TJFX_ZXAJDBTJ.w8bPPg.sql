create PROCEDURE                   P_TJFX_ZXAJDBTJ(fytj varchar2,jnsjqj varchar2,qnsjqj varchar2, rt out pkg_row.myRow) as
/*月结案情况 杨元胜
fytj 查询法院
jnsjqj 今年时间区间
qnsjqj 去年时间区间
rt   返回数据集
*/
v_scfy varchar2(200);
BEGIN
 v_scfy:='B_TJHZ.cjfy=b_fy.dm and b_fy.dm between 4166 and 4208 and '|| fytj;

insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'合计',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'新收',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'旧存',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'自动履行',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'执行和解',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'不予执行',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'强制执行',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'终结',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'其他',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'结案合计',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'执结率',-1,0,0 from dual;

--执行合计案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''合计'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''合计'') when matched then update set A.QNSLS=B.SLS';

--执行新收案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(XSS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''新收'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(XSS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''新收'') when matched then update set A.QNSLS=B.SLS';

--执行旧存案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(JCS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''旧存'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(JCS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''旧存'') when matched then update set A.QNSLS=B.SLS';

--执行自动履行案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(ZDLXS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''自动履行'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(ZDLXS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''自动履行'') when matched then update set A.QNSLS=B.SLS';

--执行执行和解案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(ZXHJS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''执行和解'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(ZXHJS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''执行和解'') when matched then update set A.QNSLS=B.SLS';

--执行不予执行案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(BYZXS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''不予执行'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(BYZXS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''不予执行'') when matched then update set A.QNSLS=B.SLS';

--执行强制执行案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(QZZXS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''强制执行'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(QZZXS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''强制执行'') when matched then update set A.QNSLS=B.SLS';

--执行终结案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(ZJS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''终结'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(ZJS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''终结'') when matched then update set A.QNSLS=B.SLS';

--执行其他数
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(YJS,0)-NVL(ZDLXS,0)-NVL(ZXHJS,0)-NVL(BYZXS,0)-NVL(QZZXS,0)-NVL(ZJS,0)) AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''其他'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(YJS,0)-NVL(ZDLXS,0)-NVL(ZXHJS,0)-NVL(BYZXS,0)-NVL(QZZXS,0)-NVL(ZJS,0)) AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''其他'') when matched then update set A.QNSLS=B.SLS';

--执行结案合计案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(YJS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''结案合计'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(YJS)AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''结案合计'') when matched then update set A.QNSLS=B.SLS';

--执行执结率
execute immediate 'merge into b_tempaytj A
    using(SELECT round(100*SUM(YJS)/SUM(NVL(XSS,0)+NVL(JCS,0)),2) AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''执结率'') when matched then update set A.JNSLS=B.SLS';
execute immediate 'merge into b_tempaytj A
    using(SELECT round(100*SUM(YJS)/SUM(NVL(XSS,0)+NVL(JCS,0)),2) AS SLS FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=16 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''执结率'') when matched then update set A.QNSLS=B.SLS';

  -- open rt for select * from b_tempaytj;
   open rt for select * from b_tempaytj WHERE (JNSLS>0 OR QNSLS>0);
END P_TJFX_ZXAJDBTJ;

/

