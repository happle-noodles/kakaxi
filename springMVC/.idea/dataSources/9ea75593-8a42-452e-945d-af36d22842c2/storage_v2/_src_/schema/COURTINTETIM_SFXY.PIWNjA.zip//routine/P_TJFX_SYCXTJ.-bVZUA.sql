create PROCEDURE P_TJFX_SYCXTJ(nscfy number,qsrq varchar2,jsrq varchar2,ntsdm number,rt out pkg_row.myRow) as
/*部门统计分析 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_ycaj varchar2(100);
v_csx  varchar2(200);
v_sxnsj varchar2(300);
v_fztj  varchar2(200);
v_tsdm  varchar2(50);
begin

   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别'; 
   select gsnr into v_tsdm   from b_tjfxgs where gsmc='承办部门A';

 
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
 
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   v_csx :=replace(v_csx,'＆JsRq＆',jsrq);
   
   v_fztj:='A.KPLB=B.FZKPLB ';
   if ntsdm=0 then
     v_tsdm:='1=1';
   else
     v_tsdm:=replace(v_tsdm,'＆CbSpt＆',ntsdm);
    end if;
    v_scfy :=v_scfy||' and  ' || v_tsdm;


   INSERT INTO B_TEMPTJFX(KPLB,MC) SELECT A.KPLB,A.MC FROM B_kplb A WHERE KPLB IN(1,7,13);
   
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE '||v_scfy||' AND '|| v_kplb||' AND '  || v_yjtj || ' AND NVL(SYCX,1)=2 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB) when matched then update set A.XSYJ=B.SL';--已结普通程序
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE '||v_scfy||' AND '|| v_kplb||' AND '  || v_yjtj || ' AND NVL(SYCX,1)<>2 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB) when matched then update set A.JCYJ=B.SL';--已结简易程序
    
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE '||v_scfy||' AND '|| v_kplb||' AND '  || v_wjtj || ' AND NVL(SYCX,1)=2 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB) when matched then update set A.XSWJ=B.SL';--未结普通程序
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE '||v_scfy||' AND '|| v_kplb||' AND '  || v_wjtj || ' AND NVL(SYCX,1)<>2 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB) when matched then update set A.JCWJ=B.SL';--未结简易程序

   UPDATE B_TEMPTJFX  SET YJ=XSYJ+XSWJ;
   UPDATE B_TEMPTJFX  SET WJ=JCYJ+JCWJ;
   insert into B_TEMPTJFX(KPLB,MC) SELECT 100,'合计' FROM dual;
   execute immediate ' merge into B_TEMPTJFX  A
    using( select sum(xsyj) as xsyj,sum(xswj) as xswj,sum(jcyj) as jcyj,sum(jcwj) as jcwj,sum(yj) as yj,sum(wj) as wj from B_TEMPTJFX) B
    ON(A.KPLB=100) WHEN  matched then update set A.XSYJ=B.XSYJ, A.XSWJ=B.XSWJ, A.JCYJ=B.JCYJ, A.JCWJ=B.JCWJ, A.YJ=B.YJ, A.WJ=B.WJ';
  
   open rt for SELECT KPLB,MC,XSYJ,XSWJ,JCYJ,JCWJ,YJ,WJ FROM  B_TEMPTJFX  ORDER BY KPLB;
end P_TJFX_SYCXTJ;
/

