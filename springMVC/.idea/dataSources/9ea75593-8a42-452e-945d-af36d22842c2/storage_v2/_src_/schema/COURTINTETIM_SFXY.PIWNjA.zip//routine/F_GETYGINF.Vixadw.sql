create function f_GetYgInf(nKplb number,nAjbs number) return varchar2 is
strYg varchar2(2000);
begin
   if(nKplb=1) then
     begin
       select to_char(wm_concat(yg)) into strYg from (
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw1 in(1,2,3)))) as yg from B_XSBHR where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr and ssdw1 in(1,2,3))))as yg from b_xszsr where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr and ssdw1 in(1,2,3))))as yg from B_FDMSSSDSR where ajbs=nAjbs);
     end;
     elsif (nKplb=2) then
       begin
          select to_char(wm_concat(yg)) into strYg from (
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw2 in(1,2,4,5)))) as yg from B_XSBHR where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr and ssdw2 in(1,2,4,5))))as yg from b_xszsr where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr and ssdw2 in(1,2,4,5))))as yg from B_FDMSSSDSR where ajbs=nAjbs);
       end;
     elsif (nKplb=3) then
       begin
          select to_char(wm_concat(yg)) into strYg from (
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw3 in(1)))) as yg from B_XSBHR where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr and ssdw3 in(1))))as yg from b_xszsr where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr and ssdw3 in(1))))as yg from B_FDMSSSDSR where ajbs=nAjbs);
       end;
       elsif (nKplb=7) then
         begin
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(1,3,4,5,7)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=8) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw2 in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=9) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw3 in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;  
       elsif(nKplb=12) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_ZQR.ajbs and xh=B_ZQR.zqr))) into strYg from B_ZQR where ajbs=nAjbs;
         end;
       elsif (nKplb=21) then  
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3,4,5,7,61,63,71,81,91,101,11,21,31,33,41,43,51,53)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif (nKplb=13) then
         begin
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(1,3,4,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=14) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw2 in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=15) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw3 in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;  
       elsif(nKplb=18) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3,4)))) into strYg from b_dsr where ajbs=nAjbs;
         end;   
       elsif(nKplb=28) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=29) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3)))) into strYg from b_dsr where ajbs=nAjbs;
         end;   
       elsif (nKplb=40 or nKplb=45) then
         begin
            select to_char(wm_concat(yg)) into strYg from (
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw2 in(1,3)))) as yg from B_XSBHR where ajbs=nAjbs
            union
            select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr)))as yg from b_xszsr where ajbs=nAjbs
            union
            select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr)))as yg from B_FDMSSSDSR where ajbs=nAjbs);
         end;
       elsif(nKplb=41 or nKplb=42 or nKplb=43 or nKplb=46 or nKplb=47 or nKplb=57 or nKplb=58 or nKplb=59) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(1,3,4,5,7)))) into strYg from b_dsr where ajbs=nAjbs;
         end;  
       elsif(nKplb=44) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=48) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3,4)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=49) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=50) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=51 or nKplb=52) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(1,3,5,6,8,9,10,11,13,15,17,18)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=54) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(1,3,4,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=55) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw2 in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=56) then 
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw3 in(1,3,5)))) into strYg from b_dsr where ajbs=nAjbs;
         end;
       else
         begin
           strYg :=''; 
         end;  
    end if;
    
    return strYg;
end;
/

