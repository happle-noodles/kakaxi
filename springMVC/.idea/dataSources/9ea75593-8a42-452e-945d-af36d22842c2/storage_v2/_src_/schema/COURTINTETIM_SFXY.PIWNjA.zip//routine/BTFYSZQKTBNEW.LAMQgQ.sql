create PROCEDURE BtFySzQkTbNew(nscfy number,qsrq varchar2,jsrq varchar2, rt out pkg_row.myRow) as
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_ndyjtj varchar2(200);
v_ndwjtj varchar2(200);
v_ndjctj varchar2(200);
v_qntqyjtj varchar2(200);
v_qntqwjtj varchar2(200);
v_qntqjctj varchar2(200);
v_qnndyjtj varchar2(200);
v_qnndwjtj varchar2(200);
v_qnndjctj varchar2(200);

v_qntqqsrq varchar2(200);
v_qntqjsrq varchar2(200);
v_qnndqsrq varchar2(200);
v_qnndjsrq varchar2(200);

v_scfy varchar2(200);
v_kplb varchar2(100);

v_qttj varchar2(500);
v_qttj1 varchar2(500);

v_gdjsrq varchar(200);
v_gdyjtj varchar(200);
v_tcs varchar(1000);
begin
  v_qntqqsrq:=to_char(add_months(to_date(qsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
  v_qntqjsrq:=to_char(add_months(to_date(jsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
  v_qnndqsrq:=to_char(add_months(to_date(qsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
  v_qnndjsrq:=to_char(add_months(to_date(jsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');

  v_gdjsrq :=to_char(add_months(to_timestamp(jsrq,'yyyy-mm-dd'), -1),'yyyy-mm-dd');
  dbms_output.put_line(v_gdjsrq);

  select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
  select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
  select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';
  select gsnr into v_tcs  from b_tjfxgs where gsmc='调撤数';

  /*v_ndyjtj:=v_yjtj;
  v_ndwjtj:=v_wjtj;
  v_ndjctj:=v_jctj;
  v_qntqyjtj:=v_yjtj;
  v_qntqwjtj:=v_wjtj;
  v_qntqjctj:=v_jctj;*/
  v_qnndyjtj:=v_yjtj;
  v_qnndwjtj:=v_wjtj;
  v_qnndjctj:=v_jctj;

  v_gdyjtj:=v_yjtj;

  v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
  v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
  v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
  v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);

  /*v_ndjctj :=replace(v_ndjctj,'＆QsRq＆',ndqsrq);
  v_ndyjtj :=replace(v_ndyjtj,'＆QsRq＆',ndqsrq);
  v_ndyjtj :=replace(v_ndyjtj,'＆JsRq＆',ndjsrq);
  v_ndwjtj :=replace(v_ndwjtj,'＆JsRq＆',ndjsrq);

  v_qntqjctj :=replace(v_qntqjctj,'＆QsRq＆',v_qnndqsrq);
  v_qntqyjtj :=replace(v_qntqyjtj,'＆QsRq＆',v_qnndqsrq);
  v_qntqyjtj :=replace(v_qntqyjtj,'＆JsRq＆',v_qnndjsrq);
  v_qntqwjtj :=replace(v_qntqwjtj,'＆JsRq＆',v_qnndjsrq);*/

  v_qnndjctj :=replace(v_qnndjctj,'＆QsRq＆',v_qnndqsrq);
  v_qnndyjtj :=replace(v_qnndyjtj,'＆QsRq＆',v_qnndqsrq);
  v_qnndyjtj :=replace(v_qnndyjtj,'＆JsRq＆',v_qnndjsrq);
  v_qnndwjtj :=replace(v_qnndwjtj,'＆JsRq＆',v_qnndjsrq);


  v_gdyjtj :=replace(v_gdyjtj,'＆QsRq＆',qsrq);
  v_gdyjtj :=replace(v_gdyjtj,'＆JsRq＆',v_gdjsrq);

  v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);

INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('立案一庭',6,1,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('立案二庭',18,1,2);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('刑庭',1,1,3);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('民一庭',2,1,4);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('民二庭',3,1,5);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('民三庭',23,1,6);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('行政庭',4,1,7);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('赔偿办',9,1,8);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('审监一庭',7,1,9);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('审监二庭',19,1,10);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('执行局',255,1,11);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('合计',-1,1,12);


  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.YJ=B.SL where A.AJLX=1';--已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.WJ=B.SL where A.AJLX=1';--未结数

    dbms_output.put_line(v_qnndyjtj);
    dbms_output.put_line(v_qnndwjtj);
    dbms_output.put_line(v_kplb);
    dbms_output.put_line('merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndwjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.qnwj=B.SL where A.AJLX=1');
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.qnwc=B.SL where A.AJLX=1';--去年已结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndwjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.qnwj=B.SL where A.AJLX=1';--去年未结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT SUM((JARQ-NVL(SXQSRQ,LARQ))-(CASE WHEN NVL(KCTS,0)>3600 THEN 0 ELSE NVL(KCTS,0) END))AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.PJ=B.SL where A.AJLX=1';--审理天数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT SUM((JARQ-NVL(SXQSRQ,LARQ))-(CASE WHEN NVL(KCTS,0)>3600 THEN 0 ELSE NVL(KCTS,0) END))AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.QNPJ=B.SL where A.AJLX=1';--去年审理天数


  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.YJ=B.SL where A.AJLX=1 and A.BMBS=255';--执行局已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.WJ=B.SL where A.AJLX=1 and A.BMBS=255';--执行局未结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.qnwc=B.SL where A.AJLX=1 and A.BMBS=255';--去年执行已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndwjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.qnWJ=B.SL where A.AJLX=1 and A.BMBS=255';--去年执行未结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT SUM((JARQ-NVL(SXQSRQ,LARQ))-(CASE WHEN NVL(KCTS,0)>3600 THEN 0 ELSE NVL(KCTS,0) END))AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.PJ=B.SL where A.AJLX=1';--审理天数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT SUM((JARQ-NVL(SXQSRQ,LARQ))-(CASE WHEN NVL(KCTS,0)>3600 THEN 0 ELSE NVL(KCTS,0) END))AS SL FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.QNPJ=B.SL where A.AJLX=1';--去年审理天数



  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.YJ=B.SL where A.BMBS=-1 AND A.AJLX=1';--已结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.WJ=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--未结合计数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnwc=B.SL where A.BMBS=-1 AND A.AJLX=1';--去年已结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndwjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnWJ=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--去年未结合计数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(1,2,3,5,40,45) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.bh=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(1,2,3,5,40,45) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnbh=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(1,2,3,5,40,45) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndjnsl=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(1,2,3,5,40,45) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndqnsl=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事去年结案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(2) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndjal=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事二审受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(40) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndjaldb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事管辖受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.bhtb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.zs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_jctj ||') and kplb in(7,8,9,12,21,41,46,44,50) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndtcl=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事旧存数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(7,8,9,12,21,41,46,44,50) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndtcldb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(7,8,9,12,21,41,46,44,50) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndwj=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年结案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(7) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.QNNDJAL=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事一审受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(7) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.QNNDTCL=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年一审受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(8) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.jnndxs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事二审受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(8) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnndja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年二审受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(9) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.jnndjc=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事再审受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(9) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnndxs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年再审受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) and (laay in(SELECT d.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) d CONNECT BY d.SJDM =PRIOR d.AYDM START WITH d.SJDM=9131) or laay =9131) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndfh=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事合同案件受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) and (laay in(SELECT d.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) d CONNECT BY d.SJDM =PRIOR d.AYDM START WITH d.SJDM=9131) or laay =9131) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndwc=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年合同受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) and (laay in(SELECT d.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) d CONNECT BY d.SJDM =PRIOR d.AYDM START WITH d.SJDM=9177) or laay =9177) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndpj=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事借款合同案件受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) and (laay in(SELECT d.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) d CONNECT BY d.SJDM =PRIOR d.AYDM START WITH d.SJDM=9208) or laay =9208) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndbh=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事建设工程案件受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(7,8,9,12,21,41,46,44,50) and (laay in(SELECT d.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) d CONNECT BY d.SJDM =PRIOR d.AYDM START WITH d.SJDM=9142) or laay =9142) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndzs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事买卖合同案件受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(7,8,9,12,21,41,46,44,50) AND '|| v_tcs ||' and '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndjc=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事调撤数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(7,8,9,12,21,41,46,44,50) AND '|| v_tcs ||' and '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndyj=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事去年调撤数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(13,14,15,28,42,47) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnzs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--行政受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(13,14,15,28,42,47) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.zstb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--行政去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj ||') and kplb in(13,14,15,28,42,47) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndxstb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--行政结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj ||') and kplb in(13,14,15,28,42,47) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ssxs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--行政去年结案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(14) and (laay in(SELECT d.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=3 ) d CONNECT BY d.SJDM =PRIOR d.AYDM START WITH d.SJDM=885) or laay =885) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ssyj=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--行政拆迁决定受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(17) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qt=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--赔偿受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(17) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnqt=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--赔偿去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(17) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndssxs=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--赔偿结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(17) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndssjc=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--赔偿去年结案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(16) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qttb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--执行受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(16) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.hj=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--执行去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(16) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.xf=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--执行结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(16) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ndxflx=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--执行去年结案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(16) and ajlb in(3,6) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ZXJDFY=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--执行监督复议数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(18) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnhj=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--申诉受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(18) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.hjtb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--申诉去年受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(18) and fzkplb=23 AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.xsss=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑事申诉受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(18) and fzkplb=24 AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.msss=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--民事申诉受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(18) and fzkplb=25 AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.xzss=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--行政申诉受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(18) and fzkplb=24 AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnmsss=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--去年民事申诉受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(18) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ssja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--申诉结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(18) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnssja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--申诉去年结案数



  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(4) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.tcl=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑罚变更受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(4) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qntcl=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑罚变更去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(4) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.xfbgja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑罚变更结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(4) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnxfbgja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--刑罚变更去年结案数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') and kplb in(22) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.tcltb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--七类受理数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||' or '|| v_qnndwjtj ||') and kplb in(22) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.wjtb=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--七类去年受理数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||') and kplb in(22) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qlja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--七类结案数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_qnndyjtj||') and kplb in(22) AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.qnqlja=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--七类去年结案数

  UPDATE B_TEMPYJAQKTJ SET XS=NVL(YJ,0)+NVL(WJ,0);--受理数
  UPDATE B_TEMPYJAQKTJ SET qnxs=NVL(qnwc,0)+NVL(qnWJ,0);--去年受理数
  UPDATE B_TEMPYJAQKTJ set jal=ROUND(YJ*100.0/(xs),2) where xs>0;--结案率
  UPDATE B_TEMPYJAQKTJ set qnjal=ROUND(qnwc*100.0/(qnxs),2) where qnxs>0;--去年结案率
  UPDATE B_TEMPYJAQKTJ set ndtb=ROUND(ndjnsl*100.0/(bh),2) where bh>0;--刑事结案率
  UPDATE B_TEMPYJAQKTJ set ndja=ROUND(ndqnsl*100.0/(qnbh),2) where qnbh>0;--去年刑事结案率
  UPDATE B_TEMPYJAQKTJ set qnndwj=ROUND(ndtcldb*100.0/(bhtb),2) where bhtb>0;--民事结案率
  UPDATE B_TEMPYJAQKTJ set ndwjtb=ROUND(ndwj*100.0/(zs),2) where zs>0;--去年民事结案率
  UPDATE B_TEMPYJAQKTJ set ndgp=ROUND(ndjc*100.0/(ndtcldb),2) where ndtcldb>0;--民事调撤率
  UPDATE B_TEMPYJAQKTJ set ndtc=ROUND(ndyj*100.0/(ndwj),2) where ndwj>0;--去年民事调撤率
  UPDATE B_TEMPYJAQKTJ SET ndqt=NVL(ndzs,0)+NVL(ndbh,0)+NVL(ndpj,0);--民事三大案由数
  UPDATE B_TEMPYJAQKTJ set ssjc=ROUND(ndxstb*100.0/(qnzs),2) where qnzs>0;--行政结案率
  UPDATE B_TEMPYJAQKTJ set sswj=ROUND(ssxs*100.0/(zstb),2) where zstb>0;--去年行政结案率
  UPDATE B_TEMPYJAQKTJ set xflx=ROUND(ndssxs*100.0/(qt),2) where qt>0;--赔偿结案率
  UPDATE B_TEMPYJAQKTJ set xflf=ROUND(ndssjc*100.0/(qnqt),2) where qnqt>0;--去年赔偿结案率
  UPDATE B_TEMPYJAQKTJ set ndxflf=ROUND(xf*100.0/(qttb),2) where qttb>0;--执行结案率
  UPDATE B_TEMPYJAQKTJ set ndxf=ROUND(ndxflx*100.0/(hj),2) where hj>0;--执行去年结案率
  UPDATE B_TEMPYJAQKTJ set ssjal=ROUND(ssja*100.0/(qnhj),2) where qnhj>0;--申诉结案率
  UPDATE B_TEMPYJAQKTJ set qnssjal=ROUND(qnssja*100.0/(hjtb),2) where hjtb>0;--申诉去年结案率
  UPDATE B_TEMPYJAQKTJ set xfbgjal=ROUND(xfbgja*100.0/(tcl),2) where tcl>0;--刑罚变更结案率
  UPDATE B_TEMPYJAQKTJ set qnxfbgjal=ROUND(qnxfbgja*100.0/(qntcl),2) where qntcl>0;--刑罚变更去年结案率
  UPDATE B_TEMPYJAQKTJ set qljal=ROUND(qlja*100.0/(tcltb),2) where tcltb>0;--七类结案率
  UPDATE B_TEMPYJAQKTJ set qnqljal=ROUND(qnqlja*100.0/(wjtb),2) where wjtb>0;--七类去年结案率
  UPDATE B_TEMPYJAQKTJ set pj=ROUND(pj/(yj),0) where yj>0;--审理天数
  UPDATE B_TEMPYJAQKTJ set qnpj=ROUND(qnpj/(qnwc),0) where qnwc>0;--审理天数

  open rt for select * from B_TEMPYJAQKTJ  order by XF;--where BH>0 or QNQT>0 or QNFH>0 or QNHJ>0
end;

/

