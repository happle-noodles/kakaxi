create PROCEDURE BtFyJdSzQkTb(nscfy number,qsrq varchar2,jsrq varchar2,ndqsrq varchar2,ndjsrq varchar2, rt out pkg_row.myRow) as
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_ndyjtj varchar2(200);
v_ndwjtj varchar2(200);
v_ndjctj varchar2(200);
v_qntqyjtj varchar2(200);
v_qntqwjtj varchar2(200);
v_qntqjctj varchar2(200);
v_qnndyjtj varchar2(200);
v_qnndwjtj varchar2(200);
v_qnndjctj varchar2(200);

v_qntqqsrq varchar2(200);
v_qntqjsrq varchar2(200);
v_qnndqsrq varchar2(200);
v_qnndjsrq varchar2(200);

v_scfy varchar2(200);
v_kplb varchar2(100);

v_qttj varchar2(500);
v_qttj1 varchar2(500);

v_gdjsrq varchar(200);
v_gdyjtj varchar(200);
begin
  v_qntqqsrq:=to_char(add_months(to_date(qsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
  v_qntqjsrq:=to_char(add_months(to_date(jsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
  v_qnndqsrq:=to_char(add_months(to_date(ndqsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
  v_qnndjsrq:=to_char(add_months(to_date(ndjsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');

  v_gdjsrq :=to_char(add_months(to_timestamp(ndjsrq,'yyyy-mm-dd'), -1),'yyyy-mm-dd');
  dbms_output.put_line(v_gdjsrq);

  select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
  select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
  select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';

  v_ndyjtj:=v_yjtj;
  v_ndwjtj:=v_wjtj;
  v_ndjctj:=v_jctj;
  v_qntqyjtj:=v_yjtj;
  v_qntqwjtj:=v_wjtj;
  v_qntqjctj:=v_jctj;
  v_qnndyjtj:=v_yjtj;
  v_qnndwjtj:=v_wjtj;
  v_qnndjctj:=v_jctj;

  v_gdyjtj:=v_yjtj;

  v_jctj :=replace(v_jctj,'＆QsRq＆',ndqsrq);
  v_yjtj :=replace(v_yjtj,'＆QsRq＆',ndqsrq);
  v_yjtj :=replace(v_yjtj,'＆JsRq＆',ndjsrq);
  v_wjtj :=replace(v_wjtj,'＆JsRq＆',ndjsrq);

  v_ndjctj :=replace(v_ndjctj,'＆QsRq＆',ndqsrq);
  v_ndyjtj :=replace(v_ndyjtj,'＆QsRq＆',ndqsrq);
  v_ndyjtj :=replace(v_ndyjtj,'＆JsRq＆',ndjsrq);
  v_ndwjtj :=replace(v_ndwjtj,'＆JsRq＆',ndjsrq);

  v_qntqjctj :=replace(v_qntqjctj,'＆QsRq＆',v_qnndqsrq);
  v_qntqyjtj :=replace(v_qntqyjtj,'＆QsRq＆',v_qnndqsrq);
  v_qntqyjtj :=replace(v_qntqyjtj,'＆JsRq＆',v_qnndjsrq);
  v_qntqwjtj :=replace(v_qntqwjtj,'＆JsRq＆',v_qnndjsrq);

  v_qnndjctj :=replace(v_qnndjctj,'＆QsRq＆',v_qnndqsrq);
  v_qnndyjtj :=replace(v_qnndyjtj,'＆QsRq＆',v_qnndqsrq);
  v_qnndyjtj :=replace(v_qnndyjtj,'＆JsRq＆',v_qnndjsrq);
  v_qnndwjtj :=replace(v_qnndwjtj,'＆JsRq＆',v_qnndjsrq);


  v_gdyjtj :=replace(v_gdyjtj,'＆QsRq＆',ndqsrq);
  v_gdyjtj :=replace(v_gdyjtj,'＆JsRq＆',v_gdjsrq);

  v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);

INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('立案一庭',6,1,1);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('立案二庭',18,1,2);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('刑庭',1,1,3);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('民一庭',2,1,4);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('民二庭',3,1,5);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('民三庭',23,1,6);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('行政庭',4,1,7);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('赔偿办',9,1,8);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('审监一庭',7,1,9);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('审监二庭',19,1,10);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('执行局',255,1,11);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX,XF)VALUES('合计',-1,1,12);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('立案一庭',6,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('立案二庭',18,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('刑庭',1,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民一庭',2,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民二庭',3,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('民三庭',23,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('行政庭',4,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('赔偿办',9,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('审监一庭',7,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('审监二庭',19,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('执行局',255,0);
INSERT INTO B_TEMPYJAQKTJ(BMMC,BMBS,AJLX)VALUES('合计',-1,0);

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.YJ=B.SL where A.AJLX=1';--月度已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.WJ=B.SL where A.AJLX=1';--月度未结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.JC=B.SL where A.AJLX=1';--月度旧存数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') and '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.TC=B.SL where A.AJLX=1';--月度调撤数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')) GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.SSXS=B.SL where A.AJLX=1';--月度已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.SSJC=B.SL where A.AJLX=1';--月度未归档数

     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') AND KPLB=4 and '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.HJ=B.SL where A.AJLX=1';--月度已结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.YJ=B.SL where A.AJLX=1 and A.BMBS=255';--执行月度已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.WJ=B.SL where A.AJLX=1 AND A.BMBS=255';--执行月度未结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.JC=B.SL where A.AJLX=1 and A.BMBS=255';--执行月度旧存数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') and '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.TC=B.SL where A.AJLX=1 AND A.BMBS=255';--执行月度调撤数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24) and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')))B
    ON(A.BMBS=255) when matched then update set A.SSXS=B.SL where A.AJLX=1 AND A.BMBS=255';--执行月度已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24) and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)))B
    ON(A.BMBS=255) when matched then update set A.SSJC=B.SL where A.AJLX=1';--执行月度未归档数

execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE ('||v_yjtj||' or '|| v_wjtj ||') AND KPLB=16 AND AJLB>1 AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.HJ=B.SL where A.AJLX=1 and A.BMBS=255';--执行月度已结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.YJ=B.SL where A.BMBS=-1 AND A.AJLX=1';--月度已结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.WJ=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--月度未结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.JC=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--月度旧存合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') and '||v_kplb||')B
    ON(1=1) when matched then update set A.TC=B.SL where A.BMBS=-1 AND A.AJLX=1';--月度调撤合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')))B
    ON(1=1) when matched then update set A.SSXS=B.SL where A.BMBS=-1 AND A.AJLX=1';--月度已归档合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)))B
    ON(1=1) when matched then update set A.SSJC=B.SL where A.BMBS=-1 AND A.AJLX=1';--月度未归档合计数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qntqyjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.GP=B.SL where A.AJLX=1';--去年月度已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qntqwjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.QNGP=B.SL where A.AJLX=1';--去年月度未结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qntqjctj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.FH=B.SL where A.AJLX=1';--去年月度旧存数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qntqyjtj||' AND '||v_scfy||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') and '||v_kplb||' GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.QNTC=B.SL where A.AJLX=1';--去年月度调撤数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqyjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.GP=B.SL where A.AJLX=1 AND A.BMBS=255';--去年执行月度已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqwjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.QNGP=B.SL where A.AJLX=1 AND A.BMBS=255';--去年执行月度未结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqjctj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.FH=B.SL where A.AJLX=1 AND A.BMBS=255';--去年执行月度旧存数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqyjtj||' AND '||v_scfy||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') and '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.QNTC=B.SL where A.AJLX=1 AND A.BMBS=255';--去年执行月度调撤数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqyjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.GP=B.SL where A.BMBS=-1 AND A.AJLX=1';--月去年度已结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqwjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.QNGP=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--去年月度未结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqjctj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.FH=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--去年月度旧存合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qntqyjtj||' AND '||v_scfy||' AND ('|| v_qttj ||' or '|| v_qttj1 ||') and '||v_kplb||')B
    ON(1=1) when matched then update set A.QNTC=B.SL where A.BMBS=-1 AND A.AJLX=1';--去年月度调撤合计数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.WC=B.SL where A.AJLX=1';--年度已结数

  --应归档数提前一个月
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.NDXFLX=B.SL where A.AJLX=1';--年度应归档数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.QNWC=B.SL where A.AJLX=1';--年度未结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.PJ=B.SL where A.AJLX=1';--年度旧存数
    dbms_output.put_line('SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' and （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NOT NULL GROUP BY B_AJZTXX.CBSPT');
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')) GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.NDSSXS=B.SL where A.AJLX=1';--年度已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.NDSSJC=B.SL where A.AJLX=1';--年度未归档数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||'and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.WC=B.SL where A.AJLX=1 and A.BMBS=255';--执行年度已结数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||'and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.NDXFLX=B.SL where A.AJLX=1 and A.BMBS=255';--执行年度应归档数


  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.QNWC=B.SL where A.AJLX=1 AND A.BMBS=255';--执行年度未结数
    dbms_output.put_line('SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||' and （select GDRQ from B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS) IS NOT NULL GROUP BY B_AJZTXX.CBSPT');
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')) and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.NDSSXS=B.SL where A.AJLX=1 AND A.BMBS=255';--执行年度已归档数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)) and CBSPT in(5,21,24))B
    ON(A.BMBS=255) when matched then update set A.NDSSJC=B.SL where A.AJLX=1 AND A.BMBS=255';--执行年度未归档数

  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.WC=B.SL where A.BMBS=-1 AND A.AJLX=1';--年度已结合计数

  --已归档数，提前一个月
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.NDXFLX=B.SL where A.BMBS=-1 AND A.AJLX=1';--年度应归档合计数


  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.QNWC=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--年度未结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.PJ=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--年度旧存合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and GDRQ <=to_date('''||ndjsrq||''',''yyyy-MM-dd'')))B
    ON(1=1) when matched then update set A.NDSSXS=B.SL where A.BMBS=-1 AND A.AJLX=1';--年度已归档合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_gdyjtj||' AND '||v_scfy||' AND '||v_kplb||' and EXISTS(SELECT ajbs FROM B_AJFZXX WHERE AJBS=B_AJZTXX.AJBS and (GDRQ >to_date('''||ndjsrq||''',''yyyy-MM-dd'') or GDRQ IS NULL)))B
    ON(1=1) when matched then update set A.NDSSJC=B.SL where A.BMBS=-1 AND A.AJLX=1';--年度未归档合计数

   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.ZS=B.SL where A.AJLX=1';--去年年度已结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndwjtj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.QNZS=B.SL where A.AJLX=1';--去年年度未结数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_qnndjctj||' AND '||v_scfy||' AND '||v_kplb||'  GROUP BY B_AJZTXX.CBSPT)B
    ON(A.BMBS=B.CBSPT) when matched then update set A.QT=B.SL where A.AJLX=1';--去年年度旧存数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndyjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.ZS=B.SL where A.BMBS=-1 AND A.AJLX=1';--去年年度已结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndwjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.QNZS=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--去年年度未结合计数
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_qnndjctj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.QT=B.SL WHERE A.BMBS=-1 AND A.AJLX=1';--去年年度旧存合计数


  UPDATE B_TEMPYJAQKTJ SET BH=NVL(YJ,0)+NVL(WJ,0);--月度受理数
  UPDATE B_TEMPYJAQKTJ set QNFH=NVL(GP,0)+NVL(QNGP,0);--去年月度受理数
  UPDATE B_TEMPYJAQKTJ set XSTB=ROUND(YJ*100.0/(YJ+WJ),2) where BH>0;--月度结案率
  update B_TEMPYJAQKTJ set GPTB=ROUND(GP*100.0/(GP+QNGP),2) WHERE QNFH>0;--去年月度结案率
  UPDATE B_TEMPYJAQKTJ set TCL=ROUND(TC*100.0/(YJ),2) where YJ>0;--月度调撤率
  UPDATE B_TEMPYJAQKTJ set QNTCL=ROUND(QNTC*100.0/(GP),2) where GP>0;--去年月度调撤率
  UPDATE B_TEMPYJAQKTJ set TCLTB=TCL-QNTCL;--月度调撤率同比
  UPDATE B_TEMPYJAQKTJ set SSWJ=ROUND(SSXS*100.0/(YJ),2) where YJ>0;--月度归档率


  UPDATE B_TEMPYJAQKTJ SET QNQT=NVL(WC,0)+NVL(QNWC,0);--年度受理数
  UPDATE B_TEMPYJAQKTJ set QNHJ=NVL(ZS,0)+NVL(QNZS,0);--去年年度受理数
  UPDATE B_TEMPYJAQKTJ set JAL=ROUND(WC*100.0/(WC+QNWC),2) where QNQT>0;--年度结案率
  UPDATE B_TEMPYJAQKTJ set NDSSWJ=ROUND(NDSSXS*100.0/(NDXFLX),2) where NDXFLX>0;--年度归档率，提前一个月
  update B_TEMPYJAQKTJ set QNJAL=ROUND(ZS*100.0/(ZS+QNZS),2) WHERE QNHJ>0;--去年年度结案率
  open rt for select * from B_TEMPYJAQKTJ where BH>0 or QNQT>0 or QNFH>0 or QNHJ>0 order by XF;
end;
/

