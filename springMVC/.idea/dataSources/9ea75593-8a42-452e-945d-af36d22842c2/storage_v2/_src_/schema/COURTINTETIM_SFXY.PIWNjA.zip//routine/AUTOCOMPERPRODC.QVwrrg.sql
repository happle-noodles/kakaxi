create procedure AutoComperProdc is
vNdSjQj varchar2(80);
vNdKsSj varchar2(50);
vNdJsSj varchar2(50);
vSjQj varchar2(80);
vKsSj varchar2(50);
vJsSj varchar2(50);

vCurrentDate varchar2(50);
vMonth varchar2(10);
vDay varchar2(10);
v_year varchar2(10);
 
begin
    
     vCurrentDate :=to_char(sysdate,'yyyy-MM-dd');
     v_year:=to_char(sysdate,'yyyy');
     vMonth:=(case when (substr(to_char(sysdate,'MM'),1,1)='0') then substr(to_char(sysdate,'MM'),2,1) else to_char(sysdate,'MM') end);
     vDay:=(case when (substr(to_char(sysdate,'dd'),1,1)='0') then substr(to_char(sysdate,'dd'),2,1) else to_char(sysdate,'dd') end);
     
     if vMonth='12'
       then
         vKsSj:=v_year||'-11-26';
         vJsSj:=v_year||'-12-25';
         vSjQj:='2#'|| to_char(to_number(v_year)+1)||'-1';
      elsif vMonth='11'
        then
         vKsSj:=to_char(to_number(v_year)-1)||'-11-26';
         vJsSj:=v_year||'-11-25';
         vSjQj:='1#'|| v_year ||'-0';
      else
         vKsSj:=to_char(to_number(v_year)-1)||'-11-26';
         vJsSj:=v_year||'-'||vMonth||'-25';
         vSjQj:='2#'|| v_year ||'-'|| to_char(to_number(vMonth)+1); 
     end if;
     
     dbms_output.put_line(vKsSj||','||vJsSj||','||vSjQj);



    aytjhz(vKsSj,vJsSj,vSjQj);
    p_tjfx_tjxxhz(vKsSj,vJsSj,vSjQj);
    p_zxpg_gjdzjjxkh(vKsSj,vJsSj,vSjQj);
    p_zxpg_zjdjcjxkh(vKsSj,vJsSj,vSjQj);

end AutoComperProdc;
/

