create PROCEDURE P_TJFX_ABSJAQTJ(nscfy number,qsrq varchar2,jsrq varchar2,ntsdm number,rt out pkg_row.myRow) as
/*部门统计分析 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_ycaj varchar2(100);
v_csx  varchar2(200);
v_sxnsj varchar2(300);
v_fztj  varchar2(200);
v_tsdm  varchar2(50);
begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   select gsnr into v_ycaj  from b_tjfxgs where gsmc='延长审限';
   select gsnr into v_csx   from b_tjfxgs where gsmc='超审限A';
   select gsnr into v_sxnsj   from b_tjfxgs where gsmc='审限内审结';
   select gsnr into v_tsdm   from b_tjfxgs where gsmc='承办部门A';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   v_csx :=replace(v_csx,'＆JsRq＆',jsrq);
   v_sxnsj :=replace(v_sxnsj,'＆JsRq＆',jsrq);
   v_fztj:='A.KPLB=B.FZKPLB ';
   if ntsdm=0 then
     v_tsdm:='1=1';
   else
     v_tsdm:=replace(v_tsdm,'＆CbSpt＆',ntsdm);
    end if;
    v_scfy :=v_scfy||' and  ' || v_tsdm;

   INSERT INTO B_TEMPTJFX(KPLB,MC) SELECT A.KPLB,A.MC FROM B_kplb A order by xssx;
   execute immediate 'UPDATE B_TEMPTJFX A SET A.XSYJ=(SELECT COUNT(fzkplb) FROM  b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_xstj || ' AND '|| v_yjtj ||' AND '|| v_fztj ||'  group by B.FZKPLB)';/*新收已结 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.XSWJ=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_xstj || ' AND '|| v_wjtj ||' AND '|| v_fztj ||'  group by B.FZKPLB)';/*新收未结*/
   execute immediate 'UPDATE B_TEMPTJFX A SET A.JCYJ=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_jctj || ' AND '|| v_yjtj ||' AND '|| v_fztj ||'  group by B.FZKPLB)';/*旧存已结*/
   execute immediate 'UPDATE B_TEMPTJFX A SET A.JCWJ=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_jctj || ' AND '|| v_wjtj ||' AND '|| v_fztj ||'  group by B.FZKPLB)';/*旧存未结 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.YJYC=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_ycaj || ' AND '|| v_fztj ||'  group by B.FZKPLB)';/*已结延长 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.YJCSX=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_csx || ' AND '|| v_fztj ||'  group by B.FZKPLB)';/*已结超审限 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.WJCSX=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_wjtj ||' AND' || v_csx || ' AND '|| v_fztj ||'  group by B.FZKPLB)';/*未结超审限 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.SXNSJ=(SELECT COUNT(fzkplb) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_sxnsj || ' AND '|| v_fztj ||'  group by B.FZKPLB)';/*审限内审结*/

   insert into B_TEMPTJFX(KPLB,MC)values(0,'合计');
   update B_TEMPTJFX set XSYJ=(select sum(XSYJ) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set XSWJ=(select sum(XSWJ) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set JCYJ=(select sum(JCYJ) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set JCWJ=(select sum(JCWJ) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set YJYC=(select sum(YJYC) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set YJCSX=(select sum(YJCSX) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set WJCSX=(select sum(WJCSX) from B_TEMPTJFX) where kplb=0;
   update B_TEMPTJFX set SXNSJ=(select sum(SXNSJ) from B_TEMPTJFX) where kplb=0;

   update B_TEMPTJFX A SET A.XS=NVL(A.XSYJ,0)+NVL(A.XSWJ,0) WHERE XSYJ>0 OR XSWJ>0 ;/*新收*/
   update B_TEMPTJFX A SET A.JC=NVL(A.JCYJ,0)+NVL(A.JCWJ,0) WHERE JCYJ>0 OR JCWJ>0;/*旧存*/
   update B_TEMPTJFX A SET A.YJ=NVL(A.XSYJ,0)+NVL(A.JCYJ,0) WHERE XSYJ>0 OR JCYJ>0;/*已结*/
   update B_TEMPTJFX A SET A.WJ=NVL(A.XSWJ,0)+NVL(A.JCWJ,0) WHERE XSWJ>0 OR JCWJ>0;/*未结 */
   update B_TEMPTJFX A SET A.SLS=NVL(A.XS,0)+NVL(A.JC,0);/*受理数*/
   update B_TEMPTJFX A SET A.XSJAL=100*NVL(A.XSYJ,0)/A.XS WHERE A.XS>0;/*新收结案率*/
   update B_TEMPTJFX A SET A.JCJAL=100*NVL(A.JCYJ,0)/A.JC WHERE A.JC>0;/*旧存结案率*/
   update B_TEMPTJFX A SET A.JAL=100*NVL(A.YJ,0)/A.SLS WHERE  A.SLS>0;/*结案率*/

   open rt for SELECT * FROM  B_TEMPTJFX WHERE SLS>0;
end P_TJFX_ABSJAQTJ;
/

