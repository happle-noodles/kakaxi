create function f_GetBgInf(nKplb number,nAjbs number) return varchar2 is
strBg varchar2(2000);
begin
   if(nKplb=1) then
     begin
       select to_char(wm_concat(bg)) into strBg from (
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBGR.ajbs and xh=B_XSBGR.bgr))) as bg from B_XSBGR where ajbs=nAjbs
          union
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw1 in(4,5)))) as bg from B_XSBHR where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr and ssdw1 in(4,5))))as bg from b_xszsr where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr and ssdw1 in(4,5))))as bg from B_FDMSSSDSR where ajbs=nAjbs);
     end;
     elsif (nKplb=2) then
       begin
          select to_char(wm_concat(bg)) into strBg from (
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBGR.ajbs and xh=B_XSBGR.bgr))) as bg from B_XSBGR where ajbs=nAjbs
          union
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw2 in(3)))) as bg from B_XSBHR where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr and ssdw2 in(3))))as bg from b_xszsr where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr and ssdw2 in(3))))as bg from B_FDMSSSDSR where ajbs=nAjbs);
       end;
     elsif (nKplb=3) then
       begin
          select to_char(wm_concat(bg)) into strBg from (
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBGR.ajbs and xh=B_XSBGR.bgr))) as bg from B_XSBGR where ajbs=nAjbs
          union
          select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw3 in(2)))) as bg from B_XSBHR where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=b_xszsr.ajbs and xh=b_xszsr.zsr and ssdw3 in(2))))as bg from b_xszsr where ajbs=nAjbs
          union
          select TO_CHAR(wm_concat((select mc from b_yastml where ajbs=B_FDMSSSDSR.ajbs and xh=B_FDMSSSDSR.fdmsdsr and ssdw3 in(2))))as bg from B_FDMSSSDSR where ajbs=nAjbs);
       end;
       elsif (nKplb=7) then
         begin
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(2,6,8)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=8) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw2 in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=9) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw3 in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=12) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_ZWR.ajbs and xh=B_ZWR.zwr))) into strBg from b_zwr where ajbs=nAjbs;
         end;
       elsif (nKplb=21) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2,54,62,64,72,82,92,102,12,22,32,34,42,44,52)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif (nKplb=13) then
         begin
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(2,6)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=14) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw2 in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=15) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw3 in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=18) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=28) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=29) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif (nKplb=40 or nKplb=45) then
         begin
            select to_char(wm_concat(bg)) into strBg from (
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBGR.ajbs and xh=B_XSBGR.bgr))) as bg from B_XSBGR where ajbs=nAjbs
            union
            select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=B_XSBHR.ajbs and xh=B_XSBHR.bhr and ssdw2 in(2)))) as bg from B_XSBHR where ajbs=nAjbs
            );
         end;
       elsif(nKplb=41 or nKplb=42 or nKplb=43 or nKplb=46 or nKplb=47 or nKplb=57 or nKplb=58 or nKplb=59) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(2,6,8)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=44) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=48) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=49) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=50) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=51 or nKplb=52) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw in(2,4,7,12,14,16)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=54) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw1 in(2,6)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=55) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw2 in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       elsif(nKplb=56) then
         begin
           select to_char(wmsys.wm_concat((select mc from b_yastml where ajbs=b_dsr.ajbs and xh=b_dsr.dsr and ssdw3 in(2,4)))) into strBg from b_dsr where ajbs=nAjbs;
         end;
       else
         begin
           strBg :='';
         end;
    end if;

    return strBg;
end;
/

