create PROCEDURE SJZSINFO as

v_jnksrq varchar2(50);
v_qnksrq varchar2(50);
v_jnjsrq varchar2(50);
v_qnjsrq varchar2(50);
v_jnxs   varchar2(200);
v_jnjc   varchar2(200);
v_jnyj   varchar2(200);
v_jnwj   varchar2(200);
v_qnxs   varchar2(200);
v_qnjc   varchar2(200);
v_qnyj   varchar2(200);
v_lnxs   varchar2(200);
v_lnjc   varchar2(200);
v_lnyj   varchar2(200);
v_jrxs   varchar2(200);
v_jrjc   varchar2(200);
v_jryj   varchar2(200);
v_sjzs   number;
v_fydm   number;
begin
if((to_char(sysdate,'mm')>=11 and to_char(sysdate,'dd')>=26) and (to_char(sysdate,'mm')<1)) then
  v_jnksrq:=to_char((to_char(sysdate,'yyyy'))||'-11-26');
  v_qnksrq:=to_char((to_char(sysdate,'yyyy')-1)||'-11-26');
else
  v_jnksrq:=to_char((to_char(sysdate,'yyyy')-1)||'-11-26');
  v_qnksrq:=to_char((to_char(sysdate,'yyyy')-2)||'-11-26');
end if;
v_jnjsrq:=to_char(sysdate,'yyyy-mm-dd');
v_qnjsrq:=to_char(ADD_MONTHS(sysdate, -12),'yyyy-mm-dd');
select gsnr into v_jnxs from b_tjfxgs where gsmc='新收A';
select gsnr into v_jnjc from b_tjfxgs where gsmc='旧存A';
select gsnr into v_jnyj from b_tjfxgs where gsmc='已结A';
select gsnr into v_jnwj from b_tjfxgs where gsmc='未结A';
v_jnxs :=replace(v_jnxs,'＆QsRq＆',v_jnksrq);
v_jnxs :=replace(v_jnxs,'＆JsRq＆',v_jnjsrq);
v_jnjc :=replace(v_jnjc,'＆QsRq＆',v_jnksrq);
v_jnyj :=replace(v_jnyj,'＆QsRq＆',v_jnksrq);
v_jnyj :=replace(v_jnyj,'＆JsRq＆',v_jnjsrq);
v_jnwj :=replace(v_jnwj,'＆JsRq＆',v_jnjsrq);
select gsnr into v_qnxs from b_tjfxgs where gsmc='新收A';
select gsnr into v_qnjc from b_tjfxgs where gsmc='旧存A';
select gsnr into v_qnyj from b_tjfxgs where gsmc='已结A';
v_qnxs :=replace(v_qnxs,'＆QsRq＆',v_qnksrq);
v_qnxs :=replace(v_qnxs,'＆JsRq＆',v_qnjsrq);
v_qnjc :=replace(v_qnjc,'＆QsRq＆',v_qnksrq);
v_qnyj :=replace(v_qnyj,'＆QsRq＆',v_qnksrq);
v_qnyj :=replace(v_qnyj,'＆JsRq＆',v_qnjsrq);
select gsnr into v_lnxs from b_tjfxgs where gsmc='新收A';
select gsnr into v_lnjc from b_tjfxgs where gsmc='旧存A';
select gsnr into v_lnyj from b_tjfxgs where gsmc='已结A';
v_lnxs :=replace(v_lnxs,'＆QsRq＆','2010-11-26');
v_lnxs :=replace(v_lnxs,'＆JsRq＆',v_jnjsrq);
v_lnjc :=replace(v_lnjc,'＆QsRq＆','2010-11-26');
v_lnyj :=replace(v_lnyj,'＆QsRq＆','2010-11-26');
v_lnyj :=replace(v_lnyj,'＆JsRq＆',v_jnjsrq);
select gsnr into v_jrxs from b_tjfxgs where gsmc='新收A';
select gsnr into v_jrjc from b_tjfxgs where gsmc='旧存A';
select gsnr into v_jryj from b_tjfxgs where gsmc='已结A';
v_jrxs :=replace(v_jrxs,'＆QsRq＆',v_jnjsrq);
v_jrxs :=replace(v_jrxs,'＆JsRq＆',v_jnjsrq);
v_jrjc :=replace(v_jrjc,'＆QsRq＆',v_jnjsrq);
v_jryj :=replace(v_jryj,'＆QsRq＆',v_jnjsrq);
v_jryj :=replace(v_jryj,'＆JsRq＆',v_jnjsrq);

select count(1) as sj into v_sjzs from b_sjzs;
if v_sjzs=0 then
  insert into b_sjzs (fydm) select dm from b_fy where dm>=4166 and dm<=4208;
end if;
select count(1) as sj into v_sjzs from B_XQFYTS;
if v_sjzs=0 then
  v_fydm:=4166;
  while(v_fydm<=4208)
  loop
    insert into B_XQFYTS (fydm,ajlx) select v_fydm,'刑事' from dual;
    insert into B_XQFYTS (fydm,ajlx) select v_fydm,'民事' from dual;
    insert into B_XQFYTS (fydm,ajlx) select v_fydm,'行政' from dual;
    insert into B_XQFYTS (fydm,ajlx) select v_fydm,'赔偿' from dual;
    insert into B_XQFYTS (fydm,ajlx) select v_fydm,'执行' from dual;
    v_fydm:=v_fydm+1;
  end loop;
end if;

--dbms_output.put_line(v_jrjc );
execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.jnxss,0) as  jnxss from b_fy  a  left join (select count(1) AS JNXSS,SCFY from B_AJZTXX WHERE '||v_jnxs||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.XSS=B.JNXSS';


execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.jnjcs,0) as  jnjcs from b_fy  a  left join (select count(1) AS JNJCS,SCFY from B_AJZTXX WHERE '||v_jnjc||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.JCS=B.JNJCS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.jnyjs,0) as  jnyjs from b_fy  a  left join (select count(1) AS JNYJS,SCFY from B_AJZTXX WHERE '||v_jnyj||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.YJS=B.JNYJS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.qnxss,0) as  qnxss from b_fy  a  left join (select count(1) AS QNXSS,SCFY from B_AJZTXX WHERE '||v_qnxs||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.QNXSS=B.QNXSS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.qnjcs,0) as  qnjcs from b_fy  a  left join (select count(1) AS QNJCS,SCFY from B_AJZTXX WHERE '||v_qnjc||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.QNJCS=B.QNJCS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.qnyjs,0) as  qnyjs from b_fy  a  left join (select count(1) AS QNYJS,SCFY from B_AJZTXX WHERE '||v_qnyj||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.QNYJS=B.QNYJS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.lnxss,0) as  lnxss from b_fy  a  left join (select count(1) AS LNXSS,SCFY from B_AJZTXX WHERE '||v_lnxs||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.LNXSS=B.LNXSS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.lnjcs,0) as  lnjcs from b_fy  a  left join (select count(1) AS LNJCS,SCFY from B_AJZTXX WHERE '||v_lnjc||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.LNJCS=B.LNJCS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.lnyjs,0) as  lnyjs from b_fy  a  left join (select count(1) AS LNYJS,SCFY from B_AJZTXX WHERE '||v_lnyj||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.LNYJS=B.LNYJS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.jrxss,0) as  jrxss from b_fy  a  left join (select count(1) AS JRXSS,SCFY from B_AJZTXX WHERE '||v_jrxs||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY ) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.JRXSS=B.JRXSS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.jrjcs,0) as  jrjcs from b_fy  a  left join (select count(1) AS JRJCS,SCFY from B_AJZTXX WHERE '||v_jrjc||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.JRJCS=B.JRJCS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.jryjs,0) as  jryjs from b_fy  a  left join (select count(1) AS JRYJS,SCFY from B_AJZTXX WHERE '||v_jryj||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.JRYJS=B.JRYJS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.dfas,0) as  dfas from b_fy  a  left join (select count(1) AS DFAS,SCFY from B_AJZTXX WHERE '||v_jnwj||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) AND AJJZJD=2 AND (CBSPT IS NULL OR CBR IS NULL) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.DFAS=B.DFAS';

execute immediate'merge into b_sjzs A
  using(select a.dm as scfy,nvl(c.slzs,0) as  slzs from b_fy  a  left join (select count(1) AS SLZS,SCFY from B_AJZTXX WHERE '||v_jnwj||'
  AND KPLB IN (1,2,3,4,5,7,8,9,12,13,14,15,16,17,18,21,22,28,29,40,41,42,44,45,46,47) AND AJJZJD=4 AND JARQ IS NULL GROUP BY B_AJZTXX.SCFY)  c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B
  on (A.FYDM=B.SCFY) WHEN MATCHED THEN UPDATE SET A.SLZS=B.SLZS';

execute immediate'UPDATE B_SJZS SET GXRQ=sysdate WHERE FYDM=4166';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.xss,0) as  xss from b_fy  a  left join (select count(1) as XSS,SCFY FROM B_AJZTXX WHERE '||v_jnxs||'
  AND KPLB IN (1,2,3,40,45) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''刑事'') WHEN MATCHED THEN UPDATE SET A.XSS=B.XSS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.jcs,0) as  jcs from b_fy  a  left join (select count(1) as JCS,SCFY FROM B_AJZTXX WHERE '||v_jnjc||'
  AND KPLB IN (1,2,3,40,45) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''刑事'') WHEN MATCHED THEN UPDATE SET A.JCS=B.JCS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.yjs,0) as  yjs from b_fy  a  left join (select count(1) as YJS,SCFY FROM B_AJZTXX WHERE '||v_jnyj||'
  AND KPLB IN (1,2,3,40,45) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''刑事'') WHEN MATCHED THEN UPDATE SET A.YJS=B.YJS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.xss,0) as  xss from b_fy  a  left join (select count(1) as XSS,SCFY FROM B_AJZTXX WHERE '||v_jnxs||'
  AND KPLB IN (7,8,9,41,44,46) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''民事'') WHEN MATCHED THEN UPDATE SET A.XSS=B.XSS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.jcs,0) as  jcs from b_fy  a  left join (select count(1) as JCS,SCFY FROM B_AJZTXX WHERE '||v_jnjc||'
  AND KPLB IN (7,8,9,41,44,46) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''民事'') WHEN MATCHED THEN UPDATE SET A.JCS=B.JCS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.yjs,0) as  yjs from b_fy  a  left join (select count(1) as YJS,SCFY FROM B_AJZTXX WHERE '||v_jnyj||'
  AND KPLB IN (7,8,9,41,44,46) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''民事'') WHEN MATCHED THEN UPDATE SET A.YJS=B.YJS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.xss,0) as  xss from b_fy  a  left join (select count(1) as XSS,SCFY FROM B_AJZTXX WHERE '||v_jnxs||'
  AND KPLB IN (13,14,15,42,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''行政'') WHEN MATCHED THEN UPDATE SET A.XSS=B.XSS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.jcs,0) as  jcs from b_fy  a  left join (select count(1) as JCS,SCFY FROM B_AJZTXX WHERE '||v_jnjc||'
  AND KPLB IN (13,14,15,42,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''行政'') WHEN MATCHED THEN UPDATE SET A.JCS=B.JCS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.yjs,0) as  yjs from b_fy  a  left join (select count(1) as YJS,SCFY FROM B_AJZTXX WHERE '||v_jnyj||'
  AND KPLB IN (13,14,15,42,47) GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''行政'') WHEN MATCHED THEN UPDATE SET A.YJS=B.YJS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.xss,0) as  xss from b_fy  a  left join (select count(1) as XSS,SCFY FROM B_AJZTXX WHERE '||v_jnxs||'
  AND KPLB=17 GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''赔偿'') WHEN MATCHED THEN UPDATE SET A.XSS=B.XSS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.jcs,0) as  jcs from b_fy  a  left join (select count(1) as JCS,SCFY FROM B_AJZTXX WHERE '||v_jnjc||'
  AND KPLB=17 GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''赔偿'') WHEN MATCHED THEN UPDATE SET A.JCS=B.JCS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.yjs,0) as  yjs from b_fy  a  left join (select count(1) as YJS,SCFY FROM B_AJZTXX WHERE '||v_jnyj||'
  AND KPLB=17 GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''赔偿'') WHEN MATCHED THEN UPDATE SET A.YJS=B.YJS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.xss,0) as  xss from b_fy  a  left join (select count(1) as XSS,SCFY FROM B_AJZTXX WHERE '||v_jnxs||'
  AND KPLB=16 GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''执行'') WHEN MATCHED THEN UPDATE SET A.XSS=B.XSS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.jcs,0) as  jcs from b_fy  a  left join (select count(1) as JCS,SCFY FROM B_AJZTXX WHERE '||v_jnjc||'
  AND KPLB=16 GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''执行'') WHEN MATCHED THEN UPDATE SET A.JCS=B.JCS';

execute immediate'merge into B_XQFYTS A using(select a.dm as scfy,nvl(c.yjs,0) as  yjs from b_fy  a  left join (select count(1) as YJS,SCFY FROM B_AJZTXX WHERE '||v_jnyj||'
  AND KPLB=16 GROUP BY B_AJZTXX.SCFY) c on a.dm=c.scfy   where a.dm>=4166 and a.dm<=4208) B ON (A.FYDM=B.SCFY AND A.AJLX=''执行'') WHEN MATCHED THEN UPDATE SET A.YJS=B.YJS';

end SJZSINFO;
/

