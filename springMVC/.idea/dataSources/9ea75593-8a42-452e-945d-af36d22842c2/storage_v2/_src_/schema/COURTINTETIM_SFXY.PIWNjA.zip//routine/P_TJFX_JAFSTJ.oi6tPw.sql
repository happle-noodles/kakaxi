create PROCEDURE P_TJFX_JAFSTJ(nscfy number,qsrq varchar2,jsrq varchar2,vTj varchar2,rt out pkg_row.myRow) as
/*部门统计分析 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
vTj 查询条件
rt   返回数据集
*/

v_yjtj varchar2(200);
v_scfy varchar2(100);
v_jafsmc varchar(1600);
v_qsrq varchar(100);
v_jsrq varchar(100);

begin

   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_jafsmc   from b_tjfxgs where gsmc='结案方式名称';

   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   /*今年结案方式分析*/
   execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC,YJ,XSSX) SELECT 1,mc,count(*),1 from (select '||v_jafsmc||'as mc from b_ajztxx where '||v_scfy|| ' AND '|| vTj || 'and '||v_yjtj||') c group by mc ';
   /*去年结案方式分析*/
   v_qsrq:= to_char(add_months(to_date(qsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
   v_jsrq:= to_char(add_months(to_date(jsrq,'yyyy-MM-dd'),-12),'yyyy-MM-dd');
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',v_qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',v_jsrq);

   execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC,XS,XSSX) SELECT 2,mc,count(*),1 from (select '||v_jafsmc||'as mc from b_ajztxx where '||v_scfy|| ' AND '|| vTj || 'and '||v_yjtj||') c group by mc ';



   insert into B_TEMPTJFX(MC,DM,XSSX) values ('合计',1,2);
   insert into B_TEMPTJFX(MC,DM,XSSX) values ('合计',2,2);
   update B_TEMPTJFX set YJ=(select sum(YJ) from B_TEMPTJFX) where mc='合计' AND DM=1;
   update B_TEMPTJFX set XS=(select sum(XS) from B_TEMPTJFX) where mc='合计' AND DM=2;


   open rt for  select NVL(a.mc,b.mc) as mc,a.yj,b.xs from (SELECT MC,YJ,XSSX FROM  B_TEMPTJFX where dm=1) a full join (SELECT MC,XS,XSSX FROM  B_TEMPTJFX where dm=2) b on a.mc=b.mc ORDER BY NVL(A.XSSX,B.XSSX);
end P_TJFX_JAFSTJ;
/

