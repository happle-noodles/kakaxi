create procedure p_cb_csx(nscfy number,nlx number,nRow number, rt out pkg_row.myRow) is
/*计算未结案件距审限终点天数 杨元胜
nlx 1为催办 ，2为超审限
*/
  v_sql varchar2(500);
  v_where varchar(500);
begin
  if nlx=1 then
      v_sql:='select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,f_getjsxzdts(a.ajbs) as ts from b_ajztxx a,b_ajcbqx b';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||' and a.larq is not null and a.jarq is null and f_getjsxzdts(a.ajbs) is not null    and (select count(1) From b_kcsxjl c where c.ajbs=a.ajbs and c.scfy=a.scfy and c.jsrq is null)=0';
      v_where:=v_where|| ' and a.kplb=b.kplb and a.scfy=b.scfy and f_getjsxzdts(a.ajbs) between 0  and b.cbts ';
       if nRow>0 then
           v_where:=v_where|| ' and  rownum<= '|| nRow ;
         end if;
        v_where:=v_where|| ' order by f_getjsxzdts (a.ajbs)';
    end if;
  if nlx=2 then
      v_sql:='select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,f_getjsxzdts(a.ajbs) as ts from b_ajztxx  a';
      v_where:=' where  scfy='||  to_char(nscfy) ||' and a.larq is not null and jarq is null AND KPLB<>22 AND KPLB<>12 and f_getjsxzdts(a.ajbs) is not null';
      v_where:=v_where|| ' and f_getjsxzdts(a.ajbs)<0 ';
             if nRow>0 then
              v_where:=v_where|| ' and  rownum<= '|| nRow ;
           end if;
         v_where:=v_where|| ' order by f_getjsxzdts (a.ajbs) desc';
       end if;
       /* ggrq  as   larq   */
   if nlx=3 then
       v_sql:='select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(b.ggrq,''yyyy-MM-dd'') as larq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,b.GGQX-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-b.GGRQ) as ts,b.ggrq from b_ajztxx a,b_sdjl b ';
       v_where:=' where  a.scfy='||  to_char(nscfy) ||' and  b.GGRQ IS NOT NULL AND b.GGQX IS NOT NULL AND b.GGQX-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-b.GGRQ) BETWEEN 0 AND 15 and  a.ajbs=b.ajbs';
        if nRow>0 then
              v_where:=v_where|| ' and  rownum<= '|| nRow ;
           end if;
    end if;
    if nlx=4 then
       v_sql:='select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.jarq,''yyyy-MM-dd'') as jarq,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,(b.gdqx-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-a.jarq)) as ts from b_ajztxx a,b_gdcbqx b, b_ajfzxx c  ';
       v_where:=' where  a.scfy='||  to_char(nscfy) ||' and b.scfy='||  to_char(nscfy) ||' and a.ajbs=c.ajbs and a.kplb=b.kplb and a.jarq is not null and a.jarq>=to_date(''2016-1-1'',''yyyy-MM-dd'') and c.gdrq is null and b.cbts>=(b.gdqx-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-a.jarq))';
        if nRow>0 then
              v_where:=v_where|| ' and  rownum<= '|| nRow ;
           end if;
      end if;


       /*
王斌20150927加

*/
      if nlx=5 then
       v_sql:='select * from (select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.jarq,''yyyy-MM-dd'') as jarq,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,(15-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-a.jarq)) as ts from b_ajztxx a  ';
       v_where:=' where  a.scfy='||  to_char(nscfy) ||' and (a.sfsx=1 or a.sfsx is null) and a.sxrq is null  and a.jarq is not null and jarq>to_date(''2015-11-1'',''yyyy-mm-dd'') and  a.kplb<>4 and a.kplb<>22)';
        if nRow>0 then
              v_where:=v_where|| ' where  rownum<= '|| nRow ;
           end if;
      end if;


  open rt for v_sql || v_where;
end p_cb_csx;
/

