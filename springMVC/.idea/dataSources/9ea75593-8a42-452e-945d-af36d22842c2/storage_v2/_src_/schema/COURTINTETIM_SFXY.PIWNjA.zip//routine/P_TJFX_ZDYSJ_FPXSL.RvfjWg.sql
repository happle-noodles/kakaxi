create PROCEDURE P_TJFX_ZDYSJ_FPXSL(qsrq varchar2,jsrq varchar2,sjqj varchar2)
as
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_sjqj varchar2(1000);
v_yj varchar2(200);
kssj timestamp;
jssj timestamp;
v_qsrq varchar2(200);
v_jsrq varchar(200);
v_sjqjcs varchar(200);
months interval year to month;
begin

     v_qsrq :=qsrq;
     v_jsrq :=jsrq;
     v_sjqjcs :=sjqj;

   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   v_xstj :=replace(v_xstj,'＆QsRq＆',v_qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',v_jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',v_qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',v_jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',v_jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',v_qsrq);
   v_sjqj :=v_sjqjcs||'#'||v_qsrq||'#'||v_jsrq;

   execute immediate 'delete from b_tjhz WHERE SJQJ LIKE ''%'||v_sjqjcs||'#%'' ';

   INSERT INTO b_tjhz(KPLB,SJQJ,CJFY,FYJB,SJDM) SELECT A.KPLB,(''||v_sjqj||'') ,B.DM,B.FYJB,(CASE WHEN B.SJDM=4166 THEN B.DM ELSE B.SJDM END) AS SJDM  FROM B_KPLB a,b_fy b where b.dm BETWEEN 4166 AND 4208 and ((a.kplb<30 or kplb>39) and a.kplb<>19) ORDER BY B.DM,A.KPLB;

   execute immediate ' merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB)B
   ON(A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY)
   when matched then update set A.YJS=B.SL where  A.SJQJ='''||v_sjqj||'''';--已结数

   execute immediate 'merge into B_TJHZ A
   using (SELECT COUNT(*) AS SL,M.FZKPLB,M.JBFY FROM (SELECT (FZKPLB-1) as FZKPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS JBFY FROM B_AJZTXX WHERE '||v_xstj||' AND KPLB IN(2,8,14)) M GROUP BY M.JBFY,M.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.JBFY)
   WHEN matched then update set A.SSXSS=B.SL WHERE A.SJQJ='''||v_sjqj||'''';--上诉新收数

     execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(*) AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE KPLB IN(3,9,15) AND '||v_yjtj||' and  AH IN(SELECT AH FROM B_YSQK WHERE KPLB=18 AND B_AJZTXX.SCFY=B_YSQK.SCFY)  GROUP BY SCFY,FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY)
   WHEN matched then update set A.ZSSSS=B.SL WHERE A.SJQJ='''||v_sjqj||'''';--再审申诉数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(*) AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE KPLB IN(2,8,14) AND '||v_yjtj||' and  AH IN(SELECT AH FROM B_YSQK WHERE KPLB=18 AND B_AJZTXX.SCFY=B_YSQK.SCFY)  GROUP BY SCFY,FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY )
   WHEN matched then update set A.ESSSS=B.SL  WHERE A.SJQJ='''||v_sjqj||'''';--二审申诉数
end;
/

