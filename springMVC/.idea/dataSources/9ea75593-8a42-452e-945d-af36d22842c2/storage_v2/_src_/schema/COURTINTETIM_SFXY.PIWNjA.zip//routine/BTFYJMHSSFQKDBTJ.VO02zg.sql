create PROCEDURE BtFyJmhSsfQkDbTj(nscfy number,qsrq varchar2,jsrq varchar2, rt out pkg_row.myRow) AS
v_yjtj varchar2(200);
v_scfy varchar2(200);
v_qnqsrq varchar2(200);
v_qnjsrq varchar(20);
v_qnyjtj varchar2(200);
BEGIN
  v_qnqsrq:=to_char(add_months(to_date(qsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');
  v_qnjsrq:=to_char(add_months(to_date(jsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
  v_qnyjtj :=v_yjtj;
  v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
  v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
  v_qnyjtj :=replace(v_qnyjtj,'＆QsRq＆',v_qnqsrq);
  v_qnyjtj :=replace(v_qnyjtj,'＆JsRq＆',v_qnjsrq);
  INSERT INTO B_TEMPTJFX(kplb)values(1);--收费总数
  INSERT INTO B_TEMPTJFX(kplb)values(2);--缓交
  INSERT INTO B_TEMPTJFX(kplb)values(3);--减交
  INSERT INTO B_TEMPTJFX(kplb)values(4);--免交
  INSERT INTO B_TEMPTJFX(kplb)values(5);--减缓免

  execute immediate 'UPDATE B_TEMPTJFX SET XS=(select sum(je) from b_ssfjnjl where ajbs in(select ajbs from B_AJZTXX WHERE '||v_yjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND NVL(TF,2)=2) WHERE KPLB=1';--
  execute immediate 'UPDATE B_TEMPTJFX SET JC=(select sum(je) from b_ssfjnjl where ajbs in(select ajbs from B_AJZTXX WHERE '||v_yjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND NVL(TF,2)=1) WHERE KPLB=1';--今年退费总数
  UPDATE B_TEMPTJFX SET YJ=nvl(XS,0)-nvl(JC,0) WHERE KPLB=1 AND AJLB=1;--今年收费总数
  execute immediate 'UPDATE B_TEMPTJFX SET XSYJ=(select sum(je) from b_ssfjnjl where ajbs in(select ajbs from B_AJZTXX WHERE '||v_qnyjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND NVL(TF,2)=2) WHERE KPLB=1';--
  execute immediate 'UPDATE B_TEMPTJFX SET XSWJ=(select sum(je) from b_ssfjnjl where ajbs in(select ajbs from B_AJZTXX WHERE '||v_qnyjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND NVL(TF,2)=1) WHERE KPLB=1';--去年退费总数
  UPDATE B_TEMPTJFX SET SLS=nvl(XSYJ,0)-nvl(XSWJ,0) WHERE KPLB=1;--去年收费总数

  execute immediate 'UPDATE B_TEMPTJFX SET YJ=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND SQJZLX=1) WHERE KPLB=4';--今年免交
  execute immediate 'UPDATE B_TEMPTJFX SET SLS=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_qnyjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND SQJZLX=1) WHERE KPLB=4';--去年免交

  execute immediate 'UPDATE B_TEMPTJFX SET YJ=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND SQJZLX=2) WHERE KPLB=3';--今年减交
  execute immediate 'UPDATE B_TEMPTJFX SET SLS=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_qnyjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND SQJZLX=2) WHERE KPLB=3';--去年减交

  execute immediate 'UPDATE B_TEMPTJFX SET YJ=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND SQJZLX=3) WHERE KPLB=2 ';--今年缓交
  execute immediate 'UPDATE B_TEMPTJFX SET SLS=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_qnyjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15)) AND SQJZLX=3) WHERE KPLB=2 ';--去年缓交

  execute immediate 'UPDATE B_TEMPTJFX SET YJ=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15))) WHERE KPLB=5';--今年减交
  execute immediate 'UPDATE B_TEMPTJFX SET SLS=(SELECT SUM(SQJJJE) from B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_qnyjtj||' and '|| v_scfy ||' AND KPLB IN(7,8,9,12,21,13,14,15))) WHERE KPLB=5 ';--去年减交

  open rt for select * from B_TEMPTJFX;
END;
/

