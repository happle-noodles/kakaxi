create procedure P_KTCSTJJ(strscfy number,strksrq varchar2,strjsrq varchar2,rt out pkg_row.myRow )

as

begin

insert into B_TEMPTJFX (mc,kplb) select a.mc,a.kplb from B_kplb a where kplb in (1,2,3,7,8,9,13,14,15);

execute immediate 
'merge into B_TEMPTJFX A  
using (select count(1) as ktcs ,kplb from b_Ftsyjl  where ftyt=1 and scfy='''||strScfy||''' and pqrq between to_date('''||strksrq||''','|| '''yyyy-mm-dd'') and to_date('''||strjsrq||''',' || '''yyyy-mm-dd'') group by kplb ) B 
on (A.kplb=B.kplb) when matched then update set A.XS=B.ktcs';

execute immediate 
'merge into B_TEMPTJFX A 
using (select count(1) as ajs,kplb from B_ajztxx where ajbs in (select ajbs from b_Ftsyjl where ftyt=1 and scfy='''||strScfy||''' and pqrq between to_date('''||strksrq||''','|| '''yyyy-mm-dd'') and to_date('''||strjsrq||''','||'''yyyy-mm-dd'')) group by kplb) B 
on (A.Kplb=B.kplb) when matched then update set A.jc=B.ajs';

open rt for select 
sum(case when kplb in(1,2,3) then jc else 0 end) xsajs,
sum(case when kplb in(1,2,3) then xs else 0 end) xsktcs,
sum(case when kplb in(7,8,9) then jc else 0 end) msajs,
sum(case when kplb in(7,8,9) then xs else 0 end) msktcs,
sum(case when kplb in(13,14,15) then jc else 0 end) xzajs,
sum(case when kplb in(13,14,15) then xs else 0 end) xzktcs,
sum(case when kplb in(1,2,3,7,8,9,13,14,15) then jc else 0 end) hjajs,
sum(case when kplb in(1,2,3,7,8,9,13,14,15) then xs else 0 end) hjktcs
from B_TEMPTJFX;
end P_KTCSTJJ;

--
/

