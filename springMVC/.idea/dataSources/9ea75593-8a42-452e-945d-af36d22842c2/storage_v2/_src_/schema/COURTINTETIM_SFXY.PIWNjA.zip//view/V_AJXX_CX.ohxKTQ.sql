create view V_AJXX_CX as
  select A.AJBS,A.SCFY,A.KPLB,A.LAAY,nvl(A.AH,(case when (select ah from b_wslaajxx where ajbs=a.ajbs) is null then '' else '网上移送：'||(select ah from b_wslaajxx where ajbs=a.ajbs) end))AH, A.DSRMC,LARQ,A.CBRMC,A.SJYMC,
(CASE A.KPLB WHEN 29  THEN  ( SELECT B.MC FROM B_DM B WHERE B.BH='GF2009-06307' AND B.DM=A.LAAY) ELSE (SELECT B.AYNR FROM B_AY B WHERE B.AYDM = A.LAAY) END) AS LAAY1,
A.JARQ,A.CBR,A.SPR,FAR,A.SCR,A.SADJR,A.SPZZCY,A.AJLB,A.AJJZJD,yy.YHXM AS LAR,A.FZAH,b.gdrq,b.ajpcdj from b_ajfzxx b,B_AJZTXX A ,B_YHDM yy where  yy.YHDM(+)=SADJR AND yy.SCFY(+)=A.SCFY and a.ajbs=b.ajbs
/

