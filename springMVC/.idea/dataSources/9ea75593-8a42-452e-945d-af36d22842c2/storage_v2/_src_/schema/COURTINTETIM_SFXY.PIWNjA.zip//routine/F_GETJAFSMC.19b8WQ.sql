create FUNCTION F_GETJAFSMC(nkplb number,nJafs number,nAjlb number) return varchar2 is
  strMC nvarchar2(200);
  /*获取案件来源名称 徐新元*/
begin
  case (nkplb)
    when 1 then
      select mc into strMc from b_dm where bh='GF2009-02208' and dm=nJafs;
    when 2 then
      select mc into strMc from b_dm where bh='GF2009-02312' and dm=nJafs;
    when 3 then
      select mc into strMc from b_dm where bh='GF2009-02509' and dm=nJafs;
    when 4 then
      select mc into strMc from b_dm where bh='GF2009-02612' and dm=nJafs;
    when 5 then
      select mc into strMc from b_dm where bh='GF2009-02404' and dm=nJafs;
    when 7 then
      select mc into strMc from b_dm where bh='GF2009-03215' and dm=nJafs;
    when 8 then
      select mc into strMc from b_dm where bh='GF2009-03304' and dm=nJafs;
    when 9 then
      select mc into strMc from b_dm where bh='GF2009-03407' and dm=nJafs;
    when 21 then
      select mc into strMc from b_dm where bh='GF2009-03511' and dm=nJafs;
    when 12 then
      select mc into strMc from b_dm where bh='GF2009-03612' and dm=nJafs;
    when 13 then
      select mc into strMc from b_dm where bh='GF2009-04205' and dm=nJafs;
    when 14 then
      select mc into strMc from b_dm where bh='GF2009-04304' and dm=nJafs;
    when 15 then
      select mc into strMc from b_dm where bh='GF2009-04408' and dm=nJafs;
    when 16 then
      select mc into strMc from b_dm where bh='GF2014-00049' and dm=nJafs;
    when 28 then
      select mc into strMc from b_dm where bh='GF2009-06203' and dm=nJafs;
    when 29 then
      select mc into strMc from b_dm where bh='GF2009-06303' and dm=nJafs;
    when 17 then
      if(nAjlb=1) then
        select mc into strMc from b_dm where bh='GF2009-07209' and dm=nJafs;
      else
        select mc into strMc from b_dm where bh='GF2009-07309' and dm=nJafs;
      end if;
    when 18 then
      select mc into strMc from b_dm where bh='GF2009-08203' and dm=nJafs;
    when 40 then
      select mc into strMc from b_dm where bh='GF2016-911003' and dm=nJafs;
    when 41 then
      select mc into strMc from b_dm where bh='GF2016-911009' and dm=nJafs;
    when 42 then
      select mc into strMc from b_dm where bh='GF2016-911013' and dm=nJafs;
    when 44 then
      select mc into strMc from b_dm where bh='GF2016-903283' and dm=nJafs;
    when 45 then
      select mc into strMc from b_dm where bh='GF2016-902953' and dm=nJafs;
    when 46 then
      select mc into strMc from b_dm where bh='GF2016-902953' and dm=nJafs;
    when 47 then
      select mc into strMc from b_dm where bh='GF2016-902953' and dm=nJafs;
    when 48 then
      select mc into strMc from b_dm where bh='GF2016-907427' and dm=nJafs;
    when 49 then
      select mc into strMc from b_dm where bh='GF2016-914204' and dm=nJafs;
    when 50 then
      select mc into strMc from b_dm where bh='GF2014-00087' and dm=nJafs;
    when 51 then
      select mc into strMc from b_dm where bh='GF2014-00109' and dm=nJafs;
    when 52 then
      select mc into strMc from b_dm where bh='GF2014-00112' and dm=nJafs;
    when 53 then
      select mc into strMc from b_dm where bh='GF2017-00004' and dm=nJafs;
    when 54 then
      select mc into strMc from b_dm where bh='GF2017-00020' and dm=nJafs; 
    when 55 then
      select mc into strMc from b_dm where bh='GF2017-00026' and dm=nJafs; 
    when 56 then
      select mc into strMc from b_dm where bh='GF2017-00032' and dm=nJafs;   
    when 57 then
      select mc into strMc from b_dm where bh='GF2018-00022' and dm=nJafs; 
    when 58 then
      select mc into strMc from b_dm where bh='GF2017-00035' and dm=nJafs;
    when 59 then
      select mc into strMc from b_dm where bh='GF2017-00038' and dm=nJafs; 
    when 61 then
      select mc into strMc from b_dm where bh='GF2018-00004' and dm=nJafs; 
    when 62 then
      select mc into strMc from b_dm where bh='GF2018-00009' and dm=nJafs;   
    when 63 then
      select mc into strMc from b_dm where bh='GF2018-00012' and dm=nJafs;       
    when 43 then
      select mc into strMc from b_dm where bh='GF2018-00016' and dm=nJafs;                          
  end case;
  return strMc;
end;
/

