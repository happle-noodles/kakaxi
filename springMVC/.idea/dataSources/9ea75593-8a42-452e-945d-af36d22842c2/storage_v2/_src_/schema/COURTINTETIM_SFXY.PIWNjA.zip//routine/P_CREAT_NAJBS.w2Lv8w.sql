create procedure P_Creat_Najbs(v_ajbs in number := 16) as
v_ah varchar2(50);
v_scfy varchar(4);
v_yyyy varchar(4);
v_lsh varchar(6);
v_ajlx varchar(4);

n_kplb number;
n_ajlb number;
n_zsscajly number;
n_ztajlx number;
n_sqfyzdsx number;

begin
  select ah,scfy into v_ah,v_scfy from b_ajztxx where ajbs=v_ajbs;
  v_yyyy:=SUBSTR(v_ah,2,4);
  v_lsh:=SUBSTR(to_char(v_ajbs),10);
  if LENGTH(v_lsh)>0   
  then  
     select kplb,ajlb,zsscajly into n_kplb,n_ajlb,n_zsscajly from b_ajztxx where ajbs=v_ajbs;
     select ztajlx,sqfyzdsx into n_ztajlx,n_sqfyzdsx  from b_ajfzxx where ajbs=v_ajbs;
     v_ajlx:=GetSbAjlx(n_kplb,n_ajlb,n_ztajlx,n_zsscajly,n_sqfyzdsx);
     update b_ajztxx set newajbs=v_scfy||v_yyyy||v_ajlx||v_lsh where ajbs=v_ajbs and newajbs is null;
  end if;
end P_Creat_Najbs;
/

