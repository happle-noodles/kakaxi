create function GetSbAjlx(kplb number,ajlb number,ztajlx number,zsscajly number,sqfyzdsx number) return varchar2 is
  Result varchar2(5);
begin
  case kplb
    when 1 then
      Result :='0201';
    when 7 then
      Result :='0301';
    when 8 then
      Result :='0302'; 
    when 9 then
      Result :='0307'; 
    when 13 then
      Result :='0401';  
    when 16 then
      case ajlb
        when 1 then
          case ztajlx
            when 1 then 
              Result :='1002';
            when 2 then 
              Result :='1003';  
            when 3 then 
              Result :='1004';
            else
              Result :='1002'; 
            end case;  
        when 2 then 
          Result :='1006';
        when 3 then 
          Result :='1007';  
        when 4 then 
          Result :='1010'; 
        when 5 then 
          Result :='1009'; 
        when 6 then 
          Result :='1008';  
        end case;        
    when 2 then
      Result :='0202';  
    when 3 then
      Result :='0207'; 
    when 18 then
      case ajlb
        when 1 then
          case zsscajly
            when 1 then
              Result :='0204'; 
            when 2 then
              Result :='0205';   
            when 3 then
              Result :='0206'; 
            else 
              Result :='0204';   
          end case;   
        when 2 then
          case zsscajly
            when 1 then
              Result :='0304'; 
            when 2 then
              Result :='0305';   
            when 3 then
              Result :='0306'; 
            else 
              Result :='0304';   
          end case;     
        when 3 then
          case zsscajly
            when 1 then
              Result :='0404'; 
            when 2 then
              Result :='0405';   
            when 3 then
              Result :='0406'; 
            else 
              Result :='0404';      
           end case;  
        else
          Result :='0304';     
        end case;
      when 40 then
        if ajlb='1' then 
          Result :='0102'; 
        else
          Result :='0103'; 
        end if; 
      when 41 then 
        case ajlb 
          when 1 then
             Result :='0105';       
          when 2 then
             Result :='0106';
          when 3 then
             Result :='0107';   
          when 4 then
             Result :='0108';     
          when 5 then
             Result :='0110'; 
          when 6 then
             Result :='0109';
          else
             Result :='0105';    
          end case;
      when 42 then 
        case ajlb 
          when 1 then
             Result :='0112';       
          when 2 then
             Result :='0113';
          when 6 then
             Result :='0114';
          else
             Result :='0112';    
          end case; 
      when 43 then 
        case ajlb 
          when 1 then
             Result :='0116';       
          when 2 then
             Result :='0117';
          when 3 then
             Result :='0118';   
          when 4 then
             Result :='0119';
          else
             Result :='0112';    
          end case;  
    when 14 then
      Result :='0402';  
    when 61 then
      Result :='0208'; 
    when 62 then
      case ajlb 
        when 1 then 
          Result :='0214';   
        when 2 then 
          Result :='0215';   
        when 3 then 
          Result :='0216';
        when 4 then 
          Result :='0217'; 
        else
          Result :='0214';   
       end case;       
    when 63 then
      case ajlb 
        when 1 then 
          Result :='0219';   
        when 2 then 
          Result :='0220';   
        when 3 then 
          Result :='0221';
        when 4 then 
          Result :='0222'; 
        else
          Result :='0219';   
       end case;    
    when 4 then
      case ajlb 
        when 1 then 
          Result :='0224';   
        when 2 then 
          Result :='0225';   
        when 3 then 
          Result :='0226';
        else
          Result :='0224';   
       end case; 
    when 53 then
      case ajlb 
        when 1 then 
          Result :='0229';   
        when 2 then 
          Result :='0230';   
        when 3 then 
          Result :='0231';
        when 4 then 
          Result :='0232'; 
        else
          Result :='0229';   
       end case;
    when 45 then
      Result :='0227';      
    when 44 then
      Result :='0308'; 
    when 50 then
        if ajlb='1' then 
          Result :='0332'; 
        else
          Result :='0333'; 
        end if; 
    when 46 then
      Result :='0330';    
    when 15 then
      Result :='0407';   
    when 47 then
      Result :='0411';  
    when 12 then
      case ajlb 
        when 1 then 
          Result :='1102';   
        when 2 then 
          Result :='1103';   
        when 3 then 
          Result :='1105';
        when 4 then 
          Result :='1106'; 
        when 5 then 
          Result :='1108'; 
        when 6 then 
          Result :='1109';  
        when 7 then 
          Result :='1110';
        when 8 then 
          Result :='1112';    
        when 9 then 
          Result :='1113';  
        when 10 then 
          Result :='1114';       
        else
          Result :='1102';   
       end case; 
    when 54 then
      Result :='0502';  
    when 55 then
      Result :='0503';  
    when 56 then
      Result :='0507';
    when 57 then
      case ajlb 
        when 1 then 
          Result :='0504';   
        when 2 then 
          Result :='0505';   
        when 3 then 
          Result :='0506';    
        else
          Result :='0504';   
       end case; 
    when 58 then
      Result :='0508';
    when 17 then
      case ztajlx 
        when 1 then 
          Result :='0510';   
        when 2 then 
          Result :='0511';   
        when 3 then 
          Result :='0512';
        when 5 then 
          Result :='0513';
        when 6 then 
          Result :='0514'; 
        when 7 then 
          Result :='0515';
        when 8 then 
          Result :='0512';         
        else
          Result :='0510';   
       end case;
    when 59 then
      Result :='0516'; 
    when 48 then
      case ajlb 
        when 1 then 
          Result :='0518';   
        when 2 then 
          Result :='0519';   
        when 3 then 
          Result :='0520';
         when 4 then 
          Result :='0521';  
        when 5 then 
          Result :='0522';
        when 6 then 
          Result :='0523'; 
        when 30 then 
          Result :='0524';         
        else
          Result :='0519';   
       end case;  
    when 51 then
      case ztajlx 
        when 1 then 
          Result :='0602';   
        when 2 then 
          Result :='0603';   
        when 3 then 
          Result :='0604';
        when 4 then 
          Result :='0605';  
        when 5 then 
          Result :='0606';
        when 6 then 
          Result :='0607'; 
        when 7 then 
          Result :='0608';
        when 8 then 
          Result :='0609'; 
        when 9 then 
          Result :='0611'; 
        when 10 then 
          Result :='0612';
        when 11 then 
          Result :='0613';     
        when 12 then 
          Result :='0614';  
        when 13 then 
          Result :='0615';
        when 14 then 
          Result :='0616';   
        when 15 then 
          Result :='0617'; 
        when 16 then 
          Result :='0618';  
        when 17 then 
          Result :='0619';  
        when 18 then 
          Result :='0621';    
        when 19 then 
          Result :='0622'; 
        when 20 then 
          Result :='0623';  
        when 21 then 
          Result :='0624';  
        when 22 then 
          Result :='0625';      
        when 23 then 
          Result :='0626'; 
        when 24 then 
          Result :='0627';
        when 25 then 
          Result :='0628'; 
        when 26 then 
          Result :='0629';    
        when 27 then 
          Result :='0631';
        when 28 then 
          Result :='0632';    
        when 29 then 
          Result :='0634';
        when 30 then 
          Result :='0635';                                                                        
        else
          Result :='0602';   
       end case;    
    when 52 then
      case ztajlx 
        when 1 then 
          Result :='0702';   
        when 2 then 
          Result :='0703';   
        when 3 then 
          Result :='0704';
        when 4 then 
          Result :='0706';  
        when 5 then 
          Result :='0707';
        when 6 then 
          Result :='0708'; 
        when 7 then 
          Result :='0710';
        when 8 then 
          Result :='0711'; 
        when 9 then 
          Result :='0712'; 
        when 10 then 
          Result :='0714';
        when 11 then 
          Result :='0715';     
        when 12 then 
          Result :='0717';  
        when 13 then 
          Result :='0718';                                                                      
        else
          Result :='0702';   
       end case; 
    when 49 then
      if ajlb=1 then 
        if sqfyzdsx=2 then
          Result :='0802';   
        else
          Result :='0803';   
        end if;
      else
         Result :='0804';   
      end if;  
    when 29 then
      case ajlb 
        when 1 then 
          Result :='0901';   
        when 0 then
          Result :='0901';    
        when 2 then 
          Result :='0902';   
        when 3 then 
          Result :='0903';
        when 4 then  
          Result :='0904';                                                                     
        else
          Result :='0901';   
       end case;
    when 28 then
      case ajlb 
        when 1 then 
          Result :='0409'; 
        when 2 then 
          Result :='0410';                                                        
        else
          Result :='0410';   
       end case; 
    when 21 then
      case ztajlx 
        when 1 then 
          Result :='0310';   
        when 2 then 
          Result :='0311';   
        when 3 then 
          Result :='0312';
        when 4 then 
          Result :='0313';  
        when 5 then 
          Result :='0314';
        when 6 then 
          Result :='0315'; 
        when 7 then 
          Result :='0316';
        when 8 then 
          Result :='0317'; 
        when 9 then 
          Result :='0318'; 
        when 10 then 
          Result :='0319';
        when 11 then 
          Result :='0320';     
        when 12 then 
          Result :='0321';  
        when 13 then 
          Result :='0323';
        when 14 then 
          Result :='0325';   
        when 15 then 
          Result :='0326'; 
        when 16 then 
          Result :='0328';  
        when 17 then 
          Result :='0329';  
        when 18 then 
          Result :='0322';                                                                      
        else
          Result :='0310';   
       end case;                                                                   
    else
      Result :='0101';
  end case;   
  return(Result);
end GetSbAjlx;
/

