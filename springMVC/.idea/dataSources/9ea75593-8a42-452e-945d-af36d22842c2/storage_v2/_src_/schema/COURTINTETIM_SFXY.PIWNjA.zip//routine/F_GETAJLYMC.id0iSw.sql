create FUNCTION F_GETAJLYMC(nkplb number,nAjly number,nAjlb number) return varchar2 is
  strMC nvarchar2(200);
  /*获取案件来源名称 徐新元*/
begin
  case (nkplb)
    when 1 then
      select mc into strMc from b_dm where bh='GF2009-02202' and dm=nAjly;
    when 2 then
      select mc into strMc from b_dm where bh='GF2009-02304' and dm=nAjly;
    when 3 then
      select mc into strMc from b_dm where bh='GF2009-02503' and dm=nAjly;
    when 4 then
      strMc:='';
    when 5 then
      strMc:='';
    when 7 then
      select mc into strMc from b_dm where bh='GF2009-03202' and dm=nAjly;
    when 8 then
      select mc into strMc from b_dm where bh='GF2009-03004' and dm=nAjly;
    when 9 then
      select mc into strMc from b_dm where bh='GF2009-03401' and dm=nAjly;
    when 21 then
      select mc into strMc from b_dm where bh='GF2009-03504' and dm=nAjly;
    when 12 then
      select mc into strMc from b_dm where bh='GF2009-03603' and dm=nAjly;
    when 13 then
      select mc into strMc from b_dm where bh='GF2009-04201' and dm=nAjly;
    when 15 then
      select mc into strMc from b_dm where bh='GF2009-04401' and dm=nAjly;
    when 16 then
      select mc into strMc from b_dm where bh='GF2009-05008' and dm=nAjly;
    when 28 then
      select mc into strMc from b_dm where bh='GF2009-06005' and dm=nAjly;
    when 29 then
      select mc into strMc from b_dm where bh='GF2009-06005' and dm=nAjly;
    when 17 then
      if(nAjlb=1) then
        select mc into strMc from b_dm where bh='GF2009-07204' and dm=nAjly;
      else
        select mc into strMc from b_dm where bh='GF2009-07302' and dm=nAjly;
      end if;
    when 18 then
      select mc into strMc from b_dm where bh='GF2009-08002' and dm=nAjly;
    when 40 then
      select mc into strMc from b_dm where bh='GF2016-911001' and dm=nAjly;
    when 41 then
      select mc into strMc from b_dm where bh='GF2016-911022' and dm=nAjly;
    when 42 then
      select mc into strMc from b_dm where bh='GF2016-911010' and dm=nAjly;
    when 44 then
      select mc into strMc from b_dm where bh='GF2016-903282' and dm=nAjly;
    when 45 then
      select mc into strMc from b_dm where bh='GF2016-902951' and dm=nAjly;
    when 46 then
      select mc into strMc from b_dm where bh='GF2016-902951' and dm=nAjly;
    when 47 then
      select mc into strMc from b_dm where bh='GF2016-902951' and dm=nAjly;
    when 48 then
      select mc into strMc from b_dm where bh='GF2016-907426' and dm=nAjly;
    when 49 then
      select mc into strMc from b_dm where bh='GF2016-914201' and dm=nAjly;
    when 50 then
      select mc into strMc from b_dm where bh='GF2016-907426' and dm=nAjly;
    when 51 then
      select mc into strMc from b_dm where bh='GF2014-00108' and dm=nAjly;
    when 52 then
      select mc into strMc from b_dm where bh='GF2014-00111' and dm=nAjly;
    else
      strMc :='';
  end case;
  return strMc;
end;
/

