create procedure P_WSLA_TJFX(fytj varchar2,kssj varchar2,jssj varchar2,tjlx number, rt out pkg_row.myRow) is
v_scfy varchar2(200);
begin
  if tjlx=1 then
    v_scfy:='safy in(select dm from B_fy where b_fy.dm between 4166 and 4208 and '|| fytj ||')';
  else
    v_scfy:='slfy in(select dm from B_fy where b_fy.dm between 4166 and 4208 and '|| fytj ||')';
  end if;
  insert into b_temptjfx (dm,mc) select dm,mc from b_dm where bh='GF2016-00004';

  execute immediate 'merge into b_temptjfx  A
      using(select kplb,
      sum(decode(jd, 0, SL,0)) as SQZ,
      sum(decode(jd, 1, SL,0)) as SHZ,
      sum(decode(jd, 2, SL,0)) as FYDH,
      sum(decode(jd, 3, SL,0)) as TYLA,
      sum(decode(jd, 4, SL,0)) as BYSL,
      sum(decode(jd, 5, SL,0)) as YLA
      from  (select count(*) as sl ,nvl(ajjzjd,0) as jd,kplb  from b_wslaajxx where sqrq between to_date('''||kssj||''',''yyyy-MM-dd'') and to_date('''||jssj||''',''yyyy-MM-dd'') and '|| v_scfy ||' group by kplb,ajjzjd ) group by kplb) B
      ON (A.DM=B.KPLB) when matched then
      update set A.XS=B.SQZ,A.JC=B.SHZ,A.WJ=B.FYDH,A.YJ=B.TYLA,A.XSYJ=B.BYSL,A.XSWJ=B.YLA';
  open rt for select DM,MC,XS,JC,WJ,YJ,XSYJ,XSWJ from b_temptjfx order by dm;

end P_WSLA_TJFX;
/

