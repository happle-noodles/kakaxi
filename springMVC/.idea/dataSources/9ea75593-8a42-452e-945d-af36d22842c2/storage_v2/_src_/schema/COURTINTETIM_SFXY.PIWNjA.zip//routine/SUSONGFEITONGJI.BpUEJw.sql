create PROCEDURE SuSongFeiTongJi (nscfy number,qsrq varchar2,jsrq varchar2,vTj varchar2,vType varchar2,rt out pkg_row.myRow) as
v_tjsj varchar(400);
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   if vType='0' then
      v_tjsj :='('||v_xstj||' or '|| v_jctj||')';
   elsif  vType='1' then
      v_tjsj := v_xstj;
   elsif vType='2' then
      v_tjsj := v_jctj;
   elsif vType='3' then
      v_tjsj := '('||v_xstj||' and '|| v_yjtj||')';
   elsif vType='4' then
      v_tjsj := '('||v_yjtj||' and '|| v_jctj||')';
   elsif vType='5' then
      v_tjsj := v_yjtj;
   elsif vType='6' then
      v_tjsj := '('||v_xstj||' and '|| v_wjtj||')';
   elsif vType='7' then
      v_tjsj := '('||v_jctj||' and '|| v_wjtj||')';
   elsif vType='8' then
      v_tjsj := v_wjtj;
   end if;

   INSERT INTO B_TEMPTJFX(KPLB,MC) values(7,'民事一审案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(8,'民事二审案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(9,'民事再审案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(10,'民事案件合计');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(12,'民事特殊案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(21,'民事破产案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(13,'行政一审案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(14,'行政二审案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(15,'行政再审案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(30,'行政案件合计');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(16,'执行案件');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(40,'执行案件合计');
   INSERT INTO B_TEMPTJFX(KPLB,MC) values(50,'总合计');

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(qsbdje)SL,FZKPLB FROM B_AJZTXX WHERE  fzkplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||' GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.XS=B.SL';--分案件类型诉讼标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(jabdje)SL,FZKPLB FROM B_AJZTXX WHERE  fzkplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||' GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.JC=B.SL';--分案件类型结案标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(ajslf)SL,FZKPLB FROM B_AJZTXX WHERE  fzkplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||' GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.SLS=B.SL';--分案件类型应交金额

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(qsbdje)SL FROM B_AJZTXX WHERE  fzkplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=10)
    when matched then update set A.XS=B.SL';--民事合计诉讼标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(jabdje)SL FROM B_AJZTXX WHERE  fzkplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=10)
    when matched then update set A.JC=B.SL';--民事合计结案标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(ajslf)SL FROM B_AJZTXX WHERE  fzkplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=10)
    when matched then update set A.SLS=B.SL';--民事合计应交金额标的

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(qsbdje)SL FROM B_AJZTXX WHERE  fzkplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=30)
    when matched then update set A.XS=B.SL';--行政合计诉讼标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(jabdje)SL FROM B_AJZTXX WHERE  fzkplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=30)
    when matched then update set A.JC=B.SL';--行政合计结案标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(ajslf)SL FROM B_AJZTXX WHERE  fzkplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=30)
    when matched then update set A.SLS=B.SL';--行政合计应交金额
      
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(qsbdje)SL FROM B_AJZTXX WHERE  fzkplb=16 and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=40)
    when matched then update set A.XS=B.SL';--执行合计诉讼标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(jabdje)SL FROM B_AJZTXX WHERE  fzkplb=16 and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=40)
    when matched then update set A.JC=B.SL';--执行合计结案标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(ajslf)SL FROM B_AJZTXX WHERE  fzkplb=16 and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=40)
    when matched then update set A.SLS=B.SL';--执行合计应交金额

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(qsbdje)SL FROM B_AJZTXX WHERE  fzkplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=50)
    when matched then update set A.XS=B.SL';--总合计诉讼标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(jabdje)SL FROM B_AJZTXX WHERE  fzkplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=50)
    when matched then update set A.JC=B.SL';--总合计结案标的
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(ajslf)SL FROM B_AJZTXX WHERE  fzkplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||')B
    ON(A.KPLB=50)
    when matched then update set A.SLS=B.SL';--总合计应缴金额

    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL,KPLB FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=3 GROUP BY B_SSFSFJZQK.KPLB)B
    ON(A.KPLB=B.KPLB)
    when matched then update set A.XSYJ=B.SL';--各案件类型缓交金额
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=3)B
    ON(A.KPLB=10)
    when matched then update set A.XSYJ=B.SL';--民事合计缓交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=3)B
    ON(A.KPLB=30)
    when matched then update set A.XSYJ=B.SL';--行政合计缓交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb=16 and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=3)B
    ON(A.KPLB=40)
    when matched then update set A.XSYJ=B.SL';--执行合计缓交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=3 )B
    ON(A.KPLB=50)
    when matched then update set A.XSYJ=B.SL';--总合计缓交金额

    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL,KPLB FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=2 GROUP BY B_SSFSFJZQK.KPLB)B
    ON(A.KPLB=B.KPLB)
    when matched then update set A.XSWJ=B.SL';--各案件类型减交金额
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=2)B
    ON(A.KPLB=10)
    when matched then update set A.XSWJ=B.SL';--民事合计减交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=2)B
    ON(A.KPLB=30)
    when matched then update set A.XSWJ=B.SL';--行政合计减交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb=16 and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=2)B
    ON(A.KPLB=40)
    when matched then update set A.XSWJ=B.SL';--执行合计减交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=2 )B
    ON(A.KPLB=50)
    when matched then update set A.XSWJ=B.SL';--总合计减交金额

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL,KPLB FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=1 GROUP BY B_SSFSFJZQK.KPLB)B
    ON(A.KPLB=B.KPLB)
    when matched then update set A.JCYJ=B.SL';--各案件类型免交金额
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=1)B
    ON(A.KPLB=10)
    when matched then update set A.JCYJ=B.SL';--民事合计免交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=1)B
    ON(A.KPLB=30)
    when matched then update set A.JCYJ=B.SL';--行政合计免交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb=16 and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=1)B
    ON(A.KPLB=40)
    when matched then update set A.JCYJ=B.SL';--执行合计免交金额
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(SQJJJE)SL FROM B_SSFSFJZQK WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND SQJZLX=1 )B
    ON(A.KPLB=50)
    when matched then update set A.JCYJ=B.SL';--总合计免交金额

  --dbms_output.put_line('SELECT sum(je)SL,KPLB FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=2) GROUP BY b_ssfjnjl.KPLB');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL,KPLB FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=2 GROUP BY b_ssfjnjl.KPLB)B
    ON(A.KPLB=B.KPLB)
    when matched then update set A.WJYC=B.SL';--各案件类型收费总额
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=2)B
    ON(A.KPLB=10)
    when matched then update set A.WJYC=B.SL';--民事合计收费总额
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=2)B
    ON(A.KPLB=30)
    when matched then update set A.WJYC=B.SL';--行政合计收费总额
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb=16 and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=2)B
    ON(A.KPLB=40)
    when matched then update set A.WJYC=B.SL';--执行合计收费总额    
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=2)B
    ON(A.KPLB=50)
    when matched then update set A.WJYC=B.SL';--总合计收费总额

    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL,KPLB FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=1 GROUP BY b_ssfjnjl.KPLB)B
    ON(A.KPLB=B.KPLB)
    when matched then update set A.YJYC=B.SL';--各案件类型收费总额
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=1)B
    ON(A.KPLB=10)
    when matched then update set A.YJYC=B.SL';--民事合计收费总额
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(13,14,15) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=1)B
    ON(A.KPLB=30)
    when matched then update set A.YJYC=B.SL';--行政合计收费总额
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb=16 and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=1)B
    ON(A.KPLB=40)
    when matched then update set A.YJYC=B.SL';--执行合计收费总额    
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT sum(je)SL FROM b_ssfjnjl WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  kplb in(7,8,9,12,21,13,14,15,16) and '||v_scfy||' and '||v_tjsj||') AND NVL(TF,2)=1)B
    ON(A.KPLB=50)
    when matched then update set A.YJYC=B.SL';--总合计收费总额

   UPDATE B_TEMPTJFX SET WJZZ=nvl(WJYC,0)-nvl(YJYC,0);

  open rt for select * from B_TEMPTJFX;
end;
/

