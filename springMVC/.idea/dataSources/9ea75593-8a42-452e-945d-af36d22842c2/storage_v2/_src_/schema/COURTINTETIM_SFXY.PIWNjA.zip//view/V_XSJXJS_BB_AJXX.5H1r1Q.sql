create view V_XSJXJS_BB_AJXX as
  select AJBS,KPLB,AH,to_char(LARQ,'yyyy"年"MM"月"dd"日"')LARQ,(select AYNR  from B_AY where AYDM=B_AJZTXX.LAAY)LAAY,
(select (select AYNR from B_AY where AYDM=B_ZKZM.ZM and SCFY=B_ZKZM.SCFY) from B_ZKZM where SFBZ=(select MAX(SFBZ) from B_ZKZM where AJBS=B_AJZTXX.AJBS))ZM,(select BQJG from B_AJFZXX where AJBS=B_AJZTXX.AJBS)BQJG,
(select (select MC from B_DM where BH='GF2009-02603' AND DM=B_AJFZXX.XFBGLX) from B_AJFZXX where AJBS=B_AJZTXX.AJBS)XFBGLX,(select (select MC from B_DM where BH='GF2009-02604' AND DM=B_AJFZXX.JSLX) from B_AJFZXX where AJBS=B_AJZTXX.AJBS)JSLX,
(select to_char(sdszrq,'yyyy"年"MM"月"dd"日"') from B_AJFZXX where AJBS=B_AJZTXX.AJBS)SDCLRQ,--收到材料日期用的是 收到诉状日期
(select (select AYNR from B_AY where AYDM=B_YSQK.AY and SCFY=B_YSQK.SCFY) from B_YSQK where SFBZ=(SELECT MAX(SFBZ) from B_YSQK where AJBS=B_AJZTXX.AJBS AND SPCX=1))ZM1,
(select (select FYMC from B_FY where DM=B_YSQK.JBFY) from B_YSQK where SFBZ=(SELECT MAX(SFBZ) from B_YSQK where AJBS=B_AJZTXX.AJBS AND SPCX=1))YSFY1,
(select (select AYNR from B_AY where AYDM=B_YSQK.AY and SCFY=B_YSQK.SCFY) from B_YSQK where SFBZ=(SELECT MAX(SFBZ) from B_YSQK where AJBS=B_AJZTXX.AJBS AND SPCX=2))ZM2,
(select (select FYMC from B_FY where DM=B_YSQK.JBFY) from B_YSQK where SFBZ=(SELECT MAX(SFBZ) from B_YSQK where AJBS=B_AJZTXX.AJBS AND SPCX=2))YSFY2,
(select (select AYNR from B_AY where AYDM=B_YSQK.AY and SCFY=B_YSQK.SCFY) from B_YSQK where SFBZ=(SELECT MAX(SFBZ) from B_YSQK where AJBS=B_AJZTXX.AJBS AND SPCX=11))ZM3,
(select (select FYMC from B_FY where DM=B_YSQK.JBFY) from B_YSQK where SFBZ=(SELECT MAX(SFBZ) from B_YSQK where AJBS=B_AJZTXX.AJBS AND SPCX=11))YSFY3,(select XFXDD from B_AJFZXX where AJBS=B_AJZTXX.AJBS)XFXDD,
(select YFXQN from B_AJFZXX where AJBS=B_AJZTXX.AJBS)YFXQN,(select YFXQY from B_AJFZXX where AJBS=B_AJZTXX.AJBS)YFXQY,(select YFXQR from B_AJFZXX where AJBS=B_AJZTXX.AJBS)YFXQR,
(select (select MC from B_DM where BH='GF2009-02606' AND DM=B_AJFZXX.BQLY) from B_AJFZXX where AJBS=B_AJZTXX.AJBS)BQLY,(select MC from B_DM where BH='GF2009-02605' AND DM=B_AJZTXX.SCYJ)SCYJ,(select MC from B_DM where BH='GF2009-02605' AND DM=B_AJZTXX.SPYJ)SPYJ,(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SCR AND SCFY=B_AJZTXX.SCFY)SCR,to_char(SCRQ,'yyyy"年"MM"月"dd"日"')SCRQ,
(select YHXM from B_YHDM  where YHDM=B_AJZTXX.SPR AND SCFY=B_AJZTXX.SCFY)SPR,to_char(LASPRQ,'yyyy"年"MM"月"dd"日"')SPRQ,(select BZ from B_AJFZXX where AJBS=B_AJZTXX.AJBS)BZ,(select TSMC from B_TSDM where TSDM=B_AJZTXX.CBSPT AND SCFY=B_AJZTXX.SCFY)CBSPT,
(select (select YHXM from B_YHDM where YHDM=B_SPZZCY.YCY AND SCFY=B_SPZZCY.SCFY) from B_SPZZCY where JS=3 AND AJBS=B_AJZTXX.AJBS and rownum=1)SPZ
 from B_AJZTXX where KPLB=4
/

