create PROCEDURE p_text(nscfy number,qsrq varchar2,jsrq varchar2,rt out pkg_row.myRow) as
/*部门统计分析 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_ycaj varchar2(100);
v_zzaj varchar2(100);
v_csx  varchar2(200);
v_fztj  varchar2(200);
v_tsdm  varchar2(50);
v_jafsmc varchar(1000);

begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   v_csx :=replace(v_csx,'＆JsRq＆',jsrq);
   v_fztj:='A.KPLB=C.KPLB ';
    v_scfy :=v_scfy||' and  1=1' ;
   
   INSERT INTO B_TEMP(KPLB,MC,XSSX) SELECT A.KPLB,A.MC,A.XSSX FROM B_kplb A;
   execute immediate 'UPDATE B_TEMP A SET A.XS=(SELECT COUNT(kplb) FROM (select (case when kplb =18 then nvl(ajlb,0)+kplb+4 else kplb end) as kplb from b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb||' AND '  || v_xstj || ')C  WHERE '|| v_fztj ||'  group by c.kplb)';/*新收 */
   execute immediate 'UPDATE B_TEMP A SET A.JC=(SELECT COUNT(kplb) FROM (select (case when kplb =18 then nvl(ajlb,0)+kplb+4 else kplb end) as kplb from b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_jctj || ')C  WHERE '|| v_fztj ||'  group by c.kplb)';/*旧存*/
   execute immediate 'UPDATE B_TEMP A SET A.YJ=(SELECT COUNT(kplb) FROM (select (case when kplb =18 then nvl(ajlb,0)+kplb+4 else kplb end) as kplb from b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj || ')C  WHERE '|| v_fztj ||'  group by c.kplb)';/*已结*/
   execute immediate 'UPDATE B_TEMP A SET A.WJ=(SELECT COUNT(kplb) FROM (select (case when kplb =18 then nvl(ajlb,0)+kplb+4 else kplb end) as kplb from b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_wjtj || ')C  WHERE '|| v_fztj ||'  group by c.kplb)';/*未结 */
  
   insert into B_TEMP(KPLB,MC,XSSX)values(-1,'合计',50);
   update B_TEMP set XS=(select sum(XS) from B_TEMP) where kplb=-1;
   update B_TEMP set JC=(select sum(JC) from B_TEMP) where kplb=-1;
   update B_TEMP set YJ=(select sum(YJ) from B_TEMP) where kplb=-1;
   update B_TEMP set WJ=(select sum(WJ) from B_TEMP) where kplb=-1;
   
   update B_TEMP A SET A.SLS=NVL(A.XS,0)+NVL(A.JC,0);/*受理数*/

   open rt for SELECT KPLB,MC,XSSX,XS,JC,YJ,WJ,SLS FROM  B_TEMP ORDER BY XSSX;
end p_text;
/

