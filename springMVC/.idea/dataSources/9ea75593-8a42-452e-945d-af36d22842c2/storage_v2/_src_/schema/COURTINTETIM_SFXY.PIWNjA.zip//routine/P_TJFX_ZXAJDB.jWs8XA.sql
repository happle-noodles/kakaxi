create procedure p_tjfx_zxajdb(fytj varchar2,qsrq varchar2,jsrq varchar2,qnksrq varchar2,qnjsrq varchar2 ,rt out pkg_row.myRow) as
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);

v_qnxstj varchar2(200);
v_qnyjtj varchar2(200);
v_qnjctj varchar2(200);


v_sql varchar(4000);

begin
   v_scfy:='SCFY BETWEEN 4166 AND 4208 AND KPLB=16 AND '|| fytj;
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   v_qnxstj:=v_xstj;
   v_qnyjtj:=v_yjtj;
   v_qnjctj:=v_jctj;
   
   v_qnxstj :=replace(v_qnxstj,'＆QsRq＆',qnksrq);
   v_qnxstj :=replace(v_qnxstj,'＆JsRq＆',qnjsrq);
   v_qnyjtj :=replace(v_qnyjtj,'＆QsRq＆',qnksrq);
   v_qnyjtj :=replace(v_qnyjtj,'＆JsRq＆',qnjsrq);
   v_qnjctj :=replace(v_qnjctj,'＆QsRq＆',qnksrq);
   
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
    v_sql := 'select b.dm,b.mc,b.jnsl,c.qnsl from (';
    v_sql := v_sql|| ' SELECT COUNT(*) AS JNSL,''受理数'' AS MC,-1 AS DM FROM B_AJZTXX WHERE ' ||v_scfy||' AND ('|| v_xstj ||' OR '|| v_jctj||')';
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS JNSL,''新收'' AS MC,-2 AS DM FROM B_AJZTXX WHERE '||v_scfy|| ' AND '|| v_xstj;
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS JNSL,''旧存'' AS MC,-3 AS DM FROM B_AJZTXX WHERE '||v_scfy|| 'AND '|| v_jctj ;
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS JNSL,(select mc from b_dm where bh=''GF2014-00049'' and dm=jafs) AS MC,JAFS AS DM FROM B_AJZTXX WHERE '||v_scfy|| 'AND'|| v_yjtj ||' group by jafs';
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS JNSL,''已结'' AS MC,100 AS DM FROM B_AJZTXX WHERE '||v_scfy|| 'AND'|| v_yjtj;
    v_sql := v_sql|| ' )b ';
    v_sql := v_sql|| ' left join ';
    v_sql := v_sql|| ' (SELECT COUNT(*) AS QNSL,''受理数'' AS MC,-1 AS DM FROM B_AJZTXX WHERE ' ||v_scfy||' AND ('|| v_qnxstj ||' OR '|| v_qnjctj||')';
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS QNSL,''新收'' AS MC,-2 AS DM FROM B_AJZTXX WHERE '||v_scfy|| ' AND '|| v_qnxstj;
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS QNSL,''旧存'' AS MC,-3 AS DM FROM B_AJZTXX WHERE '||v_scfy|| 'AND '|| v_qnjctj ;
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS QNSL,(select mc from b_dm where bh=''GF2014-00049'' and dm=jafs) AS MC,JAFS AS DM FROM B_AJZTXX WHERE '||v_scfy|| 'AND'|| v_qnyjtj ||' group by jafs';
    v_sql := v_sql|| ' union all '; 
    v_sql := v_sql|| ' SELECT COUNT(*) AS QNSL,''已结'' AS MC,100 AS DM FROM B_AJZTXX WHERE '||v_scfy|| 'AND'|| v_qnyjtj;
    v_sql := v_sql|| ' )c on b.dm=c.dm  where b.dm is not null order by b.dm';
   -- dbms_output.put_line(v_sql);
    open rt for v_sql;
end p_tjfx_zxajdb;
/

