create FUNCTION                   F_GETAY(nAy number) return varchar2 is
  strMC nvarchar2(200);
  /*获取案由名称 杨元胜*/
begin
  SELECT AYNR INTO strMC FROM B_AY  WHERE AYDM = nAy;
  RETURN strMC;
end;

/

