create PROCEDURE p_bgpt_grsjatj(nscfy number,qsrq varchar2,jsrq varchar2,nyhdm number,rt out pkg_row.myRow) as
/*办公平台个人收结案情况统计 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
nyhdm 承办人
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);

begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   v_scfy :=v_scfy||' and cbr='|| nyhdm;

   insert into B_TEMPTJFX(DM,XSSX)values(0,0);
   execute immediate 'UPDATE B_TEMPTJFX A SET A.XS=(SELECT COUNT(ajbs) FROM B_AJZTXX B WHERE '||v_scfy||' AND '|| v_kplb||'  AND ' || v_xstj || ')';/*新收已结 */
   execute immediate 'UPDATE B_TEMPTJFX A SET A.JC=(SELECT COUNT(ajbs) FROM B_AJZTXX B WHERE '||v_scfy||' AND '|| v_kplb||'  AND ' || v_jctj || ')';/*新收未结*/
   execute immediate 'UPDATE B_TEMPTJFX A SET A.YJ=(SELECT COUNT(ajbs) FROM B_AJZTXX B WHERE '||v_scfy||' AND '|| v_kplb||'  AND ' || v_yjtj || ')';/*旧存已结*/
   execute immediate 'UPDATE B_TEMPTJFX A SET A.WJ=(SELECT COUNT(ajbs) FROM B_AJZTXX B WHERE '||v_scfy||' AND '|| v_kplb||'  AND ' || v_wjtj || ')';/*旧存未结 */



   update B_TEMPTJFX A SET A.SLS=NVL(A.XS,0)+NVL(A.JC,0);/*受理数*/
   update B_TEMPTJFX A SET A.JAL=100*NVL(A.YJ,0)/A.SLS WHERE  A.SLS>0;/*结案率*/


   open rt for SELECT DM,XS,JC,YJ,WJ,SLS,JAL FROM  B_TEMPTJFX;
end p_bgpt_grsjatj;

/

