create PROCEDURE P_TJFX_GRBAZQ(nscfy number,qsrq varchar2,jsrq varchar2,tsdm number,rt out pkg_row.myRow) as
/*个人办案周期分析 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_ycaj varchar2(100);
v_kcaj  varchar2(200);
v_sxnsj varchar2(300);
v_sxbg  varchar2(100);
v_sjslts varchar2(300);
begin
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   select gsnr into v_ycaj  from b_tjfxgs where gsmc='延长审限';
   select gsnr into v_kcaj   from b_tjfxgs where gsmc='中止审限';
   select gsnr into v_sxnsj   from b_tjfxgs where gsmc='审限内审结';
   select gsnr into v_sxbg   from b_tjfxgs where gsmc='审限变更';
   select gsnr into v_sjslts   from b_tjfxgs where gsmc='实际审理天数';

   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
   v_sxnsj :=replace(v_sxnsj,'＆JsRq＆',jsrq);


  if tsdm=0
  then
     execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) select a.yhdm,a.yhxm from B_YHDM a,b_tsdm b  WHERE a.SCFY='||nscfy||' and b.scfy='||nscfy||' and a.tsdm=b.tsdm order by b.xssx,a.xssx ';
     INSERT INTO B_TEMPTJFX(dm,MC,XSSX) SELECT -2,'待分案',1000 from dual;
  else
      execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) select a.yhdm,a.yhxm from B_YHDM a,b_tsdm b  WHERE a.SCFY='||nscfy||' and b.scfy='||nscfy||' and a.tsdm=b.tsdm and a.tsdm='||tsdm||' order by b.xssx,a.xssx ';
  end if;

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.YJ=B.SL ';--已结数
   
   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_wjtj ||' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.WJ=B.SL ';/*未结*/

     execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND ' || v_ycaj || ' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.YJYC=B.SL ';/*已结延长*/

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND ' || v_kcaj || ' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.YJZZ=B.SL ';/*已结扣除*/
     
   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND ' || v_sxbg || ' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.SXBGS=B.SL ';/*已结审限变更*/
     
   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND ' || v_sxnsj || ' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.SXNSJ=B.SL ';/*审限内审结*/   
     
   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT SUM('|| v_sjslts ||') AS SL,CBR FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' group by CBR)B
   ON(A.DM=nvl(B.CBR,-2))
   when matched then update set A.SJSLTS=B.SL ';/*审理天数*/     
   
  --execute immediate 'UPDATE B_TEMPTJFX A SET A.YJ=(SELECT COUNT(*) FROM   b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' AND scfy='||nscfy||' and A.DM=nvl(B.CBR,-2) group by CBR)';/*已结 */
  -- execute immediate 'UPDATE B_TEMPTJFX A SET A.WJ=(SELECT COUNT(*) FROM   b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_wjtj ||' AND scfy='||nscfy||' AND A.DM=nvl(B.CBR,-2) group by CBR)';/*未结*/
   --execute immediate 'UPDATE B_TEMPTJFX A SET A.YJYC=(SELECT COUNT(*) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_ycaj || ' AND scfy='||nscfy||'  AND A.DM=nvl(B.CBR,-2) group by CBR)';/*已结延长 */
  -- execute immediate 'UPDATE B_TEMPTJFX A SET A.YJZZ=(SELECT COUNT(*) FROM  b_ajztxx  B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_kcaj || ' AND scfy='||nscfy||'  AND A.DM=nvl(B.CBR,-2)  group by CBR)';/*已结扣除 */
   --execute immediate 'UPDATE B_TEMPTJFX A SET A.SXBGS=(SELECT COUNT(*) FROM  b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_sxbg || ' AND scfy='||nscfy||' AND A.DM=nvl(B.CBR,-2)  group by CBR)';/*已结审限变更 */
  --execute immediate 'UPDATE B_TEMPTJFX A SET A.SXNSJ=(SELECT COUNT(*) FROM  b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND' || v_sxnsj || '  AND scfy='||nscfy||' AND A.DM=nvl(B.CBR,-2)  group by CBR)';/*审限内审结 */
  -- execute immediate 'UPDATE B_TEMPTJFX A SET A.SJSLTS=(SELECT SUM('|| v_sjslts ||') FROM  b_ajztxx B WHERE '||v_scfy||' AND '|| v_kplb|| ' AND ' || v_yjtj ||' AND scfy='||nscfy||' AND A.DM=nvl(B.CBR,-2)  group by CBR)';/*审限内审结 */


   insert into B_TEMPTJFX(DM,MC,XSSX)values(0,'合计',0);


    update B_TEMPTJFX set YJ=(select sum(YJ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set WJ=(select sum(WJ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set YJYC=(select sum(YJYC) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set YJZZ=(select sum(YJZZ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set SXBGS=(select sum(SXBGS) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set SXNSJ=(select sum(SXNSJ) from B_TEMPTJFX) where DM=0;
    update B_TEMPTJFX set SJSLTS=(select sum(SJSLTS) from B_TEMPTJFX) where DM=0;


    update B_TEMPTJFX A SET A.SLS=NVL(A.YJ,0)+NVL(A.WJ,0);/*受理数*/
    update B_TEMPTJFX A SET A.JAL=100*NVL(A.YJ,0)/A.SLS WHERE  A.SLS>0;/*结案率*/
    update B_TEMPTJFX A SET A.SJSLTS=round(NVL(A.SJSLTS,0)/A.YJ,0) WHERE  A.YJ>0;/*平均审理天数*/
    update B_TEMPTJFX A SET A.SXNSJ=round(100*NVL(A.SXNSJ,0)/A.YJ,2) WHERE  A.YJ>0;/*审限内审结率*/

    open rt for SELECT DM,MC,NVL(SLS,0) AS SLS,NVL(YJ,0) AS YJ,NVL(SJSLTS,0) AS SJSLTS,NVL(YJYC,0) AS YJYC,NVL(YJZZ,0) AS YJZZ,NVL(SXBGS,0) AS SXBGS,NVL(JAL,0) AS JAL, NVL(SXNSJ,0) AS SXNSJ  FROM  B_TEMPTJFX where sls>0 ;

end P_TJFX_GRBAZQ;
/

