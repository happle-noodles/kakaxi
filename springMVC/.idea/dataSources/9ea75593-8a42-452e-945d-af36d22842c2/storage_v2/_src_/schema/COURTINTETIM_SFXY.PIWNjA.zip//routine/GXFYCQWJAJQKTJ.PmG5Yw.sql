create PROCEDURE GxFyCqWjAjQkTj(fydm varchar2,qsrq varchar2,jsrq varchar2, rt out pkg_row.myRow) as
v_kplb varchar2(100);
v_qsrq varchar2(80);
v_jsrq varchar2(80);
v_wjtj varchar2(200);
begin
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
  INSERT INTO B_TEMPTJFX(kplb) select distinct(fzkplb) from b_ajztxx order by fzkplb;
  UPDATE B_TEMPTJFX SET MC=(SELECT MC FROM B_KPLB WHERE KPLB=B_TEMPTJFX.KPLB);
  INSERT INTO B_TEMPTJFX(kplb,mc)values(100,'合计');
  select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
  v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
  dbms_output.put_line('SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=12 GROUP BY B_AJZTXX.FZKPLB');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=12 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.XS=B.SL';--一年以上
      
   dbms_output.put_line('SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=18 GROUP BY B_AJZTXX.FZKPLB'); 
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=18 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.JC=B.SL';--18以上 
      
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=24 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.YJ=B.SL';--二年以上 
      
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=36 GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.WJ=B.SL';--三年以上 
      
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=12 )B
    ON(1=1)
    when matched then update set A.XS=B.SL WHERE KPLB=100';--合计一年以上
      
  -- dbms_output.put_line('SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=18 GROUP BY B_AJZTXX.FZKPLB'); 
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=18 )B
    ON(1=1)
    when matched then update set A.JC=B.SL  WHERE KPLB=100';--合计18以上 
      
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=24 )B
    ON(1=1)
    when matched then update set A.YJ=B.SL  WHERE KPLB=100';--合计二年以上 
      
    execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE scfy in( '||fydm||') AND '||v_kplb||' and '||v_wjtj||' AND months_between(TO_DATE('''||jsrq||''',''yyyy-MM-dd''),larq)>=36)B
    ON(1=1)
    when matched then update set A.WJ=B.SL  WHERE KPLB=100';--合计三年以上  
  
  /*v_qsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -18),'yyyy-mm-dd');
  v_jsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -12),'yyyy-mm-dd');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd'') GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.XS=B.SL';--一年以上,18月以下
      
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd''))B
    ON(1=1)
    when matched then update set A.XS=B.SL WHERE A.KPLB=100';--合计一年以上,18月以下
 
  v_qsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -24),'yyyy-mm-dd');
  v_jsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -18),'yyyy-mm-dd');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd'') GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.JC=B.SL';--18月以上，2年以下
      
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd''))B
    ON(1=1)
    when matched then update set A.JC=B.SL where KPLB=100';--合计18月以上，2年以下
      
  v_qsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -36),'yyyy-mm-dd');
  v_jsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -24),'yyyy-mm-dd');
   dbms_output.put_line('SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd'') GROUP BY B_AJZTXX.FZKPLB');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd'') GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.YJ=B.SL';--2年以上,3年一下
      
   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ BETWEEN TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') and TO_DATE('''||v_jsrq||''',''yyyy-MM-dd''))B
    ON(1=1)
    when matched then update set A.YJ=B.SL where KPLB=100';--合计2年以上,3年一下  
  
  v_qsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -36),'yyyy-mm-dd');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,FZKPLB FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ < TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'')  GROUP BY B_AJZTXX.FZKPLB)B
    ON(A.KPLB=B.FZKPLB)
    when matched then update set A.WJ=B.SL';--3年以上
      
   v_qsrq :=to_char(add_months(to_timestamp(qsrq,'yyyy-mm-dd'), -36),'yyyy-mm-dd');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE jarq is null and scfy in( '||fydm||') AND '||v_kplb||' and LARQ < TO_DATE('''||v_qsrq||''',''yyyy-MM-dd'') )B
    ON(1=1)
    when matched then update set A.WJ=B.SL WHERE KPLB=100';*/--合计3年以上  
      
    
 open rt for select * from B_TEMPTJFX WHERE XS>0 OR JC>0 OR YJ>0 OR WJ>0 order by kplb;
end ;
/

