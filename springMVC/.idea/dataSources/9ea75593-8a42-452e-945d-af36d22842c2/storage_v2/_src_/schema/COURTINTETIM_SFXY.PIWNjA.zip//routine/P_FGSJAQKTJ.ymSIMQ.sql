create PROCEDURE P_FGSJAQKTJ(nscfy number,qsrq varchar2,jsrq varchar2, rt out pkg_row.myRow) as
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_tjs varchar2(300);
v_css varchar2(1000);
BEGIN
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
  select gsnr into v_tjs  from b_tjfxgs where gsmc='调解数';
  select gsnr into v_css  from b_tjfxgs where gsmc='撤诉数';
  v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
  v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
  v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
  v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);

  execute immediate'INSERT INTO B_TEMPTJFX(MC,DM,KPLB) SELECT A.YHXM,A.YHDM,-1 KPLB FROM B_YHDM A where scfy='||nscfy;
 -- execute immediate'INSERT INTO B_TEMPTJFX(MC,DM,KPLB) SELECT A.YHXM,A.YHDM,22 KPLB FROM B_YHDM A where scfy='||nscfy;
  execute immediate'INSERT INTO B_TEMPTJFX(MC,DM,KPLB) SELECT A.YHXM,A.YHDM,4 KPLB FROM B_YHDM A where scfy='||nscfy;
  execute immediate'insert into B_TEMPTJFX(MC,DM,KPLB) values(1,-1,-2)';
  execute immediate'insert into B_TEMPTJFX(MC,DM,KPLB) values(1,-2,-3)';

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||'  AND KPLB<>4 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.YJ=B.SL WHERE KPLB=-1';--已结数
  --execute immediate ' merge into B_TEMPTJFX  A
    --using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND  KPLB=22 GROUP BY B_AJZTXX.CBR)B
    --ON(A.DM=B.CBR)
    --when matched then update set A.YJ=B.SL WHERE KPLB=22';--七类已结数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND  KPLB=4 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.YJ=B.SL WHERE KPLB=4';--减刑假释已结数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1)
    when matched then update set A.YJ=B.SL WHERE KPLB=-2';--全院已结数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||'  and KPLB<>4 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.WJ=B.SL WHERE KPLB=-1';--未结数
  --execute immediate ' merge into B_TEMPTJFX  A
   -- using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND  KPLB=22 GROUP BY B_AJZTXX.CBR)B
   -- ON(A.DM=B.CBR)
   -- when matched then update set A.WJ=B.SL WHERE KPLB=22';--七类未结数

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND  KPLB=4 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.WJ=B.SL WHERE KPLB=4';--减刑假释未结数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||' )B
    ON(1=1)
    when matched then update set A.WJ=B.SL WHERE KPLB=-2';--全院未结数

   execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||' and CBR IS NULL)B
    ON(1=1)
    when matched then update set A.WJ=B.SL WHERE KPLB=-3';--未分案案件

  execute immediate 'UPDATE B_TEMPTJFX SET SLS=NVL(YJ,0)+NVL(WJ,0)'; --受理数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and '||v_tjs||' GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.TJS=B.SL WHERE KPLB=-1';--调解数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and '||v_tjs||')B
    ON(1=1)
    when matched then update set A.TJS=B.SL WHERE KPLB=-2';--全院调解数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and '||v_css||' GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.CSS=B.SL WHERE KPLB=-1';--撤诉数

  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' and '||v_css||' )B
    ON(1=1)
    when matched then update set A.CSS=B.SL WHERE KPLB=-2';--全院撤诉数

  execute immediate 'UPDATE B_TEMPTJFX SET TCS=NVL(TJS,0)+NVL(CSS,0)'; --调撤数

  dbms_output.put_line('时间1：'||to_char(sysdate,'yyyy-MM-dd HH24:mi:ss') );
 /*
 execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE exists (SELECT AJBS FROM B_SPZZCY WHERE JS<>8 AND AJBS=B_AJZTXX.AJBS AND YCY=B_AJZTXX.CBR ) AND '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND KPLB<>22 GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR)
    when matched then update set A.HYS=B.SL WHERE KPLB=-1';--合议数*/

    execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||'  AND KPLB<>4) AND JS<>8 GROUP BY B_SPZZCY.YCY)B
     ON(A.DM=B.YCY)
    when matched then update set A.HYS=B.SL WHERE KPLB=-1';--合议数
    /*
     execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE exists (SELECT AJBS FROM B_SPZZCY WHERE JS<>8 AND AJBS=B_SPZZCY.AJBS AND YCY=B_AJZTXX.CBR ) AND '||v_yjtj||' AND '||v_scfy||' AND  KPLB=22 GROUP BY B_AJZTXX.CBR)B
     ON(A.DM=B.CBR)
     when matched then update set A.HYS=B.SL WHERE KPLB=22';--七类合议数
     */

  --  execute immediate ' merge into B_TEMPTJFX  A
    -- using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND KPLB=22) AND JS<>8 GROUP BY B_SPZZCY.YCY)B
   --  ON(A.DM=B.YCY)
   -- when matched then update set A.HYS=B.SL WHERE KPLB=22';--七类合议数

    execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND KPLB=4) AND JS<>8 GROUP BY B_SPZZCY.YCY)B
     ON(A.DM=B.YCY)
    when matched then update set A.HYS=B.SL WHERE KPLB=4';--减刑假释合议数

    execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' AND AJBS IN(SELECT AJBS FROM B_SPZZCY WHERE JS<>8))B
    ON(1=1)
    when matched then update set A.HYS=B.SL WHERE KPLB=-2';--全院合议数
    /*execute immediate ' merge into B_TEMPTJFX  A
     using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS<>8)B
    ON(1=1)
    when matched then update set A.HYS=B.SL WHERE KPLB=-2';*/--全院合议数错误
         /*
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE exists (SELECT AJBS FROM B_SPZZCY WHERE JS<>8 AND AJBS=B_SPZZCY.AJBS AND YCY=B_AJZTXX.CBR ) AND '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1)
    when matched then update set A.HYS=B.SL WHERE KPLB=-2';--全院合议数
  --execute immediate 'UPDATE B_TEMPTJFX SET XS=(SELECT SUM(NVL(HYS,0)) FROM B_TEMPTJFX WHERE KPLB!=-2) where KPLB=-2'; --全院合议数
*/
  dbms_output.put_line('时间2：'||to_char(sysdate,'yyyy-MM-dd HH24:mi:ss') );

  open rt for SELECT * FROM  B_TEMPTJFX where SLS>0 OR HYS>0 order by DM,KPLB;
END P_FGSJAQKTJ;
/

