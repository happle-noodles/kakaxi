create procedure p_tjfx_pcajdbtj(fytj varchar2,qsrq varchar2,jsrq varchar2,qnksrq varchar2,qnjsrq varchar2 ,rt out pkg_row.myRow) as
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(400);
v_kplb varchar2(100);
v_qnxstj varchar2(200);
v_qnyjtj varchar2(200);
v_qnjctj varchar2(200);

begin
   v_scfy:='SCFY BETWEEN 4166 AND 4208 AND KPLB=17 AND '|| fytj;
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   v_qnxstj:=v_xstj;
   v_qnyjtj:=v_yjtj;
   v_qnjctj:=v_jctj;
   
   v_qnxstj :=replace(v_qnxstj,'＆QsRq＆',qnksrq);
   v_qnxstj :=replace(v_qnxstj,'＆JsRq＆',qnjsrq);
   v_qnyjtj :=replace(v_qnyjtj,'＆QsRq＆',qnksrq);
   v_qnyjtj :=replace(v_qnyjtj,'＆JsRq＆',qnjsrq);
   v_qnjctj :=replace(v_qnjctj,'＆QsRq＆',qnksrq);
   
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   
   
   INSERT INTO B_TEMPAYTJ (AYDM,AYMC) SELECT -1,'赔偿案件' from dual;
   
    execute immediate (' update B_TEMPAYTJ set jnjc=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_jctj ||')');
    execute immediate (' update B_TEMPAYTJ set qnjc=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_qnjctj ||')');
    
    execute immediate (' update B_TEMPAYTJ set jnxs=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_xstj ||')');
    execute immediate (' update B_TEMPAYTJ set qnxs=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_qnxstj ||')');
    
    execute immediate (' update B_TEMPAYTJ set jnyj=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_yjtj ||')');
    execute immediate (' update B_TEMPAYTJ set qnyj=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_qnyjtj ||')');
    
    execute immediate (' update B_TEMPAYTJ set jntjs=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_yjtj ||' and laay in(select aydm from b_ay where aydm=2101 or sjdm=2101) and ajbs in(select ajbs from b_pcywjg where nvl(lx,255)<3))');
    execute immediate (' update B_TEMPAYTJ set jnwcs=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_yjtj ||' and laay in(select aydm from b_ay where aydm=2101 or sjdm=2101))');
    
    execute immediate (' update B_TEMPAYTJ set jnpjs=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_yjtj ||' and laay in(select aydm from b_ay where  aydm=2101 or aydm=2101 or sjdm=2101) and ajbs in(select ajbs from b_pcywjg where nvl(lx,255)<3))');
    execute immediate (' update B_TEMPAYTJ set jncss=(select count(*) from  b_ajztxx WHERE '||v_scfy||' AND '|| v_yjtj ||' and laay in(select aydm from b_ay where  aydm=2100 or aydm=2113 or sjdm=2113))');
    
    update  B_TEMPAYTJ set jnsls=jnxs+jnjc;  
    update  B_TEMPAYTJ set qnsls=qnxs+qnjc;
    
    update  B_TEMPAYTJ set jnwcs=jnwcs-jntjs;  
    update  B_TEMPAYTJ set jncss=jncss-jnpjs; 
    
     update  B_TEMPAYTJ set jnwj=jnsls-jnyj;  
    update  B_TEMPAYTJ set qnwj=qnsls-qnyj; 
    
    update  B_TEMPAYTJ set jnjal=round(100*jnyj/jnsls,2);  
    update  B_TEMPAYTJ set qnjal=round(100*qnyj/qnsls,2);  
    
    open rt for select jnjc,jnxs,jnsls,qnsls,jnyj,jnwj,jnjal,qnjal,jnwcs,jncss,jntjs,jnpjs from B_TEMPAYTJ;
   -- dbms_output.put_line(v_sql);
 
end p_tjfx_pcajdbtj;
/

