create FUNCTION                   F_getJsxZdTs(nAjBs number) return number is
  nJsxZtTs number;
  /*距审限终点天数 杨元胜*/
begin
  select (a.fdsxts+nvl(a.kcts,0)+nvl(a.ycts,0)+nvl(a.syts,0))-(to_date(to_char(sysdate,'yyyy-MM-dd'),'yyyy-mm-dd')-nvl(a.sxqsrq,a.larq)) INTO nJsxZtTs from b_ajztxx a WHERE AJBS=nAjBs and a.larq is not null and nvl(a.fdsxts,0)>0 ;
  RETURN nJsxZtTs;
end;

/

