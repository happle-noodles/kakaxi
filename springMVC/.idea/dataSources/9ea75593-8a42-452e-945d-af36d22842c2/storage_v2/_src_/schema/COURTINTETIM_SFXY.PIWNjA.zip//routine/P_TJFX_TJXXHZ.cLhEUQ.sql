create PROCEDURE P_TJFX_TJXXHZ(qsrq varchar2,jsrq varchar2,sjqj varchar2)
as
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_sjqj varchar2(1000);
v_yj varchar2(200);
kssj timestamp;
jssj timestamp;
v_qsrq varchar2(200);
v_jsrq varchar(200);
v_sjqjcs varchar(200);
months interval year to month;

begin
   if sjqj='-1' then
     v_jsrq :=to_char(sysdate,'yyyy-mm-dd');
     dbms_output.put_line(v_jsrq);
     v_qsrq :=to_char(add_months(sysdate, -12),'yyyy-mm-dd');
     v_qsrq :=substr(v_qsrq,1,4)||'-11-26';
     case to_char(sysdate,'mm')
       when '01' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-01-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-2';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
       when '02' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-02-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-3';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
       when '03' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-03-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-4';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '04' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-04-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-5';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '05' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-05-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-6';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '06' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-06-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-7';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '07' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-07-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-8';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '08' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-08-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-9';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '09' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-09-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-10';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '10' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-10-25','yyyy-MM-dd') then
             v_sjqjcs :='2#'||to_char(sysdate,'yyyy')||'-11';
          else
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          end if;
        when '11' then
          if sysdate<=to_date(substr(v_jsrq,1,4)||'-11-25','yyyy-MM-dd') then
             v_sjqjcs :='1#'||to_char(sysdate,'yyyy')||'-0';
          else
             v_sjqjcs :='1#'||to_char(add_months(sysdate, 12),'yyyy')||'-0';
          end if;
        when '12' then
          if sysdate=to_date(substr(v_jsrq,1,4)||'-11-25','yyyy-MM-dd') then
              v_sjqjcs :='2#'||to_char(add_months(sysdate, 12),'yyyy')||'-1';
          else
              v_sjqjcs :='1#'||to_char(add_months(sysdate, 12),'yyyy')||'-0';
          end if;
     end case;
   else
     v_qsrq :=qsrq;
     v_jsrq :=jsrq;
     v_sjqjcs :=sjqj;
   end if;


   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   --select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   v_xstj :=replace(v_xstj,'＆QsRq＆',v_qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',v_jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',v_qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',v_jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',v_jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',v_qsrq);
   v_sjqj :=v_sjqjcs||'#'||v_qsrq||'#'||v_jsrq;
   dbms_output.put_line(v_sjqj);
   execute immediate 'delete from b_tjhz WHERE SJQJ LIKE ''%'||v_sjqjcs||'#%'' ';

   INSERT INTO b_tjhz(KPLB,SJQJ,CJFY,FYJB,SJDM) SELECT A.KPLB,(''||v_sjqj||'') ,B.DM,B.FYJB,(CASE WHEN B.SJDM=4166 THEN B.DM ELSE B.SJDM END) AS SJDM  FROM B_KPLB a,b_fy b where b.dm BETWEEN 4166 AND 4208 and ((a.kplb<30 or kplb>39) and a.kplb<>19) ORDER BY B.DM,A.KPLB;
   dbms_output.put_line('时间1：'||to_char(SYSDATE,'yyyy-mm-dd  HH24:MI:SS'));
   execute immediate ' merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB)B
   ON(A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   when matched then update set A.YJS=B.SL ';--已结数

   execute immediate'merge into B_TJHZ  A
   USING(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_xstj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   ON(A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   when matched then update set A.XSS=B.SL';--新收数

   execute immediate'merge into B_TJHZ  A
   USING(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   ON (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   when matched then update set A.WJS=B.SL';--未结数'

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_jctj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   ON (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.JCS=B.SL';--旧存数'

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_xstj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.XSYJS=B.SL';--新收已结数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_xstj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.XSWJS=B.SL';--新收未结数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_jctj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.JCYJS=B.SL';--旧存已结数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_jctj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.JCWJS=B.SL';--旧存未结数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND nvl(YCTS,-1)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJYCS=B.SL';--已结延长数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND nvl(KCTS,-1)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJKCS=B.SL';--已结扣除数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' AND nvl(YCTS,-1)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJYCS=B.SL';--未结延长数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' AND nvl(KCTS,-1)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJKCS=B.SL';--未结扣除数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND nvl(CSXTS,0)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJCSXS=B.SL';--已结超审限数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' AND nvl(CSXTS,0)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJCSXS=B.SL';--未结超审限数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND nvl(SYTS,0)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJSYS=B.SL';--已结顺延数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' AND nvl(SYTS,0)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJSYS=B.SL';--未结顺延数

   execute immediate'merge into B_TJHZ  A
   using(SELECT SUM((JARQ-NVL(SXQSRQ,LARQ))-(CASE WHEN NVL(KCTS,0)>3600 THEN 0 ELSE NVL(KCTS,0) END))AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.PJSLTS=B.SL';--平均审理天数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((nvl(YCTS,0)<=0 and nvl(CSXTS,0)<=0) or kplb=12 or kplb=22) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.FDQXNJAS=B.SL'; --法定审限结案数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB in(2,3,8,9,14,15) and JAFS=2 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.GPS=B.SL';--改判数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB in(2,3,8,9,14,15) and JAFS=3 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.FHCSS=B.SL';--发回重审数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,B_AJZTXX.SCFY FROM B_AJZTXX,B_AJFZXX WHERE B_AJFZXX.AJBS=B_AJZTXX.AJBS  AND ('||v_yjtj||' or '||v_wjtj ||') AND FZKPLB=16 AND AJLB=1 and zxyj=2 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.MSSQZXS=B.SL';--民事案件申请执行mssqzxs

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE ('||v_yjtj||' or '||v_wjtj ||') AND FZKPLB=16 AND AJLB=1 and yscdlx=3 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.TJSQZXS=B.SL';--调解案件申请执行tjsqzxs

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((FZKPLB in(1,7,13) AND JAFS=7) OR (FZKPLB IN(2,3) AND JAFS=8) OR (FZKPLB in(8,9,14,15) and JAFS=9) OR(FZKPLB in(12) AND JAFS=6)) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.TJS=B.SL';--调解数(申诉结案方式未找到调解相关结案方式）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((B_AJZTXX.FZKPLB=1 AND JAFS in(4,5,9))or (B_AJZTXX.FZKPLB=2 AND JAFS in(5,6,112,107,108,109,110)) or (B_AJZTXX.FZKPLB=3 AND JAFS in(5,6,107,108,109,110,113,116,117)) OR (B_AJZTXX.FZKPLB in(7,13) AND JAFS in(4,5)) OR (B_AJZTXX.FZKPLB =8 AND JAFS in(6,7,110)) OR (B_AJZTXX.FZKPLB =9 AND JAFS in(6,7,106)) OR (B_AJZTXX.FZKPLB in (14,15) AND JAFS in(6,7)) or(B_AJZTXX.FZKPLB in(21) AND JAFS in(5,13,14,33,34,48,49,53,54,63,64,74,75,83,84,91,92,105,106,123,124,184,185)) or (B_AJZTXX.FZKPLB=41 and jafs in(16,17))  or (B_AJZTXX.FZKPLB=42 and jafs in(9,10)) or (B_AJZTXX.FZKPLB in(23,24,25) and JAFS in (7,8,21,22,45,54,76,77,84,105,106,114))) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.CSS=B.SL';--撤诉数

   dbms_output.put_line('时间2：'||to_char(SYSDATE,'yyyy-mm-dd  HH24:MI:SS'));

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND (FZKPLB in(1,7,13) and JAFS=1) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.PJS=B.SL';--判决数（民事特殊未找到判卷录入项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND (FZKPLB in(2,3,8,9,14,15) and JAFS=1) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WCS=B.SL';--维持数(行政一审和赔偿案件未找到维持的录入项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((FZKPLB in(1,7,21,13) and JAFS in(3)) OR (FZKPLB in(8,9,14,15,17) AND JAFS=5) OR (FZKPLB in(23,24,25) AND JAFS=6)) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.BHS=B.SL';--驳回数(执行申诉和赔偿申诉未找到相关录入项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB=16 AND JAFS=-1 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZDLXS=B.SL';--自动履行数（执行案件未找到结案方式为自动履行的选项

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB=16 AND JAFS=28 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZXHJS=B.SL';--执行和解数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB=16 AND JAFS=5 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.BYZXS=B.SL';--(执行)不予执行数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB=16 AND JAFS=-1 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.QZZXS=B.SL';--(执行)强制执行数(未找到强制执行的结案方式）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB=16 AND JAFS in(2,3) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZJS=B.SL';--(执行)终结数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND FZKPLB=16 AND JAFS in(-1) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.CDS=B.SL';--裁定数（无法确定哪些结案方式为裁定）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' and '||v_xstj||' AND (FZKPLB in(2,3,8,9,14,15) AND JAFS=3) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.XSFHCSS=B.SL';--新收发回重审数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' and '||v_xstj||' AND (FZKPLB in(23,24,25) AND JAFS=2) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.XSJDZSS=B.SL';--新收本院决定再审数(执行申诉和赔偿申诉未找到相关对应项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' and '||v_xstj||' AND (FZKPLB in(23,24,25) AND JAFS=4) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.XSZLZSS=B.SL';--新收本院指令再审数(执行申诉和赔偿申诉未找到相关对应项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' and '||v_jctj||' AND (FZKPLB in(2,3,5,8,9,14,15) AND JAFS=3) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.JCFHCSS=B.SL';--旧存发回重审数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' and '||v_jctj||' AND (FZKPLB in(23,24,25) AND JAFS=2) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.JCJDZSS=B.SL';--旧存本院决定再审数(执行申诉和赔偿申诉未找到相关对应项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' and '||v_jctj||' AND (FZKPLB in(23,24,25) AND JAFS=4) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.JCZLZSS=B.SL';--旧存本院指令再审数(执行申诉和赔偿申诉未找到相关对应项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  AND (FZKPLB in(2,3,5,8,9,14,15) AND JAFS=3) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJFHCSS=B.SL';--已结发回重审数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  AND (FZKPLB in(23,24,25) AND JAFS=2) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJJDZSS=B.SL';--已结本院决定再审数(执行申诉和赔偿申诉未找到相关对应项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  AND (FZKPLB in(23,24,25) AND JAFS=4) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJZLZSS=B.SL';--已结本院指令再审数(执行申诉和赔偿申诉未找到相关对应项）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||'  AND (FZKPLB in(2,3,5,8,9,14,15) AND JAFS=3) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJFHCSS=B.SL';--未结发回重审数(未结案件，没有结案方式)

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||'  AND (FZKPLB in(23,24,25) AND JAFS=2) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJJDZSS=B.SL';--未结本院决定再审数(执行申诉和赔偿申诉未找到相关对应项，未结案件，没有结案方式）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||'  AND (FZKPLB in(23,24,25) AND JAFS=4) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.WJZLZSS=B.SL';--未结本院指令再审数(执行申诉和赔偿申诉未找到相关对应项，未结案件，没有结案方式）

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  AND (FZKPLB in(23,24,25) AND JAFS in(2,3,4,5,25,31,33,34,41,43,44,52,53,61,63,64,71,73,74,82,83,91,93,94,102,103,112,113,32,42,51,62,72,81,92,101,111)) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZSS=B.SL';--再审数

   dbms_output.put_line('时间3：'||to_char(SYSDATE,'yyyy-mm-dd  HH24:MI:SS'));

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  AND (nvl(YCTS,-1)>0 OR nvl(KCTS,-1)>0) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.YJSXBGS=B.SL';--已结审限变更数

   execute immediate 'merge into B_TJHZ A
   using (SELECT COUNT(*) AS SL,M.FZKPLB,M.JBFY FROM (SELECT (FZKPLB-1) as FZKPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS JBFY FROM B_AJZTXX WHERE '||v_xstj||' AND KPLB IN(2,8,14)) M GROUP BY M.JBFY,M.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SSXSS=B.SL';--上诉新收数

  execute immediate 'merge into B_TJHZ A
   using (SELECT COUNT(*) AS SL,M.FZKPLB,M.JBFY FROM (SELECT FZKPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS JBFY FROM B_AJZTXX WHERE '||v_xstj||' AND FZKPLB IN(23,24,25)) M GROUP BY M.JBFY,M.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZSSCS=B.SL';--再审审查数

   execute immediate 'merge into B_TJHZ A
   using (SELECT COUNT(*) AS SL,M.FZKPLB,M.JBFY FROM (SELECT FZKPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS JBFY FROM B_AJZTXX WHERE '||v_xstj||' AND FZKPLB=16 AND AJLB=1 and AH NOT LIKE ''%执保%''  and AH NOT LIKE ''%执异%'' and AH NOT LIKE ''%执协%'' and AH NOT LIKE ''%执请%'' and AH NOT LIKE ''%执监%'' and AH NOT LIKE ''%执复%'' ) M GROUP BY M.JBFY,M.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZXAJS=B.SL';--申请执行案件

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE ('||v_yjtj||' OR '||v_wjtj||') AND SCFY=4166 AND FZKPLB=24  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSS=B.SL WHERE KPLB=24';--申请再审数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_xstj||' AND SCFY=4166 AND FZKPLB=24  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSXSS=B.SL WHERE KPLB=24';--申请再审新收数
  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_xstj||' AND SCFY=4166 AND FZKPLB=8  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSESXSS=B.SL WHERE KPLB=8';--申请再审二审新收数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_yjtj||' AND SCFY=4166 AND FZKPLB=24  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSYJS=B.SL WHERE KPLB=24';--申请再审结案数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_yjtj||' AND SCFY=4166 AND FZKPLB=24 AND JAFS in(6,46,75,104)  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSBHS=B.SL WHERE KPLB=24';--申请再审驳回数


  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_yjtj||' AND SCFY=4166 AND FZKPLB=24 AND JAFS in(7,8,21,22,45,54,76,77,84,105,106,114)  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSCSS=B.SL WHERE KPLB=24';--申请再审撤诉数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_yjtj||' AND SCFY=4166 AND FZKPLB=24 AND JAFS=3  GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.TSS=B.SL WHERE KPLB=24';--申请再审提审数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_yjtj||' AND SCFY=4166 AND FZKPLB=24 AND JAFS=4 GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZLZSS=B.SL WHERE KPLB=24';--申请再审指令再审数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,C.JBFY FROM B_AJZTXX INNER JOIN (SELECT JBFY,AJBS FROM B_YSQK WHERE EXISTS(SELECT MAX(SFBZ) FROM B_YSQK))C ON B_AJZTXX.AJBS=C.AJBS WHERE '||v_yjtj||' AND SCFY=4166 AND FZKPLB=24 AND JAFS in(2,5) GROUP BY C.JBFY) B
   on ( A.CJFY=B.JBFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.SQZSZSS=B.SL WHERE KPLB=24';--申请再审再审数

  execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(*) AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE KPLB IN(3,9,15) AND '||v_yjtj||' and  AH IN(SELECT AH FROM B_YSQK WHERE KPLB=18 AND B_AJZTXX.SCFY=B_YSQK.SCFY)  GROUP BY SCFY,FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ZSSSS=B.SL ';--再审申诉数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(*) AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE KPLB IN(2,8,14) AND '||v_yjtj||' and  AH IN(SELECT AH FROM B_YSQK WHERE KPLB=18 AND B_AJZTXX.SCFY=B_YSQK.SCFY)  GROUP BY SCFY,FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
   WHEN matched then update set A.ESSSS=B.SL ';--二审申诉数

   dbms_output.put_line('时间4：'||to_char(SYSDATE,'yyyy-mm-dd  HH24:MI:SS'));


 update B_TJHZ set SQZSQTS=NVL(SQZSYJS,0)-NVL(SQZSBHS,0)-NVL(SQZSCSS,0)-NVL(SQZSZSS,0)-NVL(TSS,0)-NVL(ZLZSS,0) WHERE SJQJ=''||v_sjqj||'' AND KPLB=24;

   kssj :=to_timestamp(v_qsrq,'yyyy-mm-dd');
   while(kssj<to_timestamp(v_jsrq,'yyyy-mm-dd'))
    loop
      jssj :=add_months(kssj,1);
      jssj :=jssj+interval '-1 00:00:00' day to second;

      --jssj :=to_char(add_months(to_date(to_char(jssj,'yyyy-MM-dd'),'yyyy-MM-dd'),-1),'yyyy-MM-dd');
      --v_yj :='(nvl(SPYJ,2)<>2 and JARQ>=to_date('||jssj||'))';
      --v_yj :='(JARQ>=to_date(to_char(kssj),'yyyy-mm-dd') and JARQ<=to_date(to_char(jssj),'yyyy-mm-dd'))';
       select gsnr into v_yj  from b_tjfxgs where gsmc='已结A';
        v_yj :=replace(v_yj,'＆QsRq＆',to_char(kssj,'yyyy-MM-dd'));
        v_yj :=replace(v_yj,'＆JsRq＆',to_char(jssj,'yyyy-MM-dd'));

      --months :=extract(month from to_date(jssj,'yyyy-MM-dd'));

      if to_char(jssj,'mm')='01'
        then
          execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.FEB=B.SL';
      elsif to_char(jssj,'mm')='02'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.MAR=B.SL';
      elsif to_char(jssj,'mm')='03'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.APR=B.SL';
      elsif to_char(jssj,'mm')='04'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.MAY=B.SL';
      elsif to_char(jssj,'mm')='05'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.JUN=B.SL';
      elsif to_char(jssj,'mm')='06'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.JUL=B.SL';
      elsif to_char(jssj,'mm')='07'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.AUG=B.SL';
      elsif to_char(jssj,'mm')='08'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.SEP=B.SL';
      elsif to_char(jssj,'mm')='09'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.OCT=B.SL';
      elsif to_char(jssj,'mm')='10'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.NOV=B.SL';
      elsif to_char(jssj,'mm')='11'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.DEC=B.SL';
      elsif to_char(jssj,'mm')='12'
         then
           execute immediate'merge into B_TJHZ  A
          using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
          on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY AND A.SJQJ='''||v_sjqj||''')
          WHEN matched then update set A.JAN=B.SL';
          --EXEC('UPDATE B_TJHZ SET FEB=(SELECT COUNT(*) FROM B_AJXX WHERE '+@STRYJS+' AND B_AJXX.CJFY=B_TJHZ.CJFY AND (CASE B_AJXX.AJLB WHEN 1 THEN 181 WHEN 2 THEN 182 WHEN 6 THEN 183 WHEN 7 THEN 184 WHEN 8 THEN 185 ELSE B_AJXX.KPLB END)=B_TJHZ.KPLB GROUP BY B_AJXX.CJFY,B_AJXX.KPLB,B_AJXX.AJLB) WHERE B_TJHZ.SJQJ='''+@strQJZ+'''')
        end if;
        kssj :=add_months(kssj,1);
    end loop;
       dbms_output.put_line('时间4：'||to_char(SYSDATE,'yyyy-mm-dd  HH24:MI:SS'));
end;
/

