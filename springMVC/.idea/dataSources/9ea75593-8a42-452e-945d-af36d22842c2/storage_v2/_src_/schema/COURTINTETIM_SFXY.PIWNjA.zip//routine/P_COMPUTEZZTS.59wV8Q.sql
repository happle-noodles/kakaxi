create procedure P_ComputeZzTs is
/*计算无结束日期的中止天数,实际审理天数 杨元胜*/
begin
  update b_ajztxx a set kcts=(select sum(nvl(jsrq,to_date(to_char(sysdate,'yyyy-MM-dd'),'yyyy-mm-dd'))-qsrq) as ts from b_kcsxjl b where a.ajbs=b.ajbs and nvl(a.sxqsrq,a.larq)<=qsrq) where jarq is null and ajbs in(select ajbs from b_kcsxjl where qsrq is not null and jsrq is null);
  update b_ajztxx set sjslts=(jarq-larq)-nvl(kcts,0) where  jarq is not null and sjslts is null;
  delete b_tjhz where sjqj like '-1%';
  delete b_aytjhz where sjqj like '-1%';
end P_ComputeZzTs;

/

