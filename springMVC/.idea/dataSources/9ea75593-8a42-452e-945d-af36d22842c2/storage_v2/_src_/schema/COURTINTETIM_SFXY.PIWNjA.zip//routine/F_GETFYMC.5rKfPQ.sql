create FUNCTION                   F_GETFYMC(nFyDm number) return varchar2 is
  strMC nvarchar2(200);
  /*获取法院名称 杨元胜*/
begin
  SELECT FYMC INTO strMC FROM B_FY  WHERE DM = nFyDm;
  RETURN strMC;
end;

/

