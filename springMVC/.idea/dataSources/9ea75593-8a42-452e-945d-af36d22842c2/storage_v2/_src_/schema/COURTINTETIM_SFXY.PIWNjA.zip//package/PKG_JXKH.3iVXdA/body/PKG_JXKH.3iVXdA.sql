create package body PKG_JXKH is

 procedure init_jxkhjczbex(nscfy number, rt out varchar) is
 begin
  rt:='ok';
 end init_jxkhjczbex;

/*计算绩效考核基础数据*/
 procedure init_jxkhjczb(nscfy number, qsrq varchar2,jsrq varchar2 ,sjqj varchar2, rt out myRow) as
    v_yjtj varchar2(200);
    v_wjtj varchar2(200);
    v_xstj varchar2(200);
    v_snyjtj varchar2(200);
    v_snwjtj varchar2(200);
    v_snxstj varchar2(200);
    vsnksrq varchar2(50);
    vsnjsrq varchar2(50);
    v_scfy varchar2(200);
    v_kplb varchar2(100);
 begin
    select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
    select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
    select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
    select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
    select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
    vsnksrq :=to_char( ADD_MONTHS( to_date(qsrq,'yyyy-mm-dd'),-36),'yyyy-mm-dd');
    vsnjsrq :=to_char( ADD_MONTHS( to_date(jsrq,'yyyy-mm-dd'),-12),'yyyy-mm-dd');
    v_snyjtj:=v_yjtj;
    v_snwjtj:=v_wjtj;
    v_snxstj:=v_xstj;
    v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
    v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
    v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
    v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
    v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
    v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);
    
    v_snyjtj :=replace(v_snyjtj,'＆QsRq＆',vsnksrq);
    v_snyjtj :=replace(v_snyjtj,'＆JsRq＆',vsnjsrq);
    v_snwjtj :=replace(v_snwjtj,'＆JsRq＆',vsnjsrq);
    v_snxstj :=replace(v_snxstj,'＆QsRq＆',vsnksrq);
    v_snxstj :=replace(v_snxstj,'＆JsRq＆',vsnjsrq);
    dbms_output.put_line(v_snyjtj);
    dbms_output.put_line(v_snwjtj);
      
    execute immediate 'INSERT INTO B_JXKH_TEMP(SCFY,YHDM,YHXM,TSDM,SJQJ,khlx) SELECT SCFY,YHDM,YHXM,TSDM,SJQJ,yhlx FROM B_JXKH_RYZBWHXX WHERE '|| v_scfy ||' AND SJQJ='''|| sjqj ||'''';  
    
   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_scfy ||' AND '||v_kplb||' AND  '||v_yjtj||'  GROUP BY B_AJZTXX.CBR)B
   ON(A.YHDM=B.CBR  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.YJ=B.SL WHERE  khlx=''yefg'' and '|| v_scfy;--已结数

    execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY M  right JOIN  B_AJZTXX N  ON  M.AJBS=N.AJBS AND M.JS<>8 AND m.ycy!=n.cbr  AND n.SCFY='||nscfy ||'  AND '||replace(v_kplb,'KPLB','n.KPLB')|| ' AND  '||v_yjtj||'  GROUP BY M.YCY)B
   ON(A.YHDM=B.YCY  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.HYAJS=B.SL WHERE  khlx=''yefg'' and '|| v_scfy;--合议案件数


 

   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_scfy ||' AND '||v_kplb||' AND  '||v_wjtj||'  GROUP BY B_AJZTXX.CBR)B
   ON(A.YHDM=B.CBR  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.wj=B.SL WHERE  khlx=''yefg'' and '|| v_scfy;--未结数
     
   
   
    execute immediate  ' merge into B_JXKH_TEMP  A
    using( select count(*)as sl,cbr from b_ajztxx where kplb<>18 and scfy='||nscfy||' and ah in(
    select (select ah from b_ysqk where rownum=1 and ajbs=a.ajbs and ah not like ''%申%'') as ysah from b_ajztxx a   where (a.scfy ='||nscfy||' or a.scfy=(select sjdm from B_fy where dm='||nscfy||' )) and '||v_yjtj||'  
    AND ((a.KPLB IN(2,3,8,9,14,15) AND a.JAFS =2 and nvl(a.gpyy,0)<>5) OR (a.KPLB IN(2,3) AND a.JAFS =3 and nvl(a.fhcsyy,0)<>7) or(a.KPLB IN(8,9,14,15) AND a.JAFS =3 and nvl(a.fhcsyy,8)<>5))) 
    GROUP by cbr ) b ON(A.YHDM=B.CBR  AND A.SJQJ='''||sjqj||''')
    when matched then update set A.cwajs=B.SL WHERE    khlx=''yefg'' and  '|| v_scfy;--错误案件数
     
     execute immediate  ' merge into B_JXKH_TEMP  A
    using( select m.yj*100/(m.yj+n.wj) as sl,m.cbspt 
    from (SELECT COUNT(1)AS yj,cbspt FROM B_AJZTXX WHERE  '||v_scfy ||' AND '||v_kplb||' AND  '||v_snyjtj||'  GROUP BY B_AJZTXX.cbspt)m,
    (SELECT COUNT(1)AS wj,cbspt FROM B_AJZTXX WHERE  '||v_scfy ||' AND '||v_kplb||' AND  '||v_snwjtj||'  GROUP BY B_AJZTXX.cbspt)n
    where m.cbspt=n.cbspt and m.yj+n.wj>0) b
    ON(A.tsdm=B.cbspt  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.snpjjal=B.SL WHERE  khlx=''yefg'' and '|| v_scfy;--未结数
     
   execute immediate 'update B_JXKH_TEMP  set sls=nvl(yj,0)+nvl(wj,0) where  khlx=''yefg'' and '|| v_scfy ||' and SJQJ='''||sjqj||''''; --受理数
    
   execute immediate 'update B_JXKH_TEMP  set jal=nvl(yj,0)*100/nvl(sls,0) where nvl(sls,0) >0 and  khlx=''yefg'' and '|| v_scfy ||' and SJQJ='''||sjqj||''''; --结案率
   
   execute immediate 'update B_JXKH_TEMP  set qypjbas=(select avg(nvl(yj,0)) from B_JXKH_TEMP where '|| v_scfy ||' and SJQJ='''||sjqj||''') where   KHLX=''yefg'' AND '|| v_scfy ||' and SJQJ='''||sjqj||''''; --全院平均结案数
   
   execute immediate( 'update B_JXKH_TEMP a  set bmpjbas=(select avg(nvl(yj,0)) from B_JXKH_TEMP where tsdm=a.tsdm  and  KHLX=''yefg'' AND '|| v_scfy ||' and SJQJ='''||sjqj||''' group by tsdm) where   KHLX=''yefg'' and '|| v_scfy ||' and SJQJ='''||sjqj||''''); --部门平均结案数 
  
   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX  WHERE  '||v_scfy ||' AND '||v_kplb||' AND  '||v_yjtj||' AND B_AJZTXX.AJBS IN (select AJBS from b_Ftsyjl where ftyt=1 and dtxp=1 and '||v_scfy ||') GROUP BY B_AJZTXX.CBR)B
   ON(A.YHDM=B.CBR  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.DTXPS=B.SL WHERE  khlx=''yefg'' and '|| v_scfy;--当庭宣判数
     
   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX  WHERE  '||v_scfy ||' AND ((B_AJZTXX.kplb=7 and B_AJZTXX.jafs=7) or (B_AJZTXX.kplb=8 and B_AJZTXX.jafs=9) or (B_AJZTXX.kplb=9 and B_AJZTXX.jafs=9)) AND B_AJZTXX.AH IN (select (select ah from b_ysqk where rownum=1 and ajbs=d.ajbs) from B_ajztxx d where '||v_xstj ||' and d.ajlb=1 and d.kplb = 16 and '|| v_scfy ||') GROUP BY B_AJZTXX.CBR)B
   ON(A.YHDM=B.CBR  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.TJZXS=B.SL WHERE  khlx=''yefg'' and '|| v_scfy;--调解执行数
     
   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,FGZL FROM B_AJZTXX WHERE  '||v_scfy ||' AND '||v_kplb||' AND  '||v_yjtj||'  GROUP BY B_AJZTXX.FGZL)B
   ON(A.YHDM=B.FGZL  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.FZJAS=B.SL WHERE  khlx=''fgzl'' and '|| v_scfy;--辅助结案数
     
   execute immediate( 'update B_JXKH_TEMP a  set pjfzjas=(select avg(nvl(fzjas,0)) from B_JXKH_TEMP where tsdm=a.tsdm  and  KHLX=''fgzl'' AND '|| v_scfy ||' and SJQJ='''||sjqj||''' group by tsdm) where   KHLX=''fgzl'' and '|| v_scfy ||' and SJQJ='''||sjqj||''''); --法官助理平均结案数 
   
   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,c.sjy FROM  (select n.ycy as sjy,n.kplb from B_AJZTXX m left join B_spzzcy n on m.ajbs=n.ajbs and n.js=8  WHERE  m.scfy='||nscfy ||' AND  '||v_yjtj||') c where '||v_kplb||'   GROUP BY c.sjy)B
   ON(A.YHDM=B.sjy  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.SJYFZJAS=B.SL WHERE  khlx=''sjy'' and '|| v_scfy;--书记员辅助结案数
     
   execute immediate( 'update B_JXKH_TEMP a  set sjyfzpjjas=(select avg(nvl(sjyfzjas,0)) from B_JXKH_TEMP where tsdm=a.tsdm  and  KHLX=''sjy'' AND '|| v_scfy ||' and SJQJ='''||sjqj||''' group by tsdm) where   KHLX=''sjy'' and '|| v_scfy ||' and SJQJ='''||sjqj||''''); --部门书记员辅助平均结案数 
   
   execute immediate ' merge into B_JXKH_TEMP  A
   using(SELECT COUNT(1)AS SL,c.sjy FROM  (select n.ycy as sjy,n.kplb,m.ajbs from B_AJZTXX m left join B_spzzcy n on m.ajbs=n.ajbs and n.js=8 where exists(select ajbs from B_ftsyjl where ftyt=1 and ajbs=m.ajbs) and m.scfy='||nscfy ||' AND  '||v_yjtj||') c where '||v_kplb||'   GROUP BY c.sjy)B
   ON(A.YHDM=B.sjy  AND A.SJQJ='''||sjqj||''')
   when matched then update set A.TSJLAJS=B.SL WHERE  khlx=''sjy'' and '|| v_scfy;--庭审记录结案数
   
   execute immediate( 'update B_JXKH_TEMP a  set BMPJTSJLAJS=(select avg(nvl(TSJLAJS,0)) from B_JXKH_TEMP where tsdm=a.tsdm  and  KHLX=''sjy'' AND '|| v_scfy ||' and SJQJ='''||sjqj||''' group by tsdm) where   KHLX=''sjy'' and '|| v_scfy ||' and SJQJ='''||sjqj||''''); --部门庭审记录结案数 

   
   open rt for select a.*,b.zbdm,b.zbxx,b.sfbz,b.xssx,b.yx,b.gxts from B_JXKH_TEMP a,B_JXKH_RYZBWHXX b where a.scfy=b.scfy and a.sjqj=b.sjqj  and a.yhdm=b.yhdm order by b.yhlx desc;
 
 --open rt for select a.* from B_JXKH_TEMP a;
 end init_jxkhjczb;
   
 /*代码查询绩效考核类型*/
 function  getJxKhLx(dm varchar2) return varchar2 is
   jxkhMc varchar2(100);
   begin
      case (dm)
      when 'yefg' then
        jxkhMc:='员额法官';
      when 'fgzl' then
        jxkhMc:='法官助理';
      when 'sjy' then
        jxkhMc:='书记员';
      when 'sfjsyfjry' then
        jxkhMc:='司法技术、法警人员考核' ; 
      else 
        jxkhMc :='';            
      end case;
      return jxkhMc;
   end  getJxKhLx;
 
end PKG_JXKH;
/

