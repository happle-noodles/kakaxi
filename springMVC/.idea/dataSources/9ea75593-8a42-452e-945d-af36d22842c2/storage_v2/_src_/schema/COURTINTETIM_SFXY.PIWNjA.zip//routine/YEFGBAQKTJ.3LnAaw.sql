create PROCEDURE YeFgBaQkTj(fytj varchar2,qsrq varchar2,jsrq varchar2,rt out pkg_row.myRow) as
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_xstj varchar2(100);
begin
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
  select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);


   v_scfy:='(select dm from b_fy where dm between 4166 and 4208 and '|| fytj ||')';

  execute immediate 'INSERT INTO B_TEMPTJFX(SCFY,FYJC,DM,MC,TSMC) SELECT A.SCFY,(SELECT FYJC FROM B_FY WHERE DM=A.SCFY),A.YHDM,A.YHXM,F_GETDMMC(A.FYZW,''GF2009-01050'') FROM B_YHDM a,B_TSDM B,b_fy c WHERE A.SCFY in'|| v_scfy||' and A.SCFY=B.SCFY AND  a.scfy=c.dm and A.TSDM=B.TSDM AND  nvl(sfggfl,0)=1 ORDER BY c.xssx, B.XSSX,A.XSSX';


  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,CBR,scfy FROM B_AJZTXX WHERE  '||v_yjtj||' AND  scfy in '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.CBR,B_AJZTXX.scfy)B
    ON(A.DM=B.CBR and a.scfy=b.scfy) when matched then update set A.YJ=B.SL';--主审已结件数
    --主审已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,CBR,scfy FROM B_AJZTXX WHERE  '||v_wjtj||' AND  scfy in '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.CBR,B_AJZTXX.scfy)B
    ON(A.DM=B.CBR  and a.scfy=b.scfy) when matched then update set A.WJ=B.SL';--主审未结件数
  --主审未结合计
  UPDATE B_TEMPTJFX SET SLS=NVL(YJ,0)+NVL(WJ,0);--主审合计

  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY,a.scfy FROM B_SPZZCY A LEFT JOIN B_AJZTXX C ON A.AJBS=C.AJBS WHERE  ('||v_yjtj||' or'||v_wjtj||')  AND A.YCY!=C.CBR AND C.SCFY in '||v_scfy||' AND (C.KPLB<19 OR (C.KPLB>19 AND C.KPLB<30) OR C.KPLB>39) AND A.JS IN(3,4,5,6) GROUP BY A.YCY,a.scfy)B
    ON(A.DM=B.YCY  and a.scfy=b.scfy) when matched then update set A.JCYJ=B.SL';


 execute immediate '  merge into B_TEMPTJFX  A
 using(select
      t.scfy,t.cbr,
      sum(decode(t.kplb, 7, SL,0)) as xsyj,
      sum(decode(t.kplb, 8, SL,0)) as xswj,
      sum(decode(t.kplb, 9, SL,0)) as xs,
      sum(decode(t.kplb, 12,SL,21,sl,41,sl,44,sl,46,sl,50,sl,0)) as jc,
      sum(decode(t.kplb, 1, SL,0)) as wjcsx,
      sum(decode(t.kplb, 2, SL,0)) as yjcsx,
      sum(decode(t.kplb, 3, SL,0)) as wjyc,
      sum(decode(t.kplb, 40,SL,45,sl,53,sl,61,sl,62,sl,63,sl,0)) as yjyc,
      sum(decode(t.kplb, 13, SL,0)) as wjzz,
      sum(decode(t.kplb, 14, SL,0)) as yjzz,
      sum(decode(t.kplb, 15, SL,0)) as yjkt,
      sum(decode(t.kplb, 42,SL,28,sl,47,sl,0)) as sxnsj,
      sum(decode(t.kplb, 4, SL,0)) as tcs,
      sum(decode(t.kplb, 16, SL,0)) as tjs,
      sum(decode(t.kplb, 18, SL,0)) as css,
      sum(decode(t.kplb, 29, SL,0)) as sxbgs,
      sum(decode(t.kplb, 17,SL,22,sl,43,sl,48,SL,49,sl,51,sl,52,SL,54,sl,55,sl,56,SL,57,sl,58,sl,59,sl,0)) as hys
      from (select count(*)as sl,scfy,cbr,kplb from b_ajztxx where ('||v_yjtj || ') and scfy in'|| v_scfy || ' group by scfy,cbr,kplb) t group by t.scfy,t.cbr) B
      ON (a.scfy=b.scfy and a.dm=b.cbr) when matched then
      update set A.xsyj=B.xsyj,a.xswj=b.xswj,A.xs=B.xs,a.jc=b.jc,a.wjcsx=b.wjcsx ,A.yjcsx=B.yjcsx,a.wjyc=b.wjyc ,A.yjyc=B.yjyc,a.wjzz=b.wjzz,a.yjzz=b.yjzz,a.yjkt=b.yjkt
      ,a.sxnsj=b.sxnsj,a.tcs=b.tcs,a.tjs=b.tjs,a.css=b.css,a.sxbgs=b.sxbgs,a.hys=b.hys';


    --协办案件数
     UPDATE B_TEMPTJFX SET jcwj=NVL(JCYJ,0)+NVL(SLS,0);

    UPDATE B_TEMPTJFX SET JAL=round(NVL(YJ,0)*100/NVL(SLS,0),2) WHERE NVL(SLS,0)>0;

   open rt for SELECT scfy,fyjc,DM,MC,TSMC,YJ,WJ,SLS,JAL,JCYJ,jcwj,xsyj,xswj,xs,jc,wj,wjcsx,yjcsx,wjyc,yjyc,wjzz,yjzz,sxnsj,tcs,tjs,css,sxbgs,hys FROM  B_TEMPTJFX;
 end YeFgBaQkTj;
/

