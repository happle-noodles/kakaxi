create procedure p_cb_csx_fg_list(nscfy number ,nlx number,nyhdm number, rt out pkg_row.myRow) is
/*查询 法官 相关催办超审限案件数量 
nlx 1为催办 ，2为超审限，3带归档案件
*/
  v_sql varchar2(500);
  v_where varchar(500);

begin
 if nlx=1 then
      v_sql:='select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,sjymc,TO_CHAR(a.sxjmrq,''yyyy-MM-dd'') as sxjmrq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,f_getjsxzdts(a.ajbs) as ts from b_ajztxx a,b_ajcbqx b';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||' and (cbr='||nyhdm||' or sjymc=f_getyhxm('||nscfy||','||nyhdm||')) and a.larq is not null and a.jarq is null and f_getjsxzdts(a.ajbs) is not null';
      v_where:=v_where|| ' and a.kplb=b.kplb and a.scfy=b.scfy and f_getjsxzdts(a.ajbs) between 0  and b.cbts ';
      end if;


if nlx=2 then

      v_sql:='select a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,sjymc,TO_CHAR(a.sxjmrq,''yyyy-MM-dd'') as sxjmrq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,(0-f_getjsxzdts(a.ajbs)) as ts from b_ajztxx  a';
      v_where:=' where  scfy='||  to_char(nscfy) ||'and (cbr='||nyhdm||' or sjymc=f_getyhxm('||nscfy||','||nyhdm||')) and a.larq is not null and jarq is null and f_getjsxzdts(a.ajbs) is not null';
      v_where:=v_where|| ' and f_getjsxzdts(a.ajbs)<0 ';
      end if;

 if nlx=3 then
      v_sql:='select  a.scfy,a.ajbs,a.kplb,a.ah,f_getay(a.laay)as laay ,a.dsrmc,TO_CHAR(a.jarq,''yyyy-MM-dd'') as jarq,sjymc,TO_CHAR(a.larq,''yyyy-MM-dd'') as larq,f_getyhxm(a.scfy,a.cbr)as cbr,a.ycts,a.fdsxts,a.kcts,a.syts,(b.gdqx-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-a.jarq)) as ts  from b_ajztxx a,b_gdcbqx b, b_ajfzxx c  ';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||' and  a.sjymc=f_getyhxm('||nscfy||','||nyhdm||') and b.scfy='||  to_char(nscfy) ||'  and a.jarq>=to_date(''2016-1-1'',''yyyy-mm-dd'') and a.ajbs=c.ajbs and a.kplb=b.kplb and a.jarq is not null and c.gdrq is null and b.cbts>=(b.gdqx-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-a.jarq))';
     end if;
     
 open rt for v_sql || v_where;

end p_cb_csx_fg_list;
/

