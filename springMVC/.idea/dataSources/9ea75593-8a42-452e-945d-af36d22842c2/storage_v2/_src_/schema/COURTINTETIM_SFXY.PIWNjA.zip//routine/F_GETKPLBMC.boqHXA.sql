create FUNCTION F_GETKPLBMC(nkplb number) return varchar2 is
  strMC nvarchar2(200);
  /*获取案件类型名称 杨元胜*/
begin
  SELECT MC INTO strMC FROM B_KPLB  WHERE KPLB = nkplb;
  RETURN strMC;
end;
/

