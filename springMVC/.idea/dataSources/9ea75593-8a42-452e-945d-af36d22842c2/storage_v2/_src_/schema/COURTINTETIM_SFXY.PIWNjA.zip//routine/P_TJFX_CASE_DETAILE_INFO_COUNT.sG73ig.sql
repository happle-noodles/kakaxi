create PROCEDURE P_TJFX_CASE_DETAILE_INFO_COUNT(nScfy varchar2, qsrq varchar2,jsrq varchar2,zhtj varchar2,pttj varchar2,rt out pkg_row.myRow) as
/*统计分析二级页面分组信息 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_tj varchar2(3000);
v_fztj varchar2(400);
v_sql varchar2(200);
str VARCHAR2 (200);
v_scfy varchar2(400);
j INT := 0;
i INT := 1;
len INT := 0;
v_temp varchar2(200);
m int :=0;

begin
  if nScfy='1' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='全兵团法院';
   elsif nScfy='2' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='兵团中级人民法院';
   elsif nScfy='3' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='兵团基层人民法院';
   elsif instr(nScfy,'+')>0 then
     select gsnr into v_scfy from b_tjfxgs where gsmc='中院地区';
     v_scfy :=replace(v_scfy,'＆SCFY＆',replace(nScfy,'+'));
   else
      v_scfy:='SCFY='||nScfy;
   end if;
    v_scfy:=v_scfy||' and (KPLB<19 OR (KPLB>19 AND KPLB<30) OR KPLB>39)';
  len := LENGTH(zhtj);
  /* 替换组合条件*/
    while j<len
     loop
       j := INSTR (zhtj, '#', i);
        IF j = 0
        THEN
             j := len;
             str := SUBSTR (zhtj, i);
            IF i >= len
            THEN
                EXIT;
            END IF;
        ELSE
            str := SUBSTR (zhtj, i, j - i);
            i := j + 1;
        END IF;
        if instr(str,'@',1)>0
          then
          v_temp :=str;
          len :=LENGTH(v_temp);
          m :=0;
          j :=0;
          i :=1;
          while j<len
            loop
              j := INSTR (v_temp, '@', i);
              IF j = 0
                THEN
                  j := len;
                  m :=1;
                  str := SUBSTR (v_temp, i);
                  IF i >= len
                    THEN
                    EXIT;
                    END IF;
                  ELSE
                    str := SUBSTR (v_temp, i, j - i);
                    m :=2;
                    i := j + 1;
                  END IF;
                  v_sql:= 'select gsnr  from b_tjfxgs where gsjc='''||str||'''';
                  execute immediate v_sql into v_fztj;
                  if length(v_fztj)=0
                    then
                      exit;
                    end if;

                    case
                      when 'YJ'=str or 'WJ'=str or 'XS'=str or 'JC'=str or 'SLS'=str then
                          v_fztj :=replace(v_fztj,'＆QsRq＆',qsrq);
                          v_fztj :=replace(v_fztj,'＆JsRq＆',jsrq);
                    else
                         dbms_output.put_line('123');
                         dbms_output.put_line(v_fztj);
                    end case;
                    /*dbms_output.put_line('456');
                    dbms_output.put_line(v_tj);
                    dbms_output.put_line(m);*/
                    IF m=2
                      then
                      v_tj:=v_tj||' and (('||v_fztj||' and '||v_scfy||')';
                    else
                       v_tj:=v_tj||' or ('||v_fztj||' and '||v_scfy||'))';
                      end if;
            end loop;

       else

       --DBMS_OUTPUT.put_line(str);
       v_sql:= 'select gsnr  from b_tjfxgs where gsjc='''||str||'''';

       execute immediate v_sql into v_fztj;
       if length(v_fztj)=0
         then
           exit;
         end if;
       case
        when 'YJ'=str or 'WJ'=str or 'XS'=str or 'JC'=str or 'SLS'=str then
           v_fztj :=replace(v_fztj,'＆QsRq＆',qsrq);
           v_fztj :=replace(v_fztj,'＆JsRq＆',jsrq);
        else
            dbms_output.put_line(v_fztj);
       end case;

       v_tj:=v_tj||' and '||v_fztj||' and '||v_scfy;
       end if;
    END LOOP;

       /* 获取分组列显示名称*/
          v_tj:='select COUNT(1) AS COUNT from b_ajztxx  where '||pttj||v_tj;

   open rt for v_tj;

end P_TJFX_CASE_DETAILE_INFO_COUNT;
/

