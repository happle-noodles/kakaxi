create PROCEDURE P_TJFX_ZDYSJ_GXFYSJAQKTJ(qsrq varchar2,jsrq varchar2,sjqj varchar2)
as
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_sjqj varchar2(1000);
v_yj varchar2(200);
kssj timestamp;
jssj timestamp;
v_qsrq varchar2(200);
v_jsrq varchar(200);
v_sjqjcs varchar(200);
months interval year to month;
begin

     v_qsrq :=qsrq;
     v_jsrq :=jsrq;
     v_sjqjcs :=sjqj;

   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   v_xstj :=replace(v_xstj,'＆QsRq＆',v_qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',v_jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',v_qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',v_jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',v_jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',v_qsrq);
   v_sjqj :=v_sjqjcs||'#'||v_qsrq||'#'||v_jsrq;

   execute immediate 'delete from b_tjhz WHERE SJQJ LIKE ''%'||v_sjqjcs||'#%'' ';

   INSERT INTO b_tjhz(KPLB,SJQJ,CJFY,FYJB,SJDM) SELECT A.KPLB,(''||v_sjqj||'') ,B.DM,B.FYJB,(CASE WHEN B.SJDM=4166 THEN B.DM ELSE B.SJDM END) AS SJDM  FROM B_KPLB a,b_fy b where b.dm BETWEEN 4166 AND 4208 and ((a.kplb<30 or kplb>39) and a.kplb<>19) ORDER BY B.DM,A.KPLB;

   execute immediate ' merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB)B
   ON(A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY)
   when matched then update set A.YJS=B.SL where  A.SJQJ='''||v_sjqj||'''';--已结数

   execute immediate'merge into B_TJHZ  A
   USING(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_xstj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   ON(A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY )
   when matched then update set A.XSS=B.SL where A.SJQJ='''||v_sjqj||'''';--新收数

   execute immediate'merge into B_TJHZ  A
   USING(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_wjtj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   ON (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY )
   when matched then update set A.WJS=B.SL where A.SJQJ='''||v_sjqj||'''';--未结数'

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_jctj||'  GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   ON (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY )
   WHEN matched then update set A.JCS=B.SL where A.SJQJ='''||v_sjqj||'''';--旧存数'



     execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND nvl(YCTS,-1)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY)
   WHEN matched then update set A.YJYCS=B.SL  where A.SJQJ='''||v_sjqj||'''';--已结延长数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND nvl(KCTS,-1)>0 GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY)
   WHEN matched then update set A.YJKCS=B.SL  where A.SJQJ='''||v_sjqj||'''';--已结扣除数

   execute immediate'merge into B_TJHZ  A
   using(SELECT SUM((JARQ-NVL(SXQSRQ,LARQ))-(CASE WHEN NVL(KCTS,0)>3600 THEN 0 ELSE NVL(KCTS,0) END))AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY )
   WHEN matched then update set A.PJSLTS=B.SL  where A.SJQJ='''||v_sjqj||'''';--平均审理天数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND ((nvl(YCTS,0)<=0 and nvl(CSXTS,0)<=0) or kplb=12 or kplb=22) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY)
   WHEN matched then update set A.FDQXNJAS=B.SL  where A.SJQJ='''||v_sjqj||''''; --法定审限结案数

   execute immediate'merge into B_TJHZ  A
   using(SELECT COUNT(1)AS SL,FZKPLB,SCFY FROM B_AJZTXX WHERE '||v_yjtj||'  AND (nvl(YCTS,-1)>0 OR nvl(KCTS,-1)>0) GROUP BY B_AJZTXX.SCFY,B_AJZTXX.FZKPLB) B
   on (A.KPLB=B.FZKPLB AND A.CJFY=B.SCFY )
   WHEN matched then update set A.YJSXBGS=B.SL where  A.SJQJ='''||v_sjqj||'''';--已结审限变更数
end;
/

