create view V_YH_CZRZ as
  select t.ajbs,t.scfy,
       (select fymc from b_fy where dm = t.scfy) as scfymc,
       (select mc
          from (select distinct (case
                                  when kplb = 18 then
                                   '申诉'
                                  else
                                   mc
                                end) as mc,
                                kplb
                  from b_kplb)
         where kplb = t.kplb) as kplbmc,
       t.ah,
       (select mc
          from b_dm
         where bh = (case
                 when t.kplb = 1 then
                  'GF2009-02202'
                 when t.kplb = 2 then
                  'GF2009-02304'
                 when t.kplb = 3 then
                  'GF2009-02503'
                 when t.kplb = 7 then
                  'GF2009-03202'
                 when t.kplb = 8 then
                  'GF2009-03004'
                 when t.kplb = 9 then
                  'GF2009-03401'
                 when t.kplb = 21 then
                  'GF2009-03504'
                 when t.kplb = 12 then
                  'GF2009-03603'
                 when t.kplb = 13 then
                  'GF2009-04201'
                 when t.kplb = 15 then
                  'GF2009-04401'
                 when t.kplb = 16 then
                  'GF2009-05008'
                 when t.kplb = 28 then
                  'GF2009-06005'
                 when t.kplb = 29 then
                  'GF2009-06005'
                 when t.kplb = 17 and t.ajlb = 1 then
                  'GF2009-07204'
                 when t.kplb = 17 and t.ajlb = 2 then
                  'GF2009-07302'
                 when t.kplb = 18 then
                  'GF2009-08002'
                 when t.kplb = 18 then
                  'GF2009-02304'
                 else
                  ''
               end)
           and ((t.kplb <> 8 and dm = t.ajly) or
               (t.kplb = 8 and dm = t.ssfw))) as ajlymc,
       (select aynr from b_ay where aydm = t.laay) as laaymc,
       (select mc
          from b_dm t
         where bh = 'GF2014-00001'
           and dm = t.ssyy) as ssyymc,
       to_char(t.larq,'yyyy-MM-dd') as larq,
       (select tsmc
          from b_tsdm
         where tsdm = t.cbspt
           and scfy = t.scfy) as cbsptmc,
       t.cbrmc,
       t.farmc,
       to_char(t.fasj,'yyyy-MM-dd') as fasj,
        to_char(t.jarq,'yyyy-MM-dd') as jarq,
        to_char(t1.bjrq,'yyyy-MM-dd') as bjrq,
 to_char(t1.gdrq,'yyyy-MM-dd') as gdrq,
       (select mc
          from b_dm
         where bh = (case
                 when t.kplb = 1 then
                  'GF2009-02208'
                 when t.kplb = 2 then
                  'GF2009-02312'
                 when t.kplb = 3 then
                  'GF2009-02509'
                 when t.kplb = 4 then
                  'GF2009-02612'
                 when t.kplb = 5 then
                  'GF2009-02404'
                 when t.kplb = 7 then
                  'GF2009-03215'
                 when t.kplb = 8 then
                  'GF2009-03304'
                 when t.kplb = 9 then
                  'GF2009-03407'
                 when t.kplb = 21 then
                  'GF2009-03511'
                 when t.kplb = 12 then
                  'GF2009-03612'
                 when t.kplb = 13 then
                  'GF2009-04205'
                 when t.kplb = 14 then
                  'GF2009-04304'
                 when t.kplb = 15 then
                  'GF2009-04408'
                 when t.kplb = 16 then
                  'GF2014-00049'
                  when t.kplb = 20 then
                  'GF2009-02312'
                 when t.kplb = 28 then
                  'GF2009-06203'
                 when t.kplb = 29 then
                  'GF2009-06303'
                 when t.kplb = 17 and t.ajlb = 1 then
                  'GF2009-07209'
                 when t.kplb = 17 and t.ajlb = 2 then
                  'GF2009-07309'
                 when t.kplb = 18 and t.scjdlx < 22 then
                  'GF2009-08203'
                 when t.kplb = 18 and t.scjdlx = 22 then
                  'GF2009-08306'
                 when t.kplb = 18 and t.scjdlx = 23 then
                  'GF2009-08307'
                 when t.kplb = 18 and t.scjdlx = 24 then
                  'GF2009-08308'
                 when t.kplb = 18 and t.scjdlx > 24 then
                  'GF2009-08309'
               end)
           and dm = t.jafs) as jafsmc,
           (select aynr
          from b_ay
         where aydm = t.jaay) as aynr, to_char(t.scrq,'yyyy-MM-dd') as scrq,

         (select  s.yhxm from b_yhdm s where s.yhdm=t.scr and s.scfy=t.scfy)  as scr ,
         (select  s.yhxm from b_yhdm s where s.yhdm=t.spr and s.scfy=t.scfy)  as spr ,
        to_char(t.lasprq,'yyyy-MM-dd') as lasprq,t.spyj,t.scyj,to_char(t1.sdszrq,'yyyy-MM-dd') as sdszrq
  from b_ajztxx t, b_ajfzxx t1
 where t.ajbs = t1.ajbs
/

