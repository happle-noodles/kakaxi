create PROCEDURE P_TJFX_DETAILE(nScfy varchar2, qsrq varchar2,jsrq varchar2,zhtj varchar2,pttj varchar2,v_group varchar2,rt out pkg_row.myRow) as
/*统计分析二级页面分组信息 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_tj varchar2(5000);
v_fztj varchar2(500);
v_sql varchar2(500);
str VARCHAR2 (500);
v_fzlm varchar2(220);
v_scfy varchar2(400);
j INT := 0;
i INT := 1;
len INT := 0;
v_jafsmc varchar2(2000);
v_ajlymc varchar2(1500);
v_ysfy varchar2(200);
v_temp varchar2(200);
v_kplb varchar2(100);
m int :=0;

begin
   select gsnr into v_ajlymc   from b_tjfxgs where gsmc='案件来源名称';
   select gsnr into v_jafsmc   from b_tjfxgs where gsmc='结案方式名称';
   select gsnr into v_ysfy   from b_tjfxgs where gsmc='原审法院名称';
   if nScfy='1' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='全兵团法院';
   elsif nScfy='2' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='兵团中级人民法院';
   elsif nScfy='3' then
     select gsnr into v_scfy from b_tjfxgs where gsmc='兵团基层人民法院';
   elsif instr(nScfy,'+')>0 then
     select gsnr into v_scfy from b_tjfxgs where gsmc='中院地区';
     v_scfy :=replace(v_scfy,'＆SCFY＆',replace(nScfy,'+'));
   else
      v_scfy:='SCFY='||nScfy;
   end if;
  v_kplb:=' and (KPLB<19 OR (KPLB>19 AND KPLB<30) OR KPLB>39)';
  len := LENGTH(zhtj);
  /* 替换组合条件*/
  while j<len
     loop
       j := INSTR (zhtj, '#', i);
        IF j = 0
        THEN
             j := len;
             str := SUBSTR (zhtj, i);
            IF i >= len
            THEN
                EXIT;
            END IF;
        ELSE
            str := SUBSTR (zhtj, i, j - i);
            i := j + 1;
        END IF;
        if instr(str,'@',1)>0
          then
          v_temp :=str;
          len :=LENGTH(v_temp);
          m :=0;
          j :=0;
          i :=1;
          while j<len
            loop
              j := INSTR (v_temp, '@', i);
              IF j = 0
                THEN
                  j := len;
                  m :=1;
                  str := SUBSTR (v_temp, i);
                  IF i >= len
                    THEN
                    EXIT;
                    END IF;
                  ELSE
                    str := SUBSTR (v_temp, i, j - i);
                    m :=2;
                    i := j + 1;
                  END IF;
                  v_sql:= 'select gsnr  from b_tjfxgs where gsjc='''||str||'''';
                  execute immediate v_sql into v_fztj;
                  if length(v_fztj)=0
                    then
                      exit;
                    end if;

                    case
                      when 'YJ'=str or 'WJ'=str or 'XS'=str or 'JC'=str or 'SLS'=str then
                          v_fztj :=replace(v_fztj,'＆QsRq＆',qsrq);
                          v_fztj :=replace(v_fztj,'＆JsRq＆',jsrq);
                    else
                         dbms_output.put_line('123');
                         dbms_output.put_line(v_fztj);
                    end case;
                    /*dbms_output.put_line('456');
                    dbms_output.put_line(v_tj);
                    dbms_output.put_line(m);*/
                    IF m=2
                      then
                      v_tj:=v_tj||' and (('||v_fztj||' and '||v_scfy||')';
                    else
                       v_tj:=v_tj||' or ('||v_fztj||' and '||v_scfy||'))';
                      end if;
            end loop;

       else

       --DBMS_OUTPUT.put_line(str);
       v_sql:= 'select gsnr  from b_tjfxgs where gsjc='''||str||'''';

       execute immediate v_sql into v_fztj;
       if length(v_fztj)=0
         then
           exit;
         end if;
       case
        when 'YJ'=str or 'WJ'=str or 'XS'=str or 'JC'=str or 'SLS'=str then
           v_fztj :=replace(v_fztj,'＆QsRq＆',qsrq);
           v_fztj :=replace(v_fztj,'＆JsRq＆',jsrq);
        else
            dbms_output.put_line(v_fztj);
       end case;

       v_tj:=v_tj||' and '||v_fztj||' and '||v_scfy;
       end if;
    END LOOP;
    v_tj:=v_tj||v_kplb;
    DBMS_OUTPUT.put_line(v_tj);

       /* 获取分组列显示名称*/
      case
         when v_group='CBSPT' THEN
          v_fzlm:='(SELECT TSMC FROM B_TSDM B WHERE '||v_scfy||' AND B.TSDM=b_ajztxx.CBSPT) AS MC';
          v_tj:='select count(ajbs) AS SZ,'||v_fzlm||',NVL(CBSPT,-1) AS DM from b_ajztxx  where '||pttj||v_tj||' group by '||v_group;
         when v_group='KPLB'THEN
          v_fzlm:='NVL((SELECT MC FROM B_KPLB B WHERE B.KPLB=A.KPLB),''未知案件类型'') AS MC';
          v_tj:='select count(*) AS SZ,'||v_fzlm||',NVL(KPLB,-1) AS DM from (SELECT (case when kplb =18 then nvl(ajlb,0)+kplb+4 else kplb end) as kplb  FROM b_ajztxx  where '||pttj||v_tj||') A group by '||v_group||' order by kplb';
           when v_group='SSYY'THEN
          v_fzlm:='NVL((SELECT MC FROM B_DM  B WHERE B.BH=''GF2014-00001'' AND  B.DM=b_ajztxx.SSYY),''未知诉讼语言'') AS MC';
          v_tj:='select count(ajbs) AS SZ,'||v_fzlm||',NVL(SSYY,-1) AS DM from b_ajztxx  where '||pttj||v_tj||' group by '||v_group;
          when v_group='LAAY'THEN
          v_fzlm:='NVL((SELECT AYNR FROM B_AY  B WHERE  B.AYDM=b_ajztxx.LAAY),''无案由'') AS MC';
          v_tj:='select count(ajbs) AS SZ,'||v_fzlm||',NVL(LAAY,-1) AS DM from b_ajztxx  where '||pttj||v_tj||' group by '||v_group;
          when v_group='CBR'THEN
          v_fzlm:='NVL((SELECT YHXM FROM B_YHDM  B WHERE  '||v_scfy||' AND B.YHDM=b_ajztxx.CBR ),''未知承办人'') AS MC';
          v_tj:='select count(ajbs) AS SZ,'||v_fzlm||',NVL(CBR,-1) AS DM from b_ajztxx  where '||pttj||v_tj||' group by '||v_group;
          when  v_group='JAFS'THEN
          v_tj:='select count(*) AS SZ,A.JAFSMC AS MC,A.JAFSMC AS DM from (SELECT '||v_jafsmc||'AS JAFSMC from b_ajztxx  where '||pttj||v_tj||') A group by A.JAFSMC';
          when  v_group='AJLY'THEN
          v_tj:='select count(*) AS SZ,A.AJLYMC AS MC,A.AJLYMC AS DM from (SELECT '||v_ajlymc||'AS AJLYMC from b_ajztxx  where '||pttj||v_tj||') A group by A.AJLYMC';
          when  v_group='YSFY'THEN
          v_tj:='select count(*) AS SZ,A.YSFYMC AS MC,A.YSFYMC AS DM from (SELECT '||v_ysfy||'AS YSFYMC from b_ajztxx  where '||pttj||v_tj||') A group by A.YSFYMC';
       end case;
        DBMS_OUTPUT.put_line('fisish:'||v_tj);
   open rt for v_tj;
end P_TJFX_DETAILE;
/

