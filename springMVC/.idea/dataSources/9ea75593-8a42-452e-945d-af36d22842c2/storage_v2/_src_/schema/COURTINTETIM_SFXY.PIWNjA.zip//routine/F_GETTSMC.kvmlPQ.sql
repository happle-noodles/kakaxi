create FUNCTION                   F_GETTSMC(nScFy number,nTsDm number) return varchar2 is
  strMC nvarchar2(100);
  /*获取庭室名称 杨元胜*/
begin
  SELECT TSMC INTO strMC FROM B_TSDM  WHERE SCFY = nScFy AND TSDM=nTsDm;
  RETURN strMC;
end;

/

