create PROCEDURE P_TJFX_SJFYGPFHCSTJ(fytj varchar2,fydm varchar2,v_qsrq varchar2,v_jsrq varchar2, rt out pkg_row.myRow) as
/*上级法院改判、发回重审、指令再审情况统计 杨元胜
fytj 查询法院
jnsjqj 今年时间区间
qnsjqj 去年时间区间
rt   返回数据集
*/
v_scfy varchar2(200);
v_xstj varchar2(200);
v_yjtj varchar2(200);
BEGIN
 IF fytj=1
   then
      v_scfy:='SCFY between 4166 and 4208';
 elsif fytj=2
   then 
      v_scfy:='SCFY between 4166 and 4208 and ysfy in(select dm from b_fy where fyjb=2 and dm between 4166 and 4208)';
elsif fytj=3
   then 
      v_scfy:='SCFY between 4166 and 4208 and ysfy in(select dm from b_fy where fyjb=1 and dm between 4166 and 4208)';
elsif fytj=4
   then 
      v_scfy:='SCFY between 4166 and 4208 and ysfy in(select dm from b_fy where sjdm='||fydm||' or dm='||fydm||')';
else
       v_scfy:='SCFY between 4166 and 4208 and ysfy='||fydm; 
end if;              
         
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   v_xstj :=replace(v_xstj,'＆QsRq＆',v_qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',v_jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',v_qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',v_jsrq);
   
insert into b_temptjfx (dm,mc,xssx) SELECT 1,'刑事',1 from dual;
insert into b_temptjfx (dm,mc,xssx) SELECT 7,'民事',7 from dual;
insert into b_temptjfx (dm,mc,xssx) SELECT 13,'行政',13 from dual;
insert into b_temptjfx (dm,mc,xssx) SELECT -1,'总计',50 from dual;

execute immediate 'merge into b_temptjfx A
   using (SELECT COUNT(*) AS SL,M.KPLB FROM (SELECT KPLB-1 AS KPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS YSFY,SCFY FROM B_AJZTXX WHERE '||v_xstj||' AND KPLB IN(2,8,14)) M WHERE '||v_scfy||' GROUP BY KPLB) B
   on (A.DM=B.KPLB)
   WHEN matched then update set A.XS=B.SL';
--二审改判数   
execute immediate 'merge into b_temptjfx A
   using (SELECT COUNT(*) AS SL,M.KPLB FROM (SELECT KPLB-1 AS KPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS YSFY,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND KPLB IN(2,8,14) AND JAFS=2) M WHERE '||v_scfy||' GROUP BY KPLB) B
   on (A.DM=B.KPLB)
   WHEN matched then update set A.XSYJ=B.SL'; 
--二审发回重审数   
execute immediate 'merge into b_temptjfx A
   using (SELECT COUNT(*) AS SL,M.KPLB FROM (SELECT KPLB-1 AS KPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS YSFY,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND KPLB IN(2,8,14) AND JAFS=3) M WHERE '||v_scfy||' GROUP BY KPLB) B
   on (A.DM=B.KPLB)
   WHEN matched then update set A.XSWJ=B.SL'; 
--再审改判数   
execute immediate 'merge into b_temptjfx A
   using (SELECT COUNT(*) AS SL,M.KPLB FROM (SELECT KPLB-2 AS KPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS YSFY,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND KPLB IN(3,9,15) AND JAFS=2) M WHERE '||v_scfy||' GROUP BY KPLB) B
   on (A.DM=B.KPLB)
   WHEN matched then update set A.JCYJ=B.SL'; 
--再审发回重审数      
execute immediate 'merge into b_temptjfx A
   using (SELECT COUNT(*) AS SL,M.KPLB FROM (SELECT KPLB-2 AS KPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS YSFY,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND KPLB IN(3,9,15) AND JAFS=3) M WHERE '||v_scfy||' GROUP BY KPLB) B
   on (A.DM=B.KPLB)
   WHEN matched then update set A.JCWJ=B.SL';   
   
 --再审发回重审数      
execute immediate 'merge into b_temptjfx A
   using (SELECT COUNT(*) AS SL,M.KPLB FROM (SELECT (CASE WHEN AJLB=1 THEN 1 WHEN  AJLB=2 THEN 7 WHEN  AJLB=3 THEN 13 END) AS KPLB,(SELECT JBFY FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) AS YSFY,SCFY FROM B_AJZTXX WHERE '||v_yjtj||' AND KPLB=18 AND JAFS IN(4,5)) M WHERE '||v_scfy||' GROUP BY KPLB) B
   on (A.DM=B.KPLB)
   WHEN matched then update set A.YJ=B.SL';        
   
   --上诉新收数
update b_temptjfx set XS=(SELECT SUM(XS) FROM b_temptjfx) WHERE DM=-1; 
update b_temptjfx set XSYJ=(SELECT SUM(XSYJ) FROM b_temptjfx) WHERE DM=-1; 
update b_temptjfx set XSWJ=(SELECT SUM(XSWJ) FROM b_temptjfx) WHERE DM=-1;
update b_temptjfx set JCYJ=(SELECT SUM(JCYJ) FROM b_temptjfx) WHERE DM=-1; 
update b_temptjfx set JCWJ=(SELECT SUM(JCWJ) FROM b_temptjfx) WHERE DM=-1;
update b_temptjfx set YJ=(SELECT SUM(YJ) FROM b_temptjfx) WHERE DM=-1;  
  

open rt for select DM,MC,XS AS SSS,XSYJ AS ESGPS,XSWJ AS ESFHCSS,JCYJ AS ZSGPS,JCWJ AS ZSFHCSS,YJ AS SSZLZSS from b_temptjfx ORDER BY XSSX;

END P_TJFX_SJFYGPFHCSTJ;
/

