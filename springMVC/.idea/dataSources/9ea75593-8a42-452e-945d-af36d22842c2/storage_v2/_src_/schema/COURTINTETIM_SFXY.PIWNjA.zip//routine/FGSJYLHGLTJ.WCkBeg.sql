create PROCEDURE FgSjyLhGlTj(nscfy number,qsrq varchar2,jsrq varchar2,ntsdm number,rt out pkg_row.myRow) as
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_xstj varchar2(100);
begin
  select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
  select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
  select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
  select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
  select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);

  if ntsdm=0 then
    execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) SELECT YHDM,YHXM FROM B_YHDM WHERE '||v_scfy||' ORDER BY TSDM,XSSX';
  else
    execute immediate 'INSERT INTO B_TEMPTJFX(DM,MC) SELECT YHDM,YHXM FROM B_YHDM WHERE '||v_scfy||' AND TSDM='||ntsdm||'  ORDER BY XSSX';
  end if;
  dbms_output.put_line('SELECT COUNT(1)AS SL,SADJR FROM B_AJZTXX WHERE  ('||v_yjtj||' OR '||v_wjtj||') AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.SADJR');
  INSERT INTO B_TEMPTJFX(DM,MC) values(-1,'合计');
  execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL,SADJR FROM B_AJZTXX WHERE  '||v_xstj||' AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.SADJR)B
    ON(A.DM=B.SADJR) when matched then update set A.SLS=B.SL';--立案件数
  /*execute immediate ' merge into B_TEMPTJFX  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE   '||v_xstj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.SLS=B.SL where A.DM=-1';*/--立案合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.XSYJ=B.SL';--主审已结件数
  /*execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.XSYJ=B.SL where A.DM=-1';*/--主审已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,CBR FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||' GROUP BY B_AJZTXX.CBR)B
    ON(A.DM=B.CBR) when matched then update set A.XSWJ=B.SL';--主审未结件数
  /*execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||')B
    ON(1=1) when matched then update set A.XSWJ=B.SL where A.DM=-1';*/--主审未结合计
  UPDATE B_TEMPTJFX SET XS=NVL(XSYJ,0)+NVL(XSWJ,0);--主审合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY A LEFT JOIN B_AJZTXX C ON A.AJBS=C.AJBS WHERE  '||v_yjtj||' AND A.YCY!=C.CBR AND C.SCFY='||nscfy||' AND (C.KPLB<19 OR (C.KPLB>19 AND C.KPLB<30) OR C.KPLB>39) AND A.JS IN(3,4,5,6) GROUP BY A.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.JCYJ=B.SL';--协办已结件数
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY A LEFT JOIN B_AJZTXX C ON A.AJBS=C.AJBS WHERE  '||v_wjtj||' AND A.YCY!=C.CBR AND C.SCFY='||nscfy||' AND (C.KPLB<19 OR (C.KPLB>19 AND C.KPLB<30) OR C.KPLB>39) AND A.JS IN(3,4,5,6) GROUP BY A.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.JCWJ=B.SL';--协办未结件数

  /*execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY A LEFT JOIN B_AJZTXX C ON A.AJBS=C.AJBS WHERE  '||v_yjtj||' AND A.YCY!=C.CBR AND C.SCFY='||nscfy||' AND (C.KPLB<19 OR (C.KPLB>19 AND C.KPLB<30)) AND A.JS IN(3,4,5,6))B
    ON(1=1) when matched then update set A.JCYJ=B.SL where A.DM=-1';--协办已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY A LEFT JOIN B_AJZTXX C ON A.AJBS=C.AJBS WHERE  '||v_wjtj||' AND A.YCY!=C.CBR AND C.SCFY='||nscfy||' AND (C.KPLB<19 OR (C.KPLB>19 AND C.KPLB<30)) AND A.JS IN(3,4,5,6))B
    ON(1=1) when matched then update set A.JCWJ=B.SL where A.DM=-1';*/--协办未结合计
  UPDATE B_TEMPTJFX SET JC=NVL(JCYJ,0)+NVL(JCWJ,0); --协办合计

  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=3 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.YJCSX=B.SL';--审判长已结件数
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=3 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.WJCSX=B.SL';--审判长未结件数
  /*execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=3)B
    ON(1=1) when matched then update set A.YJCSX=B.SL where A.DM=-1';--审判长已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=3)B
    ON(1=1) when matched then update set A.WJCSX=B.SL where A.DM=-1';*/--审判长未结合计

  UPDATE B_TEMPTJFX SET YJ=NVL(YJCSX,0)+NVL(WJCSX,0); --审判长合计


  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS in(4,5,6) GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.YJYC=B.SL';--审判员已结件数
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS in(4,5,6) GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.WJYC=B.SL';--审判员未结件数
  /*execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS in(4,5))B
    ON(1=1) when matched then update set A.YJYC=B.SL where A.DM=-1';--审判员已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS in(4,5))B
    ON(1=1) when matched then update set A.WJYC=B.SL where A.DM=-1';*/--审判员未结合计
  UPDATE B_TEMPTJFX SET WJ=NVL(YJYC,0)+NVL(WJYC,0); --审判员合计

  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=7 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.YJZZ=B.SL';--陪审已结件数
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=7 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.WJZZ=B.SL';--陪审未结件数
 /* execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=7)B
    ON(1=1) when matched then update set A.YJZZ=B.SL where A.DM=-1';--陪审已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=7)B
    ON(1=1) when matched then update set A.WJZZ=B.SL where A.DM=-1';*/--陪审未结合计

  UPDATE B_TEMPTJFX SET YJKT=NVL(YJZZ,0)+NVL(WJZZ,0); --陪审合计

  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=8 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.SXNSJ=B.SL';--记录已结件数
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=8 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.TCS=B.SL';--记录未结件数
 /* execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS in(6,8))B
    ON(1=1) when matched then update set A.SXNSJ=B.SL where A.DM=-1';--记录已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS in(6,8))B
    ON(1=1) when matched then update set A.TCS=B.SL where A.DM=-1';*/--记录未结合计

  UPDATE B_TEMPTJFX SET TJS=NVL(SXNSJ,0)+NVL(TCS,0); --记录合计

  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=10 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.CSS=B.SL';--翻译已结件数
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL,YCY FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=10 GROUP BY B_SPZZCY.YCY)B
    ON(A.DM=B.YCY) when matched then update set A.SXBGS=B.SL';--翻译未结件数
  /*execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_yjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=10)B
    ON(1=1) when matched then update set A.CSS=B.SL where A.DM=-1';--翻译已结合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT COUNT(1)AS SL FROM B_SPZZCY WHERE AJBS IN(SELECT AJBS FROM B_AJZTXX WHERE  '||v_wjtj||' AND '||v_scfy||' AND '||v_kplb||') AND JS=10)B
    ON(1=1) when matched then update set A.SXBGS=B.SL where A.DM=-1';*/--翻译未结合计
  UPDATE B_TEMPTJFX SET HYS=NVL(CSS,0)+NVL(SXBGS,0); --翻译合计
  execute immediate ' merge into B_TEMPTJFX A
    using(SELECT SUM(SLS)SLS,SUM(XS) AS XS,SUM(XSYJ)AS XSYJ,SUM(XSWJ)AS XSWJ,SUM(JCYJ)AS JCYJ,SUM(JCWJ)AS JCWJ,SUM(JC)AS JC,SUM(YJCSX)AS YJCSX,SUM(YJ)AS YJ,SUM(YJYC)AS YJYC,SUM(WJYC)AS WJYC,SUM(WJ)AS WJ,SUM(YJZZ)AS YJZZ,SUM(WJZZ)AS WJZZ,SUM(YJKT)AS YJKT,SUM(SXNSJ)AS SXNSJ,SUM(TCS)AS TCS,SUM(TJS)AS TJS,SUM(CSS)AS CSS,SUM(SXBGS)AS SXBGS,SUM(HYS)AS HYS FROM B_TEMPTJFX)B
    ON(A.DM=-1) when matched then update set A.SLS=B.SLS, A.XSYJ=B.XSYJ,A.XSWJ=B.XSWJ,A.XS=B.XS,A.JCYJ=B.JCYJ,A.JCWJ=B.JCWJ,A.JC=B.JC,A.YJCSX=B.YJCSX,A.YJ=B.YJ,A.YJYC=B.YJYC,A.WJYC=B.WJYC,A.WJ=B.WJ,A.YJZZ=B.YJZZ,A.WJZZ=B.WJZZ,A.YJKT=B.YJKT,A.SXNSJ=B.SXNSJ,A.TCS=B.TCS,A.TJS=B.TJS,A.CSS=B.CSS,A.SXBGS=B.SXBGS,A.HYS=B.HYS';
  open rt for SELECT * FROM  B_TEMPTJFX where HYS>0 OR TJS>0 OR YJKT>0 OR SLS>0 OR XS>0 OR YJ>0 OR WJ>0 OR JC>0  order by SLS DESC,XS DESC;
end;
/

