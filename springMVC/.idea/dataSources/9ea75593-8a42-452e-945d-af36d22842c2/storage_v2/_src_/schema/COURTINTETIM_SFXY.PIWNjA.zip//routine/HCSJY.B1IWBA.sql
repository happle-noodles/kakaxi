create procedure                   HcSjy(nAjbs in number:=16,nKplb in number:=3) as
/*合并书记员、审判组织成员 杨元胜*/
Begin
   UPDATE B_AJZTXX  SET SJYMC=(select wmsys.wm_concat(mc) from (select (SELECT A.YHXM FROM B_YHDM A WHERE A.YHDM=B.YCY and A.SCFY=B.SCFY) as mc from B_SPZZCY B WHERE B.AJBS=nAjbs AND B.JS=8)) WHERE AJBS=nAjbs;
   UPDATE B_AJZTXX  SET SPZZCY=(select wmsys.wm_concat(mc) from (select (SELECT A.YHXM FROM B_YHDM A WHERE A.YHDM=B.YCY and A.SCFY=B.SCFY) as mc from B_SPZZCY B WHERE B.AJBS=nAjbs)) WHERE AJBS=nAjbs;
End HcSjy;

/

