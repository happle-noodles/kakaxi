create view V_XS_BB_BGR as
  SELECT A.AJBS,rownum AS XH,B.MC AS XM,(select MC from B_DM where BH='GF2009-00003' AND DM=B.XB)XB,B.Csrq,B.Sfzhm,NVL(B.Sfzhm,to_char(B.Csrq,'yyyy"年"MM"月"dd"日"'))CSRQSFZHM,
(select MC from B_DM where BH='GF2009-00005' AND DM=B.Mz)Mz,(select MC from B_DM where BH='GF2009-00016' AND DM=B.Sf)Sf,
B.Dz as ZZ,B.Lxdh,B.Yzbm,B.Zw,(select MC from B_DM where BH='GF2009-00008' AND DM=B.Zzmm)Zzmm,
(select MC from B_DM where BH='GF2009-00006' AND DM=B.Whcd)Whcd,A.ZFLX,''CFZ,''CLJ,''LF,(select (select AYNR from B_AY where AYDM=B_ZKZM.ZM) from B_ZKZM where SFBZ=(select MAX(SFBZ) from B_ZKZM where BGR=A.BGR AND AJBS=A.AJBS))QSZKZM,
(select (select MC from B_DM where BH='GF2009-02006' AND DM=B_QZCSJL.ZL)||'('||to_char(B_QZCSJL.SSRQ,'yyyy"年"MM"月"dd"日"')||')' from B_QZCSJL where SFBZ=(select MAX(SFBZ) from B_QZCSJL where BGR=A.BGR AND AJBS=A.AJBS AND AJBS=A.AJBS))QZCSZL,
(select wmsys.wm_concat((select AYNR from B_AY where AYDM=B_DZZM.ZM)) from B_DZZM where BGR=A.BGR AND AJBS=A.AJBS)PJJDZM,
(select (select MC from B_DM where BH='GF2009-02035' AND DM=B_DZLXXX.PCQK)PCQK from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))PJQK,
(select (select MC from B_DM where BH='GF2009-02036' AND DM=B_DZLXXX.WZYY)WZYY from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))WZYY,
(select MSCCJE from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))CCXJE1,(select MC from B_DM where BH='GF2009-00011' AND DM=B.XZJB)JB,
(select (select MC from B_DM where BH='GF2009-02040' AND DM=B_DZLXXX.DCFJX)DCFJX from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))FJXZL,
(select BDZZQLN from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))BDZZQLN,
(select BDZZQLY from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))BDZZQLY,
(select MSCCJE/10000 from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))CCXJE,
(select FJSE/10000 from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))DWFJSEX,A.FZJE/10000 AS FZJEX,
(select count(*) from B_DSRSSHD WHERE SLYQ LIKE '%1%' AND TSR=A.BGR AND AJBS=A.AJBS)CZFS,(select COUNT(*) from B_XSFDMSSSGK where AJBS=A.AJBS AND instr(BGR,A.BGR)>0 AND BGR IS NOT NULL)FDMSCLJG,
(select (CASE BDZZQLZS WHEN 1 THEN '终身' ELSE NVL(BDZZQLN||'年','')||NVL(BDZZQLY||'月','') END) from B_DZLXXX where SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))BDZZQLQX,A.ZASNL as SXFZSNL,
(select JYCS from B_QZCSJL WHERE SFBZ=(select MAX(SFBZ) from B_QZCSJL where BGR=A.BGR AND AJBS=A.AJBS))JYCS,(A.FZJE/10000)FFSDCWJZX,
(select LXSXRQ from B_DZLXXX WHERE SFBZ=(select MAX(SFBZ) from B_DZLXXX where BGR=A.BGR AND AJBS=A.AJBS))CPSX,
((select to_char(JE/10000,'fm9999990.9999') from B_SSDBQK where SFBZ=(select MAX(SFBZ) from B_SSDBQK where DSR=A.BGR AND AJBS=A.AJBS AND SCFY=A.SCFY)) ||'；'||(select (select MC from B_YASTML where AJBS=B_SSDBQK.AJBS AND SCFY=B_SSDBQK.SCFY AND XH=B_SSDBQK.DBR) from B_SSDBQK where SFBZ=(select MAX(SFBZ) from B_SSDBQK where DSR=A.BGR AND AJBS=A.AJBS AND SCFY=A.SCFY)))BZJEBZR
FROM B_XSBGR A, B_YASTML B WHERE A.BGR=B.XH AND A.AJBS=B.AJBS
/

