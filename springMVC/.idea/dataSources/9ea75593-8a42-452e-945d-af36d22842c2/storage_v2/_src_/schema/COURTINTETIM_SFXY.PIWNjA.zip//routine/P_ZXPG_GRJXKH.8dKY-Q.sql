create procedure P_ZXPG_GRJXKH(qsrq VARCHAR2,jsrq VARCHAR2, rt out pkg_row.myRow)
AS
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_tcs varchar2(400);
qskssj varchar2(20);
qsjssj varchar2(20);
v_qsxstj varchar2(200);
v_qsyjtj varchar2(200);
v_qsjctj varchar2(200);
begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';
   select gsnr into v_tcs   from b_tjfxgs where gsmc='调撤数';
   qskssj:='2011-11-26';
   qsjssj:='2014-11-25';
   v_qsxstj:=v_xstj; 
   v_qsyjtj:=v_yjtj; 
   v_qsjctj:=v_jctj; 
   
   v_qsxstj :=replace(v_qsxstj,'＆QsRq＆',qskssj);
   v_qsxstj :=replace(v_qsxstj,'＆JsRq＆',qsjssj);
   v_qsyjtj :=replace(v_qsyjtj,'＆QsRq＆',qskssj);
   v_qsyjtj :=replace(v_qsyjtj,'＆JsRq＆',qsjssj);
   v_qsjctj :=replace(v_qsjctj,'＆QsRq＆',qskssj);
   
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   
   insert into b_temptjfx(tsmc,mc,kplb) select '立案一庭','陈能汉',3 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案一庭','杨青',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案一庭','江帆',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案一庭','黄华',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案一庭','牛志建',12 from dual;
   
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','杜爱冬',6 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','徐鸿莉',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','郭毅',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','丁卫军',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','罗婷婷',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','程军',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '立案二庭','陈锋',12 from dual;

   insert into b_temptjfx(tsmc,mc,kplb) select '行政庭','贾洪',3 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '行政庭','吴龙',6 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '行政庭','王建敏',12 from dual;
   
   insert into b_temptjfx(tsmc,mc,kplb) select '民一庭','王彦博',3 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '民一庭','徐丽丽',6 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '民一庭','朱程文',12 from dual;
   
   insert into b_temptjfx(tsmc,mc,kplb) select '民二庭','刘霞',3 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '民二庭','李冰',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '民二庭','刘婷婷',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '民二庭','蔡立军',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '民二庭','苟振强',12 from dual;
      
   insert into b_temptjfx(tsmc,mc,kplb) select '民三庭','刘俊',3 from dual;
   
   insert into b_temptjfx(tsmc,mc,kplb) select '刑庭','陈浩礼',3 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '刑庭','张艳荣',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '刑庭','瓮亚琼',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '刑庭','阿曼古丽',12 from dual;
   
   insert into b_temptjfx(tsmc,mc,kplb) select '执行一庭','孙海军',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '执行二庭','薛梅',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '执行三庭','米合巴努尔',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '执行局','阿曼古丽',12 from dual;

   insert into b_temptjfx(tsmc,mc,kplb) select '审监一庭','胡志超',3 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '审监一庭','汪晓兰',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '审监一庭','杨正远',12 from dual;
   insert into b_temptjfx(tsmc,mc,kplb) select '审监一庭','黄婷婷',12 from dual;
   
   --此存储过程采用的虚拟表字段可能和显示的结果不一样。请注意
   
  --实际结案数YJ
   execute immediate 'merge into b_temptjfx
   using (SELECT COUNT(*) AS SLS,(SELECT YHXM FROM B_YHDM WHERE YHDM=CBR AND SCFY=4166) AS CBRMC FROM B_AJZTXX  WHERE '||v_yjtj||' AND '||v_kplb|| ' AND KPLB<>4 AND SCFY=4166 GROUP BY CBR)A
    ON (b_temptjfx.MC=CBRMC ) when matched then update set b_temptjfx.YJ=A.SLS';

  execute immediate 'merge into b_temptjfx
   using (SELECT COUNT(*)/5 AS SLS,(SELECT YHXM FROM B_YHDM WHERE YHDM=CBR AND SCFY=4166) AS CBRMC FROM B_AJZTXX  WHERE '||v_yjtj||' AND '||v_kplb|| ' AND KPLB=4 and sfktsl=1 AND SCFY=4166 GROUP BY CBR)A
    ON (b_temptjfx.MC=CBRMC ) when matched then update set b_temptjfx.YJ=b_temptjfx.YJ+A.SLS';
    
  execute immediate 'merge into b_temptjfx
   using (SELECT COUNT(*)/20 AS SLS,(SELECT YHXM FROM B_YHDM WHERE YHDM=CBR AND SCFY=4166) AS CBRMC FROM B_AJZTXX  WHERE '||v_yjtj||' AND '||v_kplb|| ' AND KPLB=4 and nvl(sfktsl,2)=2 AND SCFY=4166 GROUP BY CBR)A
    ON (b_temptjfx.MC=CBRMC ) when matched then update set b_temptjfx.YJ=round(b_temptjfx.YJ+A.SLS,0)';
    
    --庭室收案数XS
       execute immediate 'merge into b_temptjfx
   using (SELECT COUNT(*) AS SLS,(SELECT TSMC FROM B_TSDM WHERE TSDM=CBSPT AND SCFY=4166) AS CBSPTMC FROM B_AJZTXX  WHERE ('||v_xstj||' or '|| v_jctj ||') AND '||v_kplb|| ' AND SCFY=4166 GROUP BY CBSPT)A
    ON (b_temptjfx.tsmc=CBSPTMC ) when matched then update set b_temptjfx.XS=A.SLS';
    
    --结案数得分xswj
    update b_temptjfx set xswj=(yj-kplb)*0.2+20;
    update b_temptjfx set xswj=24 where xswj>24;
    
    update b_temptjfx set tsmc='执行局' where tsmc in('执行一庭','执行二庭','执行三庭');
    --人均办案数JC
    update b_temptjfx a set jc=round(a.xs/(select count(*) from b_temptjfx b where a.tsmc=b.tsmc),0);
    --前三年平均结案率wj
    execute immediate ' update b_temptjfx a set wj=round(100*(select count(*) from b_ajztxx where '||v_qsyjtj||' AND '||v_kplb|| ' AND KPLB<>4 AND SCFY=4166)
    /(select count(*) from b_ajztxx where ('||v_qsxstj||' or '|| v_qsjctj ||') AND '||v_kplb|| '  AND SCFY=4166),2)
    where (select count(*) from b_ajztxx where ('||v_qsxstj||' or '|| v_qsjctj ||') AND '||v_kplb|| ' AND SCFY=4166)>0';
    
    --法官结案数sls
    execute immediate 'merge into b_temptjfx
    using (SELECT COUNT(*) AS SLS,(SELECT YHXM FROM B_YHDM WHERE YHDM=CBR AND SCFY=4166) AS CBRMC FROM B_AJZTXX  WHERE ('||v_xstj||' or '|| v_jctj ||') AND '||v_kplb|| ' AND SCFY=4166 GROUP BY CBR)A
    ON (b_temptjfx.MC=CBRMC ) when matched then update set b_temptjfx.sls=A.SLS';
    
    --法官结案率 jal
      update b_temptjfx a set jal=round(100*yj/sls,0) where sls>0;
    
    --结案率得分jcyj
    update b_temptjfx set jcyj=round((jal-wj)*0.2,2)+20;
    update b_temptjfx set jcyj=22 where jcyj>22;

    
    --前三年调撤率 tjs 
    execute immediate ' update b_temptjfx a set tjs=round(100*(select count(*) from b_ajztxx where '||v_qsyjtj||' AND '||v_tcs|| ' AND SCFY=4166)
    /(select count(*) from b_ajztxx where '||v_qsyjtj||' and KPLB IN (7,8,9,1,2,3,13,14,15,21,12) AND SCFY=4166),2)-5
    where (select count(*) from b_ajztxx where '||v_qsyjtj||' AND  SCFY=4166 and KPLB IN (7,8,9,1,2,3,13,14,15,12,21))>0';
    
    
    
     --法官调解数 css 
    execute immediate 'merge into b_temptjfx
    using (SELECT COUNT(*) AS SLS,(SELECT YHXM FROM B_YHDM WHERE YHDM=CBR AND SCFY=4166) AS CBRMC FROM B_AJZTXX  WHERE '||v_yjtj||' AND '||v_tcs|| ' AND SCFY=4166 GROUP BY CBR)A
    ON (b_temptjfx.MC=CBRMC ) when matched then update set b_temptjfx.css=A.SLS';
     
    --可调解结案数xsyj 
    execute immediate 'merge into b_temptjfx
    using (SELECT COUNT(*) AS SLS,(SELECT YHXM FROM B_YHDM WHERE YHDM=CBR AND SCFY=4166) AS CBRMC FROM B_AJZTXX  WHERE '||v_yjtj||' AND KPLB IN (7,8,9,1,2,3,13,14,15,12,21) AND SCFY=4166 GROUP BY CBR)A
    ON (b_temptjfx.MC=CBRMC ) when matched then update set b_temptjfx.xsyj=A.SLS';
    
    --法官调解率
    update b_temptjfx set css=round(100*css/xsyj,2) where xsyj>0;
    
    --调解得分
    update b_temptjfx set jcwj=(css-tjs)*0.2+20;
    update b_temptjfx set jcwj=12 where jcwj>12;
    update b_temptjfx set jcwj=8 where jcwj<8;
    update b_temptjfx set jcwj=10 where css=0;
    
    update b_temptjfx set yjyc=jcwj+jcyj+xswj;
     
      
    open rt for SELECT * FROM  b_temptjfx ;

end P_ZXPG_GRJXKH;
/

