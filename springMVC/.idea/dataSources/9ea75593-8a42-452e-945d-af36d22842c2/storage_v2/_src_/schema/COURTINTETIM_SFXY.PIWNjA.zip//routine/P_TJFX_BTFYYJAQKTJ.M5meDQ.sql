create PROCEDURE                   P_TJFX_BtFyYjaQkTj(nscfy number,qsrq varchar2,jsrq varchar2,ndqsrq varchar2,ndjsrq varchar2, rt out pkg_row.myRow) as
/*月结案情况 杨元胜
nscfy 查询法院
qsrq 月起始日期
jsrq 月结束日期
ndqsrq 年度起始日期
ndjsrq 年度结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_jctj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);

v_qnxstj varchar2(200);
v_qnjctj varchar2(200);
v_qnyjtj varchar2(200);
v_qnwjtj varchar2(200);


v_scfy varchar2(200);
v_kplb varchar2(100);
v_ndxstj varchar2(200);
v_ndjctj varchar2(200);
v_ndyjtj varchar2(200);
v_ndwjtj varchar2(200);

v_qnndyjtj varchar2(200);
v_qnndwjtj varchar2(200);


v_qnqsrq varchar(20);
v_qnjsrq varchar(20);
v_qnndqsrq varchar(20);
v_qnndjsrq varchar(20);

v_qttj varchar2(500);
v_qttj1 varchar2(500);


begin
  v_qnqsrq:=to_char(add_months(to_date(qsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');
  v_qnjsrq:=to_char(add_months(to_date(jsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');

  v_qnndqsrq:=to_char(add_months(to_date(ndqsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');
  v_qnndjsrq:=to_char(add_months(to_date(ndjsrq,'yyyy-MM--dd'),-12) ,'yyyy-MM-dd');

   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_scfy  from b_tjfxgs where gsmc='生产法院';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_qnxstj:=v_xstj;
   v_qnjctj:=v_jctj;
   v_qnyjtj:=v_yjtj;
   v_qnwjtj:=v_wjtj;

   v_ndyjtj:=v_yjtj;
   v_ndwjtj:=v_wjtj;
   v_ndxstj:=v_xstj;
   v_ndjctj:=v_jctj;

   v_qnndyjtj:=v_yjtj;
   v_qnndwjtj:=v_wjtj;

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);

   v_qnxstj :=replace(v_qnxstj,'＆QsRq＆',v_qnqsrq);
   v_qnxstj :=replace(v_qnxstj,'＆JsRq＆',v_qnjsrq);
   v_qnjctj :=replace(v_qnjctj,'＆QsRq＆',v_qnqsrq);
   v_qnyjtj :=replace(v_qnyjtj,'＆QsRq＆',v_qnqsrq);
   v_qnyjtj :=replace(v_qnyjtj,'＆JsRq＆',v_qnjsrq);
   v_qnwjtj :=replace(v_qnwjtj,'＆JsRq＆',v_qnjsrq);

   v_ndxstj :=replace(v_ndxstj,'＆QsRq＆',ndqsrq);
   v_ndxstj :=replace(v_ndxstj,'＆JsRq＆',ndjsrq);
   v_ndjctj :=replace(v_ndjctj,'＆QsRq＆',ndqsrq);
   v_ndyjtj :=replace(v_ndyjtj,'＆QsRq＆',ndqsrq);
   v_ndyjtj :=replace(v_ndyjtj,'＆JsRq＆',ndjsrq);
   v_ndwjtj :=replace(v_ndwjtj,'＆JsRq＆',ndjsrq);

   v_qnndyjtj :=replace(v_qnndyjtj,'＆QsRq＆',v_qnndqsrq);
   v_qnndyjtj :=replace(v_qnndyjtj,'＆JsRq＆',v_qnndjsrq);
   v_qnndwjtj :=replace(v_qnndwjtj,'＆JsRq＆',v_qnndjsrq);

   v_scfy :=replace(v_scfy,'＆scfy＆',nscfy);


INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(1,'立案一庭',6,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(2,'立案一庭',6,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(3,'立案二庭',18,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(4,'立案二庭',18,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(5,'刑庭',1,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(6,'刑庭',1,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(7,'民一庭',2,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(8,'民一庭',2,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(9,'民二庭',3,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(10,'民二庭',3,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(11,'民三庭',23,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(12,'民三庭',23,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(13,'行政庭',4,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(14,'行政庭',4,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(15,'赔偿办',9,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(16,'赔偿办',9,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(17,'审监一庭',7,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(18,'减刑',-2,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(19,'审监一庭',7,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(20,'审监二庭',19,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(21,'审监二庭',19,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(22,'执行庭',255,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(23,'执行庭',255,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(24,'合计',-1,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(25,'执行一庭',5,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(26,'执行一庭',5,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(27,'执行二庭',21,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(28,'执行二庭',21,0);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(29,'执行三庭',24,1);
INSERT INTO B_TEMPYJAQKTJ(XH,BMMC,BMBS,AJLX)VALUES(30,'执行三庭',24,0);









  --今年新收(月)
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_xstj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.XS=B.SL WHERE AJLX=1';--一般案件
 execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_xstj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.XS=B.SL WHERE AJLX=0';--七类案件
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_xstj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.XS=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
  update B_TEMPYJAQKTJ  A SET A.XS=(select sum(XS) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
  update B_TEMPYJAQKTJ  A SET A.XS=(select sum(XS) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局


  --去年新收(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnxstj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNXS=B.SL WHERE AJLX=1';--一般案件
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnxstj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNXS=B.SL WHERE AJLX=0';--七类案件
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND  '||v_qnxstj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.QNXS=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
  update B_TEMPYJAQKTJ  A SET A.QNXS=(select sum(QNXS) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
  update B_TEMPYJAQKTJ  A SET A.QNXS=(select sum(QNXS) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局

  --今年旧存
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_jctj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.JC=B.SL WHERE AJLX=1';--一般案件
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_jctj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.JC=B.SL WHERE AJLX=0';--七类案件
  execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND  '||v_jctj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.JC=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
  update B_TEMPYJAQKTJ  A SET A.JC=(select sum(JC) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
  update B_TEMPYJAQKTJ  A SET A.JC=(select sum(JC) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局

  --今年改判(月)
   select gsnr into v_qttj  from b_tjfxgs where gsmc='改判数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.GP=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.GP=(select sum(GP) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.GP=(select sum(GP) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
  --去年改判(月)
    select gsnr into v_qttj  from b_tjfxgs where gsmc='改判数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNGP=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNGP=(select sum(QNGP) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNGP=(select sum(QNGP) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
  --改判同比(月)
   UPDATE B_TEMPYJAQKTJ SET GPTB=round((GP-QNGP)*100.0/QNGP,2) WHERE QNGP>0;

     --今年调撤(月)
   select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
   select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and ('|| v_qttj ||' OR '|| v_qttj1 ||') and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.TC=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.TC=(select sum(TC) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.TC=(select sum(TC) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
     --去年调撤(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and ('|| v_qttj ||' OR '|| v_qttj1 ||') and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNTC=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNTC=(select sum(QNTC) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNTC=(select sum(QNTC) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
    --调撤同比(月)
    UPDATE B_TEMPYJAQKTJ SET TCTB=round((TC-QNTC)*100.0/QNTC,2) WHERE QNTC>0;

    --今年发回重审(月)
    select gsnr into v_qttj  from b_tjfxgs where gsmc='发回重审数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.FH=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.FH=(select sum(FH) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.FH=(select sum(FH) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
     --去年发回重审(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNFH=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNFH=(select sum(QNFH) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNFH=(select sum(QNFH) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
      --发回重审同比(月)
   UPDATE B_TEMPYJAQKTJ SET FHTB=round((FH-QNFH)*100.0/QNFH,2) WHERE QNFH>0;

      --今年维持(月)
   select gsnr into v_qttj  from b_tjfxgs where gsmc='维持数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.WC=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.WC=(select sum(WC) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.WC=(select sum(WC) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年维持(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNWC=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNWC=(select sum(QNWC) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNWC=(select sum(QNWC) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --维持同比(月)
   UPDATE B_TEMPYJAQKTJ SET WCTB=round((WC-QNWC)*100.0/QNWC,2) WHERE QNWC>0;

       --今年判决(月)
     select gsnr into v_qttj  from b_tjfxgs where gsmc='判决数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.PJ=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.PJ=(select sum(PJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.PJ=(select sum(PJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年判决(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNPJ=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNPJ=(select sum(QNPJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNPJ=(select sum(QNPJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
     --判决同比(月)
   UPDATE B_TEMPYJAQKTJ SET PJTB=ROUND((PJ-QNPJ)*100.0/QNPJ,2) WHERE QNPJ>0;

   --今年驳回(月)
    select gsnr into v_qttj  from b_tjfxgs where gsmc='驳回数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.BH=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.BH=(select sum(BH) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.BH=(select sum(BH) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年驳回(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNBH=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNBH=(select sum(QNBH) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNBH=(select sum(QNBH) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --驳回同比(月)
   UPDATE B_TEMPYJAQKTJ SET BHTB=ROUND((BH-QNBH)*100.0/QNBH,2) WHERE QNBH>0;

    --今年再审(月)
    select gsnr into v_qttj  from b_tjfxgs where gsmc='再审数';
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.ZS=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.ZS=(select sum(ZS) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.ZS=(select sum(ZS) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年再审(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and '|| v_qttj ||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNZS=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNZS=(select sum(QNZS) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNZS=(select sum(QNZS) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --再审同比(月)
   UPDATE B_TEMPYJAQKTJ SET ZSTB=ROUND((ZS-QNZS)*100.0/QNZS,2) WHERE QNZS>0;
   --今年已结合计(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_yjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.HJ=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_yjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.HJ=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_yjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.HJ=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.HJ=(select sum(HJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.HJ=(select sum(HJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
    --今年已结合计(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnyjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNHJ=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnyjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNHJ=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnyjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.QNHJ=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.QNHJ=(select sum(QNHJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNHJ=(select sum(QNHJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
    --已结合计同比(月)
   UPDATE B_TEMPYJAQKTJ SET HJTB=round((HJ-QNHJ)*100.0/QNHJ,2) WHERE QNHJ>0;

    --今年其他结案数(月)
   UPDATE B_TEMPYJAQKTJ SET QT=HJ-NVL(GP,0)-NVL(TC,0)-NVL(FH,0)-NVL(WC,0)-NVL(PJ,0) -NVL(BH,0) -NVL(ZS,0) WHERE HJ>0;
   --去年其他结案数(月)
   UPDATE B_TEMPYJAQKTJ SET QNQT=QNHJ-NVL(QNGP,0)-NVL(QNTC,0)-NVL(QNFH,0)-NVL(QNWC,0)-NVL(QNPJ,0) -NVL(QNBH,0) -NVL(QNZS,0) WHERE QNHJ>0;
   --其他同比(月)
   UPDATE B_TEMPYJAQKTJ SET QTTB=round((QT-QNQT)*100.0/QNQT,2) WHERE QNQT>0;

     --今年未结(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_wjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.WJ=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_wjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.WJ=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_wjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.WJ=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.WJ=(select sum(WJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.WJ=(select sum(WJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年未结(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnwjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNWJ=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnwjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNWJ=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnwjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.QNWJ=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.QNWJ=(select sum(QNWJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNWJ=(select sum(QNWJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
    --未结同比(月)
   UPDATE B_TEMPYJAQKTJ SET WJTB=ROUND((WJ-QNWJ)*100.0/QNWJ,2) WHERE QNWJ>0;

   --今年结案率(月)
   UPDATE B_TEMPYJAQKTJ SET JAL=ROUND(HJ*100.0/(HJ+WJ),2) WHERE (HJ+WJ)>0;
   --去年结案率(月)
   UPDATE B_TEMPYJAQKTJ SET QNJAL=ROUND(QNHJ*100.0/(QNHJ+QNWJ),2) WHERE (QNHJ+QNWJ)>0;
   --结案率同比(月)
   UPDATE B_TEMPYJAQKTJ SET JALTB=ROUND(JAL-QNJAL,2);
   --今年调撤率(月)
   UPDATE B_TEMPYJAQKTJ SET TCL=ROUND(TC*100.0/HJ,2) WHERE HJ>0 and AJLX=1;
   --去年调撤率(月)
   UPDATE B_TEMPYJAQKTJ SET QNTCL=ROUND(QNTC*100.0/QNHJ,2) WHERE QNHJ>0 and AJLX=1;
      --结案率同比(月)
   UPDATE B_TEMPYJAQKTJ SET TCLTB=ROUND(TCL-QNTCL,2);

     --年度
   --今年结案数(年度)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_ndyjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDJA=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_ndyjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDJA=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_ndyjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.NDJA=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.NDJA=(select sum(NDJA) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.NDJA=(select sum(NDJA) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年结案数月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnndyjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNNDJA=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnndyjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNNDJA=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnndyjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.QNNDJA=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.QNNDJA=(select sum(QNNDJA) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNNDJA=(select sum(QNNDJA) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局

    --今年未结数(年度)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_ndwjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDWJ=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_ndwjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDWJ=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_ndwjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.NDWJ=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.NDWJ=(select sum(NDWJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.NDWJ=(select sum(NDWJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
   --去年未结数)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnndwjtj||' and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNNDWJ=B.SL WHERE AJLX=1';--一般案件
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnndwjtj||' and KPLB=22 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNNDWJ=B.SL WHERE AJLX=0';--七类案件
     execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_qnndwjtj||' and KPLB=4 )B ON(A.BMBS=-2) when matched then update set A.QNNDWJ=B.SL WHERE AJLX=1 and A.BMBS=-2';--减刑假释案件
    update B_TEMPYJAQKTJ  A SET A.QNNDWJ=(select sum(QNNDWJ) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNNDWJ=(select sum(QNNDWJ) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局

    --未结数同比(年度)
   UPDATE B_TEMPYJAQKTJ SET NDWJTB=ROUND((NDWJ-QNNDWJ)*100.0/QNNDWJ,2) WHERE QNNDWJ>0;
   --今年受理数(年度)
   UPDATE B_TEMPYJAQKTJ SET NDJNSL=NDJA+NDWJ;
   --去年受理数(年度)
   UPDATE B_TEMPYJAQKTJ SET NDQNSL=QNNDJA+QNNDWJ;
   --受理数同比(年度)
   UPDATE B_TEMPYJAQKTJ SET NDTB=ROUND((NDJNSL-NDQNSL)*100.0/NDQNSL,2) WHERE NDQNSL>0;
   --今年结案率(年度)
   UPDATE B_TEMPYJAQKTJ SET NDJAL= ROUND(NDJA*100.0/NDJNSL,2) WHERE NDJNSL>0;
   --去年结案率(年度)
   UPDATE B_TEMPYJAQKTJ SET QNNDJAL=ROUND(QNNDJA*100.0/NDQNSL,2) WHERE NDQNSL>0;
   --结案率同比(年度)
   UPDATE B_TEMPYJAQKTJ SET NDJALDB=NDJAL-QNNDJAL;

   --今年调撤(年度)
   select gsnr into v_qttj  from b_tjfxgs where gsmc='调解数';
   select gsnr into v_qttj1  from b_tjfxgs where gsmc='撤诉数';

    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_ndyjtj||' and ('|| v_qttj ||' OR '|| v_qttj1 ||') and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.NDTCL=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.NDTCL=(select sum(NDTCL) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.NDTCL=(select sum(NDTCL) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
    update B_TEMPYJAQKTJ  A SET A.NDTCL=ROUND(NDTCL*100/NDJA,2) where NDJA>0;
     --去年调撤(月)
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL,CBSPT FROM B_AJZTXX WHERE '||v_scfy||' AND '||v_kplb||' AND '||v_qnndyjtj||' and ('|| v_qttj ||' OR '|| v_qttj1 ||') and KPLB<>22 AND KPLB<>4 GROUP BY B_AJZTXX.CBSPT)B ON(A.BMBS=B.CBSPT) when matched then update set A.QNNDTCL=B.SL WHERE AJLX=1';--一般案件
    update B_TEMPYJAQKTJ  A SET A.QNNDTCL=(select sum(QNNDTCL) from B_TEMPYJAQKTJ) where  A.BMBS=-1; --合计
    update B_TEMPYJAQKTJ  A SET A.QNNDTCL=(select sum(QNNDTCL) from B_TEMPYJAQKTJ where B_TEMPYJAQKTJ.BMBS IN(5,21,24) AND B_TEMPYJAQKTJ.AJLX=A.AJLX) where A.BMBS=255; --执行局
    update B_TEMPYJAQKTJ  A SET A.QNNDTCL=ROUND(QNNDTCL*100/QNNDJA,2) where QNNDJA>0;
    --调解率同比(年度)
    UPDATE B_TEMPYJAQKTJ SET NDTCLDB=NDTCL-QNNDTCL;

    --申诉信访处理
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_xstj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSXS=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_jctj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSJC=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_yjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSYJ=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_wjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSWJ=B.SL WHERE AJLX=1 AND BMBS=-1';--今年申诉未结数
    execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndxstj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSXS=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉新收数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndjctj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSJC=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉旧存数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndyjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSYJ=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉已结数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_AJZTXX WHERE '||v_ndwjtj||' AND '||v_scfy||' and KPLB=18 )B ON(A.BMBS=-1) when matched then update set A.SSWJ=B.SL WHERE AJLX=1 AND BMBS=-1';--年度申诉未结数
    --dbms_output.put_line('SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ=1 AND (djsj>=to_date('||qsrq||',''yyyy-mm-dd'') and djsj<=to_date('||jsrq||',''yyyy-mm-dd''))');
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ=1 AND (djsj>=to_date('''||qsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||jsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.XFLX=B.SL WHERE AJLX=1 AND BMBS=-1';--今年信访来信数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ!=1 AND (djsj>=to_date('''||qsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||jsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.XFLF=B.SL WHERE AJLX=1 AND BMBS=-1';--今年信访来访数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ=1 AND (djsj>=to_date('''||ndqsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||ndjsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.NDXFLX=B.SL WHERE AJLX=1 AND BMBS=-1';--年度信访来信数
   execute immediate ' merge into B_TEMPYJAQKTJ  A
    using(SELECT COUNT(1)AS SL FROM B_XF WHERE '||v_scfy||' and KPLB=19 and XFTJ!=1 AND (djsj>=to_date('''||ndqsrq||''',''yyyy-mm-dd'') and djsj<=to_date('''||ndjsrq||''',''yyyy-mm-dd'')) )B ON(A.BMBS=-1) when matched then update set A.NDXFLF=B.SL WHERE AJLX=1 AND BMBS=-1';--年度信访来访数
   update B_TEMPYJAQKTJ set XF=(NVL(XFLX,0)+NVL(XFLF,0)) WHERE AJLX=1 AND BMBS=-1;
   update B_TEMPYJAQKTJ set NDXF=(NVL(NDXFLX,0)+NVL(NDXFLF,0)) WHERE AJLX=1 AND BMBS=-1;

   delete B_TEMPYJAQKTJ where BMBS in(5,21,24);



open rt for select * from B_TEMPYJAQKTJ order by XH;

end P_TJFX_BtFyYjaQkTj;

/

