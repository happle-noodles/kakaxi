create FUNCTION F_GETHYTCY(nAjbs number) return varchar2 is
  strHytcy nvarchar2(200);
  /*获取案件来源名称 徐新元*/
begin
  select wmsys.wm_concat(yhxm) into strHytcy from (select yhxm from b_yhdm e,b_spzzcy d where e.yhdm=d.ycy and e.scfy=d.scfy and d.js in(3,4,5,7) and d.ajbs=nAjbs order by d.sfbz);
  return strHytcy;
end;
/

