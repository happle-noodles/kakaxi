create package PKG_JXKH is

  -- Author  : YYS
  -- Created : 2018-08-09 15:27:15
  -- Purpose :

  type myRow is ref cursor;
  
  procedure init_jxkhjczbex( nscfy number, rt out varchar );

 procedure init_jxkhjczb(nscfy number, qsrq varchar2,jsrq varchar2 ,sjqj varchar2, rt out myRow);
  
   /*代码查询绩效考核类型*/
  function  getJxKhLx(dm varchar2) return varchar2;

end PKG_JXKH;
/

