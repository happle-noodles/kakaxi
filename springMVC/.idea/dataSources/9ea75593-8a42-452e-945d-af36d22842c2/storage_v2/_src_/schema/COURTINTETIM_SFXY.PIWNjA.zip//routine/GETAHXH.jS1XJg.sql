create function GetAhXh(ah varchar2) return varchar2 is
  Result varchar2(5);
  temp varchar2(2);
  nTemp integer;
begin
  for i in 1..6 loop
     temp:=substr(ah,(length(ah)-i),1);
     nTemp:=to_number(temp);
     Result:=Result||temp;

  end loop;
  EXCEPTION
        when others then
           dbms_output.put_line(temp);
  select reverse(Result) into Result from dual;
  return(Result);
end GetAhXh;
/

