create PROCEDURE P_TJFX_ZSAJDBTJ(fytj varchar2,jnsjqj varchar2,qnsjqj varchar2, rt out pkg_row.myRow) as
/*月结案情况 杨元胜
fytj 查询法院
jnsjqj 今年时间区间
qnsjqj 去年时间区间
rt   返回数据集
*/
v_scfy varchar2(200);
BEGIN
 v_scfy:='B_TJHZ.cjfy=b_fy.dm and b_fy.dm between 4166 and 4208 and '|| fytj;

insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'刑事',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'民事',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'行政',-1,0,0 from dual;
insert into b_tempaytj (aydm,aymc,sjdm,ayjb,kplb) SELECT 0,'总计',-1,0,0 from dual;

--今年民事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=9 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''民事'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNGPS=B.GPS,A.JNFHCSS=B.FHCSS';

--去年民事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=9 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''民事'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNGPS=B.GPS,A.QNFHCSS=B.FHCSS';

--今年刑事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=3 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''刑事'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNGPS=B.GPS,A.JNFHCSS=B.FHCSS';

--去年刑事一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=3 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''刑事'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNGPS=B.GPS,A.QNFHCSS=B.FHCSS';

--今年行政一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=15 AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''行政'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNGPS=B.GPS,A.JNFHCSS=B.FHCSS';

--去年行政一审案件
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB=15 AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''行政'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNGPS=B.GPS,A.QNFHCSS=B.FHCSS';

--今年总计
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB in (3,9,15) AND
  SJQJ LIKE '''||jnsjqj||''')B ON(A.AYMC=''总计'') when matched then
    update set A.JNSLS=B.SLS,A.JNXS=B.XSS,A.JNJC=B.JCS,A.JNYJ=B.YJS,A.JNTJS=B.TJS,A.JNGPS=B.GPS,A.JNFHCSS=B.FHCSS';

--去年总计
execute immediate 'merge into b_tempaytj A
    using(SELECT SUM(NVL(XSS,0)+NVL(JCS,0)) AS SLS,SUM(XSS)AS XSS,SUM(JCS)AS JCS,SUM(YJS)AS YJS,SUM(NVL(TJS,0)+NVL(CSS,0)) AS TJS,SUM(GPS) AS GPS,SUM(FHCSS) AS FHCSS
  FROM B_TJHZ,B_FY WHERE '||v_scfy||' AND KPLB in (3,9,15) AND
  SJQJ LIKE '''||qnsjqj||''')B ON(A.AYMC=''总计'') when matched then
    update set A.QNSLS=B.SLS,A.QNXS=B.XSS,A.QNJC=B.JCS,A.QNYJ=B.YJS,A.QNTJS=B.TJS,A.QNGPS=B.GPS,A.QNFHCSS=B.FHCSS';

    update b_tempaytj set jnjal= round(100*jnyj/jnsls,2) where jnsls>0;
    update b_tempaytj set qnjal= round(100*qnyj/qnsls,2) where qnsls>0;
  --调撤率
  update b_tempaytj set jnbhs=round(100*jntjs/jnyj,2) where jnyj>0;
  update b_tempaytj set qnbhs=round(100*qntjs/qnyj,2) where qnyj>0;
  --改判率
  update b_tempaytj set jnwcs=round(100*jngps/jnyj,2) where jnyj>0;
  update b_tempaytj set qnwcs=round(100*qngps/qnyj,2) where qnyj>0;
  --发回重审率
  update b_tempaytj set jnqts=round(100*jnfhcss/jnyj,2) where jnyj>0;
  update b_tempaytj set qnqts=round(100*qnfhcss/qnyj,2) where qnyj>0;

  -- open rt for select * from b_tempaytj;
   open rt for select * from b_tempaytj WHERE (JNSLS>0 OR QNSLS>0);
END P_TJFX_ZSAJDBTJ;

/

