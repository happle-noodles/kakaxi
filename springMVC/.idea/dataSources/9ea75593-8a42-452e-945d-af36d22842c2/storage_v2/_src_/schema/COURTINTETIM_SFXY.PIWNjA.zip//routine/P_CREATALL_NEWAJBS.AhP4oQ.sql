create procedure P_CREATALL_NEWAJBS as
begin
  declare
    cursor cur_a is
      SELECT AJBS
        FROM B_AJZTXX
       WHERE LARQ >=TO_DATE('2018-1-1','yyyy-mm-dd') and newajbs is null ;
  begin
    for line_a in cur_a loop              
      p_creat_najbs(v_ajbs => line_a.ajbs);       
       COMMIT;       
    end loop;

  end;
end P_CREATALL_NEWAJBS;
/

