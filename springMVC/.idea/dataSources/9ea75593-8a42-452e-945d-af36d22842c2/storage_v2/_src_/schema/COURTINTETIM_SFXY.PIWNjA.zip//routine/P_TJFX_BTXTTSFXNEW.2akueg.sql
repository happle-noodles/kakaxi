create PROCEDURE P_TJFX_BTXTTSFXNEW(jnsjqj varchar2,qnsjqj varchar2, rt out pkg_row.myRow) as
--兵团系统态势分析
begin
  --系统汇总
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''slstb'',''sls'',(select sum(yjs+wjs) from b_tjhz where sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''jcs'',(select sum(jcs) from b_tjhz where sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''yjs'',(select sum(yjs) from b_tjhz where sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''jaltb'',''jal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''sjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''sls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''jal'') from  dual');

 --系统刑事
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsslstb'',''xssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,5,40,45) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,5,40,45) and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''xsyjs'',(select sum(yjs) from b_tjhz where kplb in(1,2,3,5,40,45) and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''xsjaltb'',''xsjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(1,2,3,5,40,45) and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(1,2,3,5,40,45) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''xssjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''xssls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''xsjal'') from  dual');
  --系统民事
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msslstb'',''mssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''mssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''msyjs'',(select sum(yjs) from b_tjhz where kplb in(7,8,9,12,21,41,44,46,50) and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''msjaltb'',''msjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''mssjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''mssls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''msjal'') from  dual');
  --系统行政
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xzslstb'',''xzsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(13,14,15,28,42,47) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(13,14,15,28,42,47) and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzsls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''xzyjs'',(select sum(yjs) from b_tjhz where kplb in(13,14,15,28,42,47) and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''xzjaltb'',''xzjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(13,14,15,28,42,47) and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(13,14,15,28,42,47) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''xzsjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''xzsls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''xzjal'') from  dual');
  --系统赔偿
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''pcslstb'',''pcsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=17 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=17 and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''pcslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''pcsls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''pcyjs'',(select sum(yjs) from b_tjhz where kplb=17 and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''pcjaltb'',''pcjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=17 and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=17 and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''pcsjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''pcsls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''pcjal'') from  dual');
  --系统申诉
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''ssslstb'',''sssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(23,24,25,26,27) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where kplb in(23,24,25,26,27) and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''ssslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''sssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''ssyjs'',(select sum(yjs) from b_tjhz where kplb in(23,24,25,26,27) and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''ssjaltb'',''ssjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(23,24,25,26,27) and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(23,24,25,26,27) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''sssjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''sssls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''ssjal'') from  dual');
  --系统执行
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''zxslstb'',''zxsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=16 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=16 and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''zxslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''zxsls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''zxyjs'',(select sum(yjs) from b_tjhz where kplb=16 and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''zxjaltb'',''zxjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=16 and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=16 and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''zxsjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''zxsls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''zxjal'') from  dual');
  --系统减刑
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''jxjsslstb'',''jxjssls'',(select sum(yjs+wjs) from b_tjhz where  kplb=4 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=4 and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''jxjsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''jxjssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''jxjsyjs'',(select sum(yjs) from b_tjhz where kplb=4 and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''jxjsjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=4 and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=4 and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''jxjssjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''jxjssls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''jxjsjal'') from  dual');
  --系统七类案件
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''qlslstb'',''qlsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=22 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=22 and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''qlslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qlsls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''qlyjs'',(select sum(yjs) from b_tjhz where kplb=22 and  sjqj like '''||jnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''qljal'',(select (case when sum(yjs+wjs)>0 then round(sum(yjs)*100/sum(yjs+wjs),2) end) from b_tjhz where kplb=22  and sjqj like '''||jnsjqj||'%''),(select (case when sum(yjs+wjs)>0 then round(sum(yjs)*100/sum(yjs+wjs),2) end) from b_tjhz where kplb=22  and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj,xs) select -1,''qlsjatb'',(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''qlsls''),(select (case when yj-xs>0 then 1 when yj-xs<0 then -1 else 0 end) from b_temptjfx where mc=''qljal'') from  dual');
 --诉前保全与司法制裁、司法救助
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sqbqsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=29 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sqbqjas'',(select sum(yjs) from b_tjhz where  kplb=29 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sqbqjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=29 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=49 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcjas'',(select sum(yjs) from b_tjhz where  kplb=49 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=49 and sjqj like '''||jnsjqj||'%'') from dual');

  execute immediate ('insert into b_temptjfx (mc,yj) select ''sfjzsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=48 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sfjzyjs'',(select sum(yjs) from b_tjhz where  kplb=48 and sjqj like '''||jnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''sfjzjal'',(select (case when sum(yjs+wjs)>0 then round(sum(yjs)*100/sum(yjs+wjs),2) end) from b_tjhz where kplb=48  and  sjqj like '''||jnsjqj||'%'') from dual');

  --系统诉讼案件
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''yezsslstb'',''yezssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,7,8,9,13,14,15) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,7,8,9,13,14,15) and sjqj like '''||qnsjqj||'%'') from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''yezsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''yezssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''ysslstbl'',''yssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(1,7,13) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(1,7,13)  and sjqj like '''||qnsjqj||'%'') from dual');
  --民事一审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msysslstb'',''msyssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(7) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(7) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msysslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msyssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''msysbz'', round((select yj from b_temptjfx where mc=''msyssls'')*100/(select yj from  b_temptjfx where mc=''yssls''),2) from dual');
  --刑事一审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsysslstb'',''xsyssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(1) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(1) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsysslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsyssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''xsysbz'', round((select yj from b_temptjfx where mc=''xsyssls'')*100/(select yj from  b_temptjfx where mc=''yssls''),2) from dual');
  --行政一审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1, ''xzysslstb'',''xzyssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(13) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(13) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzysslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzyssls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''xzysbz'', round((select yj from b_temptjfx where mc=''xzyssls'')*100/(select yj from  b_temptjfx where mc=''yssls''),2) from dual');
  --刑事二审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''esslstbl'',''essls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(2,8,14) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(2,8,14) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsesslstb'',''xsessls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(2) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(2) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsessls'' and xs>0) from  dual');
  --民事二审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msesslstb'',''msessls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(8) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(8) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msessls'' and xs>0) from  dual');
  --行政二审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xzesslstb'',''xzessls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(14) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(14) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzessls'' and xs>0) from  dual');
   --刑事再审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''zsslstbl'',''zssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(3,9,15) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(3,9,15) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xszsslstb'',''xszssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(3) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(3) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xszsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xszssls'' and xs>0) from  dual');
  --民事再审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''mszsslstb'',''mszssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(9) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(9) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''mszsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''mszssls'' and xs>0) from  dual');
  --行政再审
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xzzsslstb'',''xzzssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(15) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(15) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzzsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzzssls'' and xs>0) from  dual');
 
  --执行
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''zxajtbj'',''zxajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(16) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(16) and sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''zxajtbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''zxajsls'' and xs>0) from  dual');

 --各师法院收结案情况

  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''gsfyslstb'',''gsfysls'',(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy<>4166 ),(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||qnsjqj||'%''and cjfy<>4166) from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''gsfyslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''gsfysls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''gsfyyjstb'',''gsfyyjs'',(select sum(yjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy<>4166 ),(select sum(yjs) from b_tjhz where  sjqj like '''||qnsjqj||'%''and cjfy<>4166) from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''gsfyyjstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''gsfyyjs'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''gsfyjaltb'',''gsfyjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where sjqj like '''||jnsjqj||'%'' and cjfy<>4166),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where sjqj like '''||qnsjqj||'%'' and cjfy<>4166)  from dual');



  --中级法院
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''zjfyslstb'',''zjfysls'',(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=2)),(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||qnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=2)) from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''zjfyslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''zjfysls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''zjfyxfbgsls'',(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=2 and kplb=4)) from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select''zjfyslsbz'' ,round((select yj from b_temptjfx where mc=''zjfysls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''zjfyjas'',(select sum(yjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=2)) from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''zjfyyjstbl'',''zjfyyjs'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=2) and  sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=2) and  sjqj like '''||qnsjqj||'%'')  from dual');

  --垦区法院
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''kqfyslstb'',''kqfysls'',(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1)),(select sum(yjs+wjs) from b_tjhz where  sjqj like '''||qnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1)) from dual');
  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''kqfyslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''kqfysls'' and xs>0) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select''kqfyslsbz'' ,round((select yj from b_temptjfx where mc=''kqfysls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''kqfyjas'',(select sum(yjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1)) from dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''kqfyjaltb'',''kqfyjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1) and  sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1) and  sjqj like '''||qnsjqj||'%'')  from dual');


  --兵团分院分析
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''btfyslstb'',''btfysls'',(select sum(yjs+wjs) from b_tjhz where cjfy=4166 and  sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where cjfy=4166 and sjqj like '''||qnsjqj||'%'') from dual');

  execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''btfyslstbl'',(select (yj-xs)*100/xs from b_temptjfx where mc=''btfysls'' and xs>0) from  dual');

  execute immediate ('insert into b_temptjfx (mc,yj) select ''btfyslsbz'',round((select yj from b_temptjfx where mc=''btfysls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
  execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''btfyjaltb'',''btfyjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where cjfy=4166 and  sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where cjfy=4166 and  sjqj like '''||qnsjqj||'%'')  from dual');
  execute immediate ('insert into b_temptjfx (mc,yj) select ''btfyyjs'',(select sum(yjs) from b_tjhz where  sjqj like '''||jnsjqj||'%''and cjfy=4166) from dual');

   --刑事案件审理情况
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajslstb'',''xsajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,5,40,45) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,5,40,45) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajsls'' and xs>0) from  dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajyjstb'',''xsajyjs'',(select sum(yjs) from b_tjhz where  kplb in(1,2,3,5,40,45) and sjqj like '''||jnsjqj||'%''),(select sum(yjs) from b_tjhz where  kplb in(1,2,3,5,40,45) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajyjstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajyjs'' and xs>0) from  dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''xsajjaltbl'',''xsajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(1,2,3,5,40,45) and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(1,2,3,5,40,45) and sjqj like '''||qnsjqj||'%'')  from dual');
   execute immediate ('insert into b_temptjfx (mc,yj) select ''xsajbz'' ,round((select yj from b_temptjfx where mc=''xsajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');

   --刑事一审分析
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsysajslstb'',''xsysajsls'',(select sum(yjs+wjs) from b_tjhz where kplb=1 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(1) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsysajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsysajsls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''xsysajslstb1'' ,(select (yj-xs) from b_temptjfx where mc=''xsysajsls'') from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajyswhslstb'',''xsajyswhsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=15) or laay =15) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=15) or laay =15) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajyswhslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajyswhsls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajysqfslstb'',''xsajysqfsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=199) or laay =199) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=199) or laay =199) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajysqfslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajysqfsls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajystwslstb'',''xsajystwsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=363) or laay =363) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=363) or laay =363) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajystwslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajystwsls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsajysgjaqslstbl'',''xsajysgjaqsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=2) or laay =2) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=2) or laay =2) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsajysphscslstbl'',''xsajysphscsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=58) or laay =58) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=58) or laay =58) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsajysqhccslstbl'',''xsajysqhccsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=161) or laay =161) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=161) or laay =161) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsajysfhzxslstbl'',''xsajysfhzxsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=212) or laay =212) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=212) or laay =212) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (mc,yj) select ''xsajysdzzsls'',(select sum(sls) from b_aytjhz where kplb=1 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=376) or laay =376) and sjqj like '''||jnsjqj||'%'') from dual');

    --刑事二审分析
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajesslstb'',''xsajessls'',(select sum(yjs+wjs) from b_tjhz where kplb=2 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where kplb=2 and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajessls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''xsesajslstb'' ,(select (yj-xs) from b_temptjfx where mc=''xsajessls'') from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajqfccslstbl'',''xsesajqfccsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=199) or laay =199) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=199) or laay =199) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajfashcxslstb'',''xsesajfashcxsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=212) or laay =212) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=212) or laay =212) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajqfgmqlsltbl'',''xsesajqfgmqlsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=161) or laay =161) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=161) or laay =161) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajtwshslstbl'',''xsesajtwshsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=363) or laay =363) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=363) or laay =363) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajphscjjslstbl'',''xsesajphscjjsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=58) or laay =58) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=58) or laay =58) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajwhggaqslstb'',''xsesajwhggaqsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=15) or laay =15) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=15) or laay =15) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''xsesajdzzslstbl'',''xsesajdzzsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=376) or laay =376) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=376) or laay =376) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (mc,yj) select ''xsesajwhgfsls'',(select sum(sls) from b_aytjhz where kplb=2 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=1 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=341) or laay =341) and sjqj like '''||jnsjqj||'%'') from dual');

    --刑事再审分析
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xsajzsslstb'',''xsajzssls'',(select sum(yjs+wjs) from b_tjhz where kplb=3 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where kplb=3 and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xsajzsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xsajzssls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''xszsajslstb'' ,(select (yj-xs) from b_temptjfx where mc=''xsajzssls'') from  dual');


  --民事案件审理情况
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msajslstb'',''msajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msajsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''msajyjs'',(select sum(yjs) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''msajjaltbl'',''msajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||qnsjqj||'%'')  from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''msajtcltbl'',''msajtcl'',(select round((sum(tjs)+sum(css))*100/sum(yjs),2) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||jnsjqj||'%''),(select round((sum(tjs)+sum(css))*100/sum(yjs),2) from b_tjhz where  kplb in(7,8,9,12,21,41,44,46,50) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''msajbz'' ,round((select yj from b_temptjfx where mc=''msajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');

   --民事分析
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msajysslstb'',''msajyssls'',(select sum(yjs+wjs) from b_tjhz where kplb=7 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=7 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msajysslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msajyssls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msajesslstb'',''msajessls'',(select sum(yjs+wjs) from b_tjhz where kplb=8 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=8 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msajesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msajessls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msajzsslstb'',''msajzssls'',(select sum(yjs+wjs) from b_tjhz where kplb=9 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=9 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msajysmaxfyslstb'',''msys无'',(select sum(sls) from b_aytjhz where kplb=7 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9130) or laay =9130) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb=7 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9130) or laay =9130) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msajysmaxfyslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msys无'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msajzsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msajzssls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''msajystb'' ,(select (yj-xs) from b_temptjfx where mc=''msajyssls'') from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''msajestb'' ,(select (yj-xs) from b_temptjfx where mc=''msajessls'') from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''msajzstb'' ,(select (yj-xs) from b_temptjfx where mc=''msajzssls'') from  dual');


    --合同纠纷案件
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htjfslstbj'',''htjfsls'',(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htjfslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htjfsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''htjfslstb'' ,(select (yj-xs) from b_temptjfx where mc=''htjfsls'') from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysslstbj'',''htysslstbj无'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysslstbj无'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysldzyslstbj'',''htysldzysls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9462) or laay =9462) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9462) or laay =9462) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysldzyslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysldzysls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htyslwhtslstbj'',''htyslwhtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9289) or laay =9289) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9289) or laay =9289) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htyslwhtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htyslwhtsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysmmhtslstbj'',''htysmmhtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9142) or laay =9142) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9142) or laay =9142) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysmmhtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysmmhtsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysfdcslstbj'',''htysfdcsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9158) or laay =9158) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9158) or laay =9158) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysfdcslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysfdcsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysjkhtslstbj'',''htysjkhtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9177) or laay =9177) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9177) or laay =9177) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysjkhtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysjkhtsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysjzhtslstbj'',''htysjzhtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9208) or laay =9208) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9208) or laay =9208) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysjzhtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysjzhtsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysfwhtslstbj'',''htysfwhtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9265) or laay =9265) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9265) or laay =9265) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysfwhtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysfwhtsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htysfwmmhtslstbj'',''htysfwmmhtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9162) or laay =9162) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9162) or laay =9162) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htysfwmmhtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htysfwmmhtsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htesslstbj'',''htessls'',(select sum(sls) from b_aytjhz where kplb in（8） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（8） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htessls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''htzsslstbj'',''htzssls'',(select sum(sls) from b_aytjhz where kplb in（9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9131) or laay =9131) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''htzsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''htzssls'' and xs>0) from  dual');


     --婚姻家庭、继承纠纷案件
      execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''hyjcslstbj'',''hyjcsls'',(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9012) or laay =9012) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9012) or laay =9012) and sjqj like '''||qnsjqj||'%'') from dual');
      execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''hyjcslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''hyjcsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''hyjcslstb'' ,(select (yj-xs) from b_temptjfx where mc=''hyjcsls'') from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''hyjchyslstbj'',''hyjchysls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9012) or laay =9012) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9012) or laay =9012) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''hyjchyslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''hyjchysls'' and xs>0) from  dual');

     --execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''hyjcjcslstbj'',''hyjcjcsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9039) or laay =9039) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9039) or laay =9039) and sjqj like '''||qnsjqj||'%'') from dual');
    -- execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''hyjcjcslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''hyjcjcsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''hyjcesslstbj'',''hyjcesslst'',(select sum(sls) from b_aytjhz where kplb in（8） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9012) or laay =9012) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（8） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9012) or laay =9012) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''hyjcesslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''hyjcesslst'' and xs>0) from  dual');


     --权属纠纷案件，侵权纠纷案件

     execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''qsjfslstb无'',(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM in(9001,9047)) or laay in(9001,9047)) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM in(9001,9047)) or laay in(9001,9047)) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''qsjfslstb'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qsjfslstb无'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''qqjfslstb无'',(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM in(9705)) or laay in(9705)) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM in(9705)) or laay in(9705)) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''qqjfslstb'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qqjfslstb无'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''qsqqslstbj'',''qsqqsls'',(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM in(9705,9001,9047)) or laay in(9705,9001,9047)) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7,8,9） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM in(9705,9001,9047)) or laay in(9705,9001,9047)) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''qsqqslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qsqqsls'' and xs>0) from  dual');
   --
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''qsqqysjdcsgslstb'',''qsqqysjdcsgsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9722) or laay =9722) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9722) or laay =9722) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''qsqqysjdcsgslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qsqqysjdcsgsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''qsqqyswqjfslstb'',''qsqqyswqjfsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9047) or laay =9047) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9047) or laay =9047) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''qsqqyswqjfslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qsqqyswqjfsls'' and xs>0) from  dual');

    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''qsqqysrgqslstb'',''qsqqysrgqsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9001) or laay =9001) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9001) or laay =9001) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''qsqqysrgqslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qsqqysrgqsls'' and xs>0) from  dual');




    /*
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msysajsyqslstbj'',''msysajsyqsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9062) or laay =9062) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9062) or laay =9062) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msysajsyqslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msysajsyqsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msysajrsqslstbj'',''msysajrsqsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9001) or laay =9001) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9001) or laay =9001) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msysajrsqslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msysajrsqsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''msysajjtslstbj'',''msysajjtsls'',(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9722) or laay =9722) and sjqj like '''||jnsjqj||'%''),(select sum(sls) from b_aytjhz where kplb in（7） and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=2 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=9722) or laay =9722) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''msysajjtslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''msysajjtsls'' and xs>0) from  dual');
     */

     --行政案件，赔偿案件
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xzajslstb'',''xzajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(13,14,15,28,42,47) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(13,14,15,28,42,47) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzajsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (mc,yj) select ''xzajyjs'',(select sum(yjs) from b_tjhz where  kplb in(13,14,15,28,42,47) and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''xsajjaltbl1'',''xzajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(13,14,15,28,42,47)  and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb in(13,14,15,28,42,47) and sjqj like '''||qnsjqj||'%'')  from dual');

     execute immediate ('insert into b_temptjfx (mc,yj) select ''xsajslszb'' ,round((select yj from b_temptjfx where mc=''xzajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xzysajslstb'',''xzysajsls'',(select sum(yjs+wjs) from b_tjhz where kplb=13 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=13 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzysajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzysajsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''xzesajslstb'',''xzesajsls'',(select sum(yjs+wjs) from b_tjhz where kplb=14 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=14 and sjqj like '''||qnsjqj||'%'') from dual');
      execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''xzesajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''xzesajsls'' and xs>0) from  dual');

     execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''xzzsajsls'',(select sum(yjs+wjs) from b_tjhz where kplb=15 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb=15 and sjqj like '''||qnsjqj||'%'') from dual');

     execute immediate ('insert into b_temptjfx (mc,yj) select ''xzysqtsls'',(select sum(sls) from b_aytjhz where kplb=13 and ( laay in(SELECT A.AYDM FROM (SELECT AYDM,AYNR,SJDM,AYJB,AYLB FROM B_AY WHERE AYLB=3 ) A CONNECT BY A.SJDM =PRIOR A.AYDM START WITH A.SJDM=5001) or laay =5001) and sjqj like '''||jnsjqj||'%'') from dual');


     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''pcajslstbl'',''pcajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=17 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb=17 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''pcajslszb'' ,round((select yj from b_temptjfx where mc=''pcajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''pcajslstb'' ,(select (yj-xs) from b_temptjfx where mc=''pcajsls'') from  dual');

     --执行案件
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''zxajslstbj'',''zxajsls1'',(select sum(yjs+wjs) from b_tjhz where  kplb=16 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb=16 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''zxajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''zxajsls1'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''zxajslstb'' ,(select (yj-xs) from b_temptjfx where mc=''zxajsls1'') from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''zxajyjs'',(select sum(yjs) from b_tjhz where  kplb=16 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''zxajzjltbl'',''zxajzjl'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=16  and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=16 and sjqj like '''||qnsjqj||'%'')  from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''zxajzb'' ,round((select yj from b_temptjfx where mc=''zxajsls1'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''zxajmsslstbl'',''zxajmssls'',(select sum(mssqzxs) from b_tjhz where  kplb=16 and sjqj like '''||jnsjqj||'%''),(select sum(mssqzxs) from b_tjhz where   kplb=16 and sjqj like '''||qnsjqj||'%'') from dual');

     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 3,''zxajtjslstbl'',''zxajtjsls'',(select sum(tjsqzxs) from b_tjhz where  kplb=16 and sjqj like '''||jnsjqj||'%''),(select sum(tjsqzxs) from b_tjhz where   kplb=16 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''zxajmsslstzb'' ,round((select yj from b_temptjfx where mc=''zxajmssls'')*100/(select yj from b_temptjfx where mc=''zxajsls1''),2) from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''zxajtjslszxajzb'' ,round((select yj from b_temptjfx where mc=''zxajtjsls'')*100/(select yj from b_temptjfx where mc=''zxajsls1''),2) from  dual');

     execute immediate ('insert into b_temptjfx (mc,yj) select ''zxajtjslszb'' ,round((select yj from b_temptjfx where mc=''zxajtjsls'')*100/(select sum(tjs) from b_tjhz where  kplb in(1,2,3,7,8,9,13,14,15) and sjqj like '''||jnsjqj||'%''),2) from  dual');


     --减刑、假释案件办理情况
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''jxjsajslstbj'',''jxjsajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=4 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb=4 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''jxjsajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''jxjsajsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''jxjsajtb'' ,(select (yj-xs) from b_temptjfx where mc=''jxjsajsls'') from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''jxjsajyjs'',(select sum(yjs) from b_tjhz where  kplb=4 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''jxjsajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=4  and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=4 and sjqj like '''||qnsjqj||'%'')  from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''jxjsajslszb'' ,round((select yj from b_temptjfx where mc=''jxjsajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');


     --申诉、申请再审案件办理情况
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''ssajslstbj'',''ssajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(23,24,25,26,27) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb in(23,24,25,26,27) and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''ssajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''ssajsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''ssajtb'' ,(select (yj-xs) from b_temptjfx where mc=''ssajsls'') from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''ssajyjs'',(select sum(yjs) from b_tjhz where  kplb in(23,24,25,26,27) and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''ssajjaltbl'',''ssajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where  kplb in(23,24,25,26,27)  and sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where  kplb in(23,24,25,26,27) and sjqj like '''||qnsjqj||'%'')  from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''ssajslszb'' ,round((select yj from b_temptjfx where mc=''ssajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''ssajxsslstbj'',''ssajxssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(23) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb in(23) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''ssajxsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''ssajxssls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''ssajxzslstbj'',''ssajxzsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(25) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb in(25) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''ssajxzslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''ssajxzsls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''ssajmsslstbj'',''ssajmssls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(24) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb in(24) and sjqj like '''||qnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''ssajmsslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''ssajmssls'' and xs>0) from  dual');
    execute immediate ('insert into b_temptjfx (mc,yj) select ''ssajpcsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=27 and sjqj like '''||jnsjqj||'%'') from dual');

    --七类案件
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 1,''qlajslstb'',''qlajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=22 and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where   kplb=22 and sjqj like '''||qnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''qlajslstbl'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''qlajsls'' and xs>0) from  dual');
     execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -3,''qlajtb'' ,(select (yj-xs) from b_temptjfx where mc=''qlajsls'') from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''qlajyjs'',(select sum(yjs) from b_tjhz where  kplb=22 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select  2,''qlajjaltb'',''qlajjal'',(select (case when sum(yjs+wjs)>0 then round(sum(yjs)*100/sum(yjs+wjs),2) end) from b_tjhz where kplb=22 and sjqj like '''||jnsjqj||'%''),(select (case when sum(yjs+wjs)>0 then round(sum(yjs)*100/sum(yjs+wjs),2) end) from b_tjhz where kplb=22  and sjqj like '''||qnsjqj||'%'')  from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''qlajslszb'' ,round((select yj from b_temptjfx where mc=''qlajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''qlajsls1'' ,(select yj from b_temptjfx where mc=''qlajsls'') from  dual');

    --诉前保全与司法制裁
     execute immediate ('insert into b_temptjfx (mc,yj) select ''bqajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=29 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''bqajyjs'',(select sum(yjs) from b_tjhz where  kplb=29 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''bqajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=29  and sjqj like '''||jnsjqj||'%'') from dual');

     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=49 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcajyjs'',(select sum(yjs) from b_tjhz where  kplb=49 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcajjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where kplb=49  and sjqj like '''||jnsjqj||'%'') from dual');
     
     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfjzajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb=48 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfjzajyjs'',(select sum(yjs) from b_tjhz where  kplb=48 and sjqj like '''||jnsjqj||'%'') from dual');
     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfjzajjal'',(select  (case when sum(yjs+wjs)>0 then  round(sum(yjs)*100/sum(yjs+wjs),2) end) from b_tjhz where kplb=48  and sjqj like '''||jnsjqj||'%'') from dual');
     
     
     execute immediate ('insert into b_temptjfx (mc,yj) select ''sfzcbqajslszb'' ,round((select sum(yj) as yj from b_temptjfx where mc=''bqajsls'' or  mc=''sfzcajsls'' or mc=''sfjzajsls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');




  --审判质量
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''fhcsltb'',''fhcsl'',(select round(sum(fhcss)*100/sum(yjs),2) from b_tjhz where  kplb in(2,3,8,9,14,15) and sjqj like '''||jnsjqj||'%''),(select round(sum(fhcss)*100/sum(yjs),2) from b_tjhz where  kplb in(2,3,8,9,14,15) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''zsltb'',''zsl'',(select round(sum(zss)*100/sum(yjs),2) from b_tjhz where  kplb in(23,24,25) and sjqj like '''||jnsjqj||'%''),(select round(sum(zss)*100/sum(yjs),2) from b_tjhz where  kplb in(23,24,25) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''gpltb'',''gpl'',(select round(sum(gps)*100/sum(yjs),2) from b_tjhz where  kplb in(2,3,8,9,14,15) and sjqj like '''||jnsjqj||'%''),(select round(sum(gps)*100/sum(yjs),2) from b_tjhz where  kplb in(2,3,8,9,14,15) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''zsscltb'',''zsscl'',round((select sum(zsscs) from b_tjhz where kplb in(23,24,25) and sjqj like '''||jnsjqj||'%'')*100/(select sum(yjs) from b_tjhz where kplb in(7,8,13,14,1,2) and sjqj like '''||jnsjqj||'%''),2),round((select sum(zsscs) from b_tjhz where kplb in(23,24,25) and sjqj like '''||qnsjqj||'%'')*100/(select sum(yjs) from b_tjhz where kplb in(7,8,13,14,1,2) and sjqj like '''||qnsjqj||'%''),2) from dual');

   --审判质量
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''qyjaltb'',''qyjal'',(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where  sjqj like '''||jnsjqj||'%''),(select round(sum(yjs)*100/sum(yjs+wjs),2) from b_tjhz where  sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 5,''qjslsjtb'',''qjslsj'',(select round(sum(PJSLTS)/sum(yjs),0) from b_tjhz where  sjqj like '''||jnsjqj||'%''),(select round(sum(PJSLTS)/sum(yjs),0) from b_tjhz where  sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (mc,yj) select ''spxlzjsls'',(select (yj-xs) from b_temptjfx where mc=''sls'' and xs>0) from dual');
   execute immediate ('insert into b_temptjfx (kplb,mc,yj) select -2,''spxlzjslstb'' ,(select (yj-xs)*100/xs from b_temptjfx where mc=''sls'' and xs>0) from  dual');


   --审判效果
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''ysfpxsltb'',''ysfpxsl'',(select round(100-sum(SSXSS)*100/sum(yjs),2) from b_tjhz where  kplb in(1,7,13) and sjqj like '''||jnsjqj||'%''),(select round(100-sum(SSXSS)*100/sum(yjs),2) from b_tjhz where  kplb in(1,7,13) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''tcltb'',''tcl'',(select round((sum(tjs)+sum(css))*100/sum(yjs),2) from b_tjhz where  kplb in(1,2,3,7,8,9,12,13,14,15,18,21) and sjqj like '''||jnsjqj||'%''),(select round((sum(tjs)+sum(css))*100/sum(yjs),2) from b_tjhz where  kplb in(1,2,3,7,8,9,12,13,14,15,18,21) and sjqj like '''||qnsjqj||'%'') from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''cpzdlxltb'',''cpzdlxl'',round(100-(select sum(sqzxajs) from b_tjhz where kplb=16 and sjqj like '''||jnsjqj||'%'')*100/(select sum(yjs) from b_tjhz where kplb in(7,8,9,13,14,15,12,21) and sjqj like '''||jnsjqj||'%''),2),round(100-(select sum(sqzxajs) from b_tjhz where kplb=16 and sjqj like '''||qnsjqj||'%'')*100/(select sum(yjs) from b_tjhz where kplb in(7,8,9,13,14,15,12,21) and sjqj like '''||qnsjqj||'%''),2) from dual');
   execute immediate ('insert into b_temptjfx (kplb,tsmc,mc,yj,xs) select 2,''zsscltb'',''zsscl'',round((select sum(zsscs) from b_tjhz where kplb in(23,24,25) and sjqj like '''||jnsjqj||'%'')*100/(select sum(yjs) from b_tjhz where kplb in(1,2,7,8,13,14) and sjqj like '''||jnsjqj||'%''),2),round((select sum(zsscs) from b_tjhz where kplb in(23,24,25) and sjqj like '''||qnsjqj||'%'')*100/(select sum(yjs) from b_tjhz where kplb in(1,2,7,8,13,14) and sjqj like '''||qnsjqj||'%''),2) from dual');



    --审判执行质效的意见
    execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''jcfysls'',(select sum(yjs+wjs) from b_tjhz where sjqj like '''||jnsjqj||'%'' and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1)),(select sum(yjs+wjs) from b_tjhz where sjqj like '''||qnsjqj||'%'' and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1)) from dual');
    execute immediate ('insert into b_temptjfx (mc,yj) select ''jcfyslszyl'' ,round((select yj from b_temptjfx where mc=''jcfysls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');

    execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''jcfyssajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(1,2,3,7,8,9,13,14,15) and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1) and sjqj like '''||jnsjqj||'%''),(select yj from b_temptjfx where mc=''yezssls'' and xs>0) from dual');
    execute immediate ('insert into b_temptjfx (mc,yj) select ''jcfyssajslstbl'',(select round(yj*100/xs,2) from b_temptjfx where mc=''jcfyssajsls'' and xs>0) from dual');

    execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''jcfyzxbqajsls'',(select sum(yjs+wjs) from b_tjhz where  kplb in(16,29) and cjfy in(select dm from b_fy where dm between 4166 and 4208 and fyjb=1) and sjqj like '''||jnsjqj||'%''),(select sum(yjs+wjs) from b_tjhz where  kplb in(16,29) and sjqj like '''||jnsjqj||'%'') from dual');
    execute immediate ('insert into b_temptjfx (mc,yj) select ''jcfyzxbqajslstbl'',(select round(yj*100/xs,2) from b_temptjfx where mc=''jcfyzxbqajsls'' and xs>0) from dual');

 execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''qxtzjsls'',(select (yj-xs) from b_temptjfx where mc=''sls'' and xs>0),(select (yj-xs) from b_temptjfx where mc=''kqfysls'' and xs>0) from dual');
 execute immediate ('insert into b_temptjfx (mc,yj) select ''jcfyzjsls'',(select (yj-xs) from b_temptjfx where mc=''kqfysls'' and xs>0)  from dual');
 execute immediate ('insert into b_temptjfx (mc,yj) select ''jcfyzjslstbl'',(select round(xs*100/yj,2) from b_temptjfx where mc=''qxtzjsls'' and xs>0) from dual');


    --execute immediate ('insert into b_temptjfx (mc,yj,xs) select ''btqymssls'',(select sum(yjs+wjs) from b_tjhz where kplb in(7,8,9,21,12) and sjqj like '''||jnsjqj||'%'' ),(select sum(yjs+wjs) from b_tjhz where kplb in(7,8,9,21,12) and sjqj like '''||qnsjqj||'%'') from dual');
    --execute immediate ('insert into b_temptjfx (mc,yj) select ''btqymsyssls'',(select sum(yjs+wjs) from b_tjhz where kplb in(7) and sjqj like '''||jnsjqj||'%'' ) from dual');
    --execute immediate ('insert into b_temptjfx (mc,yj) select ''byqymsyszl'' ,round((select yj from b_temptjfx where mc=''btqymssls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');
    --execute immediate ('insert into b_temptjfx (mc,yj) select ''jcfymszqymsl'' ,round((select yj from b_temptjfx where mc=''jcfysls'')*100/(select yj from b_temptjfx where mc=''sls''),2) from  dual');

 open rt for select kplb,tsmc,mc,yj,xs from b_temptjfx;

end P_TJFX_BTXTTSFXNEW;
/

