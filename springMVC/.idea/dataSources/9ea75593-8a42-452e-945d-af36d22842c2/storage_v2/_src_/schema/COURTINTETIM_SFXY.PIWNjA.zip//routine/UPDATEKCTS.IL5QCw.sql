create procedure UPDATEKCTS(nAjbs in number:=16) is
/*计算扣除天数 欧伟*/
begin
   UPDATE  B_AJZTXX SET KCTS=NVL((SELECT trunc(SUM(A.KCTS)) AS KCTS from (SELECT (JSRQ-QSRQ) AS KCTS from B_KCSXJL where JSRQ>=QSRQ AND AJBS=nAjbs  and (select nvl(sxqsrq,larq)from b_ajztxx where ajbs=nAjbs )<=qsrq) A),0)+NVL((SELECT trunc(SUM(B.KCTS)) AS KCTS from (SELECT ((select to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd') from dual)-QSRQ) AS KCTS from B_KCSXJL where (select sysdate from dual)>=QSRQ AND JSRQ IS NULL AND AJBS=nAjbs  and (select nvl(sxqsrq,larq)from b_ajztxx where ajbs=nAjbs)<=qsrq)B),0) WHERE AJBS=nAjbs;
   UPDATE  B_AJZTXX SET KCTS=null WHERE AJBS=nAjbs and KCTS=0;
end UPDATEKCTS;

/

