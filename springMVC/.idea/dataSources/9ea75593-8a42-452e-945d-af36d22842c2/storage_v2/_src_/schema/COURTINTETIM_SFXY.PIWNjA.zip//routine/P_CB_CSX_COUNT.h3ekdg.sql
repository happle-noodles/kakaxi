create procedure p_cb_csx_count(nscfy number ,nlx number, rt out pkg_row.myRow) is
/*计算未结案件距审限终点天数 杨元胜
nlx 1为催办 ，2为超审限  ，3 公告到期 ， 4 归档提醒 5  生效到期提醒
*/
  v_sql varchar2(500);
  v_where varchar(500);

begin
 if nlx=1 then
      v_sql:='select count(1) as count from b_ajztxx a,b_ajcbqx b';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||' and a.larq is not null and a.jarq is null and f_getjsxzdts(a.ajbs) is not null   and (select count(1) From b_kcsxjl c where c.ajbs=a.ajbs and c.scfy=a.scfy and c.jsrq is null)=0 ';
      v_where:=v_where|| ' and a.kplb=b.kplb and a.scfy=b.scfy and f_getjsxzdts(a.ajbs) between 0  and b.cbts ';
      end if;


       if nlx=2 then

      v_sql:='select count(1) as count from b_ajztxx  a';
      v_where:=' where  scfy='||  to_char(nscfy) ||' and a.larq is not null and jarq is null AND KPLB<>22 AND KPLB<>12 and f_getjsxzdts(a.ajbs) is not null';
      v_where:=v_where|| ' and f_getjsxzdts(a.ajbs)<0 ';
      end if;



  if nlx=3 then
       v_sql:='select count(1) as  count from b_ajztxx a,b_sdjl b ';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||' and  b.GGRQ IS NOT NULL AND b.GGQX IS NOT NULL AND b.GGQX-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-b.GGRQ) BETWEEN 0 AND 15 and  a.ajbs=b.ajbs';

end if;

 if nlx=4 then
      v_sql:='select  count(1) as count  from b_ajztxx a,b_gdcbqx b, b_ajfzxx c  ';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||' and b.scfy='||  to_char(nscfy) ||' and a.ajbs=c.ajbs and a.kplb=b.kplb and a.jarq is not null and a.jarq>=to_date(''2016-1-1'',''yyyy-MM-dd'') and c.gdrq is null and b.cbts>=(b.gdqx-(to_date(to_char(sysdate,''yyyy-MM-dd''),''yyyy-mm-dd'')-a.jarq))';
end if;

/*
王斌20150927加

*/
 if nlx=5 then
      v_sql:='select  count(1) as count  from b_ajztxx a   ';
      v_where:=' where  a.scfy='||  to_char(nscfy) ||'   and (a.sfsx=1 or a.sfsx is null) and a.sxrq is null and a.jarq is not null and jarq>to_date(''2015-11-1'',''yyyy-mm-dd'') and  a.kplb<>4 and a.kplb<>22 ';
end if;


 open rt for v_sql || v_where;

end p_cb_csx_count;
/

