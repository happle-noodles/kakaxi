create PROCEDURE P_TJFX_SLQKTJ(jnsjqj varchar2,qnsjqj varchar2, rt out pkg_row.myRow) as
/*月结案情况 杨元胜
nscfy 查询法院
qsrq 月起始日期
jsrq 月结束日期
ndqsrq 年度起始日期
ndjsrq 年度结束日期
rt   返回数据集
*/
n_js number;
n_sz number;
v_avg varchar2(500);
v_bzc varchar2(500);
BEGIN
 INSERT INTO B_TEMPSL(DM,XSJB,MC,XSSX)SELECT 4166,1,'全兵团系统',-104 from dual;
 INSERT INTO B_TEMPSL(DM,XSJB,MC,fyjb,XSSX)SELECT 4166,5,'兵团分院',3,-103 from dual;
 INSERT INTO B_TEMPSL(DM,XSJB,MC,XSSX)SELECT 4166,2,'兵团中级人民法院',-102 from dual;
 INSERT INTO B_TEMPSL(DM,XSJB,MC,XSSX)SELECT 4166,3,'兵团基层人民法院',-101 from dual;
 insert INTO B_TEMPSL(DM,XSJB,MC,XSSX)SELECT DM,4,FYJC,XSSX-60 FROM B_FY where sjdm=4166 ORDER BY XSSX;
 insert INTO B_TEMPSL(DM,XSJB,MC,SJDM,FYJB,XSSX)SELECT DM,5,FYJC,SJDM,FYJB,XSSX FROM B_FY where  DM BETWEEN 4167 AND 4208;
 UPDATE B_TEMPSL SET SJDM=DM WHERE FYJB=2;

--今年改判率
execute immediate 'merge into B_TEMPSL  A
    using(select sum(gps) as fz,sum(yjs) as fm ,cjfy from b_tjhz where kplb in(2,3,8,9,14,15) and sjqj like '''||jnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jngpl=round(100*fz/fm,2) where fm>0;
  --  update B_TEMPSL a set fz=0,fm=0;

 --去年改判率
execute immediate 'merge into B_TEMPSL  A
    using(select sum(gps) as fz,sum(yjs) as fm ,cjfy from b_tjhz where kplb in(2,3,8,9,14,15) and sjqj like '''||qnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qngpl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
 --改判率同比
    update  B_TEMPSL set gpltb=jngpl-qngpl;
 --今年发回重审率
  
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(fhcss) as fz,sum(yjs) as fm ,cjfy from b_tjhz where kplb in(2,3,8,9,14,15) and sjqj like '''||jnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jnfhcsl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
 --去年发回重审率
execute immediate 'merge into B_TEMPSL  A
    using(select sum(fhcss) as fz,sum(yjs) as fm ,cjfy from b_tjhz where kplb in(2,3,8,9,14,15) and sjqj like '''||qnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qnfhcsl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
 --发回重审率同比
    update  B_TEMPSL set fhcsltb=jnfhcsl-qnfhcsl;

     --今年再审率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(zss) as fz,sum(yjs) as fm ,cjfy from b_tjhz where kplb in(23,24,25) and sjqj like '''||jnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jnzsl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
 --去年发再审率
execute immediate 'merge into B_TEMPSL  A
    using(select sum(zss) as fz,sum(yjs) as fm ,cjfy from b_tjhz where kplb in(23,24,25) and sjqj like '''||qnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qnzsl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
 --再审率同比
    update  B_TEMPSL set zsltb=jnzsl-qnzsl;
      
     --今年结案率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(yjs) as fz,sum(yjs+wjs) as fm ,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jnjal=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
 --去年结案率
 
execute immediate 'merge into B_TEMPSL  A
    using(select sum(yjs) as fz,sum(wjs+yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qnjal=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
 --结案率同比
    update  B_TEMPSL set jaltb=jnjal-qnjal;

    --今年一审服判息诉率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(SSXSS) as fz,sum(yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb in(1,7,13) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jnysfpxsl=100-round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
 --去年一审服判息诉率
 
execute immediate 'merge into B_TEMPSL  A
    using(select sum(SSXSS) as fz,sum(yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' and kplb in(1,7,13) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qnysfpxsl=100-round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
 --一审服判息诉率同比
    update  B_TEMPSL set ysfpxsltb=jnysfpxsl-qnysfpxsl;
         
    --今年调解率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(tjs) as fz,sum(yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb in(1,2,3,7,8,9,12,13,14,15) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jntjl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
 --去年调解率
 
execute immediate 'merge into B_TEMPSL  A
    using(select sum(tjs) as fz,sum(yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%''and kplb in(1,2,3,7,8,9,12,13,14,15)  group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qntjl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
   --调解率率同比
    update  B_TEMPSL set tjltb=jntjl-qntjl;

   --今年撤诉率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(css) as fz,sum(yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb in(1,2,3,7,8,9,12,13,14,15,21) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jncsl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;

 --去年撤诉率
      
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(css) as fz,sum(yjs) as fm ,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%''and kplb in(1,2,3,7,8,9,12,13,14,15,21)  group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ,A.FM=B.FM';
    
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    
    update b_tempsl a set qncsl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
   --撤诉率同比
  
    update  B_TEMPSL set csltb=jncsl-qncsl;

    --今年裁判自动履行率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(sqzxajs) as fz,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb=16 group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ';
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(yjs) as fm,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb in(1,2,3,7,8,9,13,14,15,12,21) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jncpzdlxl=100-round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
    
     --去年裁判自动履行率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(sqzxajs) as fz,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' and kplb=16 group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ';
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(yjs) as fm,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' and kplb in(1,2,3,7,8,9,13,14,15,12,21) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FM=B.FM';
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qncpzdlxl=100-round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
    update B_TEMPSL set cpzdlxltb=jncpzdlxl-qncpzdlxl; 
 
     --今年再审审查率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(zsscs) as fz,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb in(23,24,25) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ';
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(yjs) as fm,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb in(1,2,7,8,13,14) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FM=B.FM';
    
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set jnzsscl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;
 --去年再审审查率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(zsscs) as fz,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' and kplb in(23,24,25) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FZ=B.FZ';
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(yjs) as fm,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' and kplb in(1,2,7,8,13,14) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set A.FM=B.FM';
    
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where sjdm=a.dm or dm=a.dm),FM=(select sum(FM) from B_TEMPSL where sjdm=a.dm or dm=a.dm) where XSJB=4;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=1),FM=(select sum(FM) from B_TEMPSL where FYJB=1) where XSJB=3;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL where FYJB=2),FM=(select sum(FM) from B_TEMPSL where FYJB=2) where XSJB=2;
    update B_TEMPSL a set fz=(select sum(fz) from B_TEMPSL WHERE FYJB>0),FM=(select sum(FM) from B_TEMPSL where FYJB>0) where XSJB=1;  
    update b_tempsl a set qnzsscl=round(100*fz/fm,2) where fm>0;
    update B_TEMPSL a set fz=0,fm=0;  
   --再审审查率同比
    update  B_TEMPSL set zsscltb=jnzsscl-qnzsscl;

 
   --今年结案均衡度率
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(jan)as Y1,sum(feb) as Y2,sum(mar)as Y3,sum(apr)as Y4,sum(may) as Y5,sum(jun) as Y6,sum(jul)as Y7,sum(aug)as Y8,sum(sep)as Y9,sum(oct)as Y10,sum(nov)as Y11,sum(DEC)as Y12,cjfy from b_tjhz where  sjqj like '''||jnsjqj||'%'' and kplb not in(4) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12';
 
    merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12,SJDM 
    FROM B_TEMPSL WHERE XSJB=5 AND DM<>4166  GROUP BY SJDM ) B  ON(A.DM=B.SJDM AND A.XSJB=4)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    
     merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12 
    FROM B_TEMPSL WHERE XSJB=5 AND FYJB=2) B  ON(A.XSJB=2)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    
     merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12 
    FROM B_TEMPSL WHERE XSJB=5 AND FYJB=1) B  ON(A.XSJB=3)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    
    merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12 
    FROM B_TEMPSL WHERE XSJB=5 AND XSJB=5) B  ON(A.XSJB=1)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    n_js:=0;
    v_avg:='0';
    v_bzc:='0';
    select y1 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y1';
        v_bzc:=v_bzc||'+power(y1-fm,2)';
    end if;
    select y2 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y2';
        v_bzc:=v_bzc||'+power(y2-fm,2)';
    end if;
    select y3 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y3';
        v_bzc:=v_bzc||'+power(y3-fm,2)';
    end if;
    select y4 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y4';
        v_bzc:=v_bzc||'+power(y4-fm,2)';
    end if;
    select y5 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y5';
        v_bzc:=v_bzc||'+power(y5-fm,2)';
    end if; 
    select y6 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y6';
        v_bzc:=v_bzc||'+power(y6-fm,2)';
    end if; 
    select y7 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y7';
        v_bzc:=v_bzc||'+power(y7-fm,2)';
    end if; 
    select y8 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y8';
        v_bzc:=v_bzc||'+power(y8-fm,2)';
    end if;
    select y9 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y9';
        v_bzc:=v_bzc||'+power(y9-fm,2)';
    end if; select y10 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y10';
        v_bzc:=v_bzc||'+power(y10-fm,2)';
    end if; 
    select y11 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y11';
        v_bzc:=v_bzc||'+power(y11-fm,2)';
    end if;  
    select y12 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y12';
        v_bzc:=v_bzc||'+power(y12-fm,2)';
    end if;   

   EXECUTE IMMEDIATE ' update B_TEMPSL set FM=('|| v_avg || ')/'||n_js||' WHERE '||n_js||'>0';
   EXECUTE IMMEDIATE ' update B_TEMPSL set FZ=sqrt(('|| v_bzc || ')/'||n_js||') WHERE '||n_js||'>0';
   update  B_TEMPSL set jnjajhd=round(100-fz*100/fm,2) where fm>0;
   update B_TEMPSL a set fz=0,fm=0;  
   
   --去年结案均衡度
    execute immediate 'merge into B_TEMPSL  A
    using(select sum(jan)as Y1,sum(feb) as Y2,sum(mar)as Y3,sum(apr)as Y4,sum(may) as Y5,sum(jun) as Y6,sum(jul)as Y7,sum(aug)as Y8,sum(sep)as Y9,sum(oct)as Y10,sum(nov)as Y11,sum(DEC)as Y12,cjfy from b_tjhz where  sjqj like '''||qnsjqj||'%'' and kplb not in(4) group by cjfy) B
    on (A.DM=B.CJFY AND A.XSJB=5 ) when matched then
    update set a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12';
 
    merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12,SJDM 
    FROM B_TEMPSL WHERE XSJB=5 AND DM<>4166  GROUP BY SJDM ) B  ON(A.DM=B.SJDM AND A.XSJB=4)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    
     merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12 
    FROM B_TEMPSL WHERE XSJB=5 AND FYJB=2) B  ON(A.XSJB=2)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    
     merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12 
    FROM B_TEMPSL WHERE XSJB=5 AND FYJB=1) B  ON(A.XSJB=3)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    
    merge into B_TEMPSL A 
    USING(select sum(Y1) as Y1,sum(Y2) as Y2,sum(Y3) as Y3,sum(Y4) as Y4,sum(Y5) as Y5,sum(Y6) as Y6,sum(Y7) as Y7,sum(Y8) as Y8,sum(Y9) as Y9,sum(Y10) as Y10,sum(Y11) as Y11,sum(Y12) as Y12 
    FROM B_TEMPSL WHERE XSJB=5 AND XSJB=5) B  ON(A.XSJB=1)  
    when matched then update SET a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12;
    n_js:=0;
    v_avg:='0';
    v_bzc:='0';
    select y1 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y1';
        v_bzc:=v_bzc||'+power(y1-fm,2)';
    end if;
    select y2 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y2';
        v_bzc:=v_bzc||'+power(y2-fm,2)';
    end if;
    select y3 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y3';
        v_bzc:=v_bzc||'+power(y3-fm,2)';
    end if;
    select y4 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y4';
        v_bzc:=v_bzc||'+power(y4-fm,2)';
    end if;
    select y5 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y5';
        v_bzc:=v_bzc||'+power(y5-fm,2)';
    end if; 
    select y6 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y6';
        v_bzc:=v_bzc||'+power(y6-fm,2)';
    end if; 
    select y7 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y7';
        v_bzc:=v_bzc||'+power(y7-fm,2)';
    end if; 
    select y8 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y8';
        v_bzc:=v_bzc||'+power(y8-fm,2)';
    end if;
    select y9 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y9';
        v_bzc:=v_bzc||'+power(y9-fm,2)';
    end if; select y10 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y10';
        v_bzc:=v_bzc||'+power(y10-fm,2)';
    end if; 
    select y11 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y11';
        v_bzc:=v_bzc||'+power(y11-fm,2)';
    end if;  
    select y12 into n_sz from B_TEMPSL where xsjb=1;
    if  n_sz>0 then
        n_js:=n_js+1;
        v_avg:=v_avg||'+y12';
        v_bzc:=v_bzc||'+power(y12-fm,2)';
    end if;   

   EXECUTE IMMEDIATE ' update B_TEMPSL set FM=('|| v_avg || ')/'||n_js||' WHERE '||n_js||'>0';
   EXECUTE IMMEDIATE ' update B_TEMPSL set FZ=sqrt(('|| v_bzc || ')/'||n_js||') WHERE '||n_js||'>0';
   update  B_TEMPSL set qnjajhd=round(100-fz*100/fm,2) where fm>0;
   update B_TEMPSL a set fz=0,fm=0;  
   
   update B_TEMPSL set jajhdtb=jnjajhd-qnjajhd;
   

  open rt for select * from B_TEMPSL ORDER BY XSSX;
  end P_TJFX_SLQKTJ;
/

