create procedure                   UPDATEAJJZ(nAjbs in number:=16,nScfy in number:=3) as
/*计算被告人的犯罪金额之和 存入案件辅助表*/
Begin
   UPDATE  B_AJFZXX SET AJJZ= (SELECT SUM(FZJE) FROM B_XSBGR WHERE AJBS=nAjbs AND SCFY=nScfy) WHERE AJBS=nAjbs;
End UPDATEAJJZ;

/

