create procedure P_ZXPG_GJDZJJXKH(qsrq VARCHAR2,jsrq VARCHAR2,sjqj VARCHAR2)
AS
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
cursor c_zxpgsm is select zbbs,zbfx,zbqs from b_btfyzxpgsm where mkmc like 'GJDZJJXKH%' and xssx>-1;
n_zbbs number;
zbfx number;
zbqs number;
v_fz varchar2(500);
v_fz1 varchar2(500);
v_fz2 varchar2(500);
v_fm varchar2(500);
v_sjfwz varchar2(100);
v_where varchar2(200);
v_sql varchar2(500);
n_zyz number;
n_zcz number;
n_js number;--结案均衡计数
n_sz number;--数值
v_avg varchar2(500);--平均值
v_bzc varchar2(500);--标准差
v_sjqj1 varchar(30);
v_sjqj2 varchar(30);
v_sjqj3 varchar(30);
begin

   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_kplb  from b_tjfxgs where gsmc='卡片类别';

   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_sjfwz:=sjqj||'#'||qsrq||'#'||jsrq;

   v_sjqj1:= substr(sjqj,1,2) ||to_char(to_number(substr(sjqj,3,4))-1)||substr(sjqj,7);
   v_sjqj2:= substr(sjqj,1,2) ||to_char(to_number(substr(sjqj,3,4))-2)||substr(sjqj,7);
   v_sjqj3:= substr(sjqj,1,2) ||to_char(to_number(substr(sjqj,3,4))-3)||substr(sjqj,7);

for v_zbxx in c_zxpgsm loop
        n_zbbs:=v_zbxx.zbbs;
        zbfx:=v_zbxx.zbfx;
        zbqs:=v_zbxx.zbqs;
      --分子
       case n_zbbs
       --一审判决案件改判发回重审率
       when 1478 then
            v_fz:= v_yjtj|| ' and  kplb in(2,8,14) and jafs=2 and nvl(gpyy,0)<>5' ;
            v_fz1:= v_yjtj|| ' and  kplb in(2,8,14) and jafs=3 and ((kplb=2 and nvl(fhcsyy,0)<>7) or (kplb in(8,14) and nvl(fhcsyy,0)<>8))'  ;
        --生效案件改判发回重审率
        when 1479 then
             v_fz:= v_yjtj|| ' and  kplb in(3,9,15) and jafs=2 and nvl(gpyy,0)<>5' ;
             v_fz1:= v_yjtj|| 'and  kplb in(3,9,15) and jafs=3 and ((kplb=3 and nvl(fhcsyy,0)<>7) or (kplb in(9,15) and nvl(fhcsyy,0)<>8))' ;
        --司法赔偿案件
        when 1480 then
             v_fz:= v_yjtj|| ' and KPLB = 17 and jafs=101' ; --全兵团系统没有
        --法官因审判执行案件被追究刑事责任
        when 1482 then
             v_fz:='1=2';
        --法院年人均结案数
        when 1483 then
             v_fz:= v_yjtj|| ' and  (KPLB<19 OR (KPLB>19 AND KPLB<30)  or KPLB>33) and kplb<>4' ;
             v_fz1:= v_yjtj|| 'and  kplb=4 and nvl(sfktsl,1)=1';
             v_fz2:= v_yjtj|| 'and  kplb=4 and nvl(sfktsl,1)=2';
        --审结率
        when 1484 then
             v_fz:= v_yjtj|| ' and kplb<>4  and (KPLB<19 OR (KPLB>19 AND KPLB<30) or KPLB>33)' ;
         --法定期限内结案率
        when 1485 then
             v_fz:= v_yjtj|| ' and kplb<>4 and ((nvl(YCTS,0)<=0 and nvl(CSXTS,0)<=0) or kplb=12 or kplb=22)  and (KPLB<19 OR (KPLB>19 AND KPLB<30))' ;
          --平均审理时间指数
         when 1486 then
            v_fz:= v_yjtj|| ' and KPLB IN(1,2,3,7,8,9,13,14,15,18) and nvl(sjslts,0)>0 and fdsxts>0';
          --结案均衡度
         when 1487 then
           v_fz :='1=2';
          --一审服判息诉率
          when 1488 then
           v_fz :=v_xstj|| ' and  kplb in(2,8,14)' ;
           --调解率(民事一二再审)
          when 1489 then
           v_fz :=v_yjtj|| ' and ((kplb=7 and jafs=7) or (kplb in(8,9) and jafs=9))' ;
           --撤诉率
          when 1490 then
           v_fz :=v_yjtj|| ' and ((KPLB=1 AND JAFS in(4,5,9))or (KPLB=2 AND JAFS in(5,6,112,107,108,109,110)) or (KPLB=3 AND JAFS in(5,6,107,108,109,110,113,116,117)) OR (KPLB in(7,13) AND JAFS in(4,5)) OR (KPLB =8 AND JAFS in(6,7,110)) OR (KPLB =9 AND JAFS in(6,7,106)) OR (KPLB in (14,15) AND JAFS in(6,7)))' ;
           --裁判案件自动履行率
          when 1493 then
           v_fz :='1=2';
           --调解案件申请执行率
          when 1494 then
           v_fz :=v_xstj|| ' and  kplb=16 and  AJLB=1  AND AH NOT LIKE ''%执协%''  AND AH NOT LIKE ''%执监%''  AND AH NOT LIKE ''%执异%''  AND AH NOT LIKE ''%执复%''  AND AH NOT LIKE ''%执请%'' AND AH NOT LIKE ''%执保%''' ;
            --再审审查率
          when 1499 then
           v_fz :='1=2';
           --涉诉信访
           when 1501 then
           v_fz :='1=2';
          --司法建议
          when 1502 then
           v_fz :=v_yjtj|| ' and  ajbs in(select ajbs from b_sfjy)';
        --信息录入错误率
          when 1503 then
           v_fz :='1=2';
        else
         v_fz:='out';
       end case;

       --分母
       case n_zbbs
       --一审判决案件改判发回重审率
        when 1478 then
             v_fm:= v_yjtj|| ' and  kplb in(1,13,7) and jafs=1' ;
        --生效案件改判发回重审率
        when 1479 then
             v_fm:= v_yjtj|| ' and  kplb in(1,13,7,2,8,14)';
         --司法赔偿案件
        when 1480 then
             v_fm:= v_yjtj|| ' AND 1=2' ;
         --法官因审判执行案件被追究刑事责任
        when 1482 then
             v_fm:='1=2';
         --法院年人均结案数
        when 1483 then
             v_fm:='1=2';
        --审结率
        when 1484 then
           v_fm:= '('||v_yjtj|| ' or  '||v_wjtj ||')and (KPLB<19 OR (KPLB>19 AND KPLB<30) or KPLB>33) and kplb<>4';
          --法定期限内结案率
        when 1485 then
           v_fm:= v_yjtj|| ' and kplb<>4  and (KPLB<19 OR (KPLB>19 AND KPLB<30))' ;
           --平均审理时间指数
        when 1486 then
            v_fm:= v_yjtj|| ' and KPLB IN(1,2,3,7,8,9,13,14,15,18) and nvl(sjslts,0)>0 and fdsxts>0';
           --结案均衡度
        when 1487 then
           v_fm:='1=2';
          --一审服判息诉率
        when 1488 then
            v_fm:= v_yjtj|| ' and  kplb in(1,13,7)';
          --调解率(民事一二再审)
        when 1489 then
            v_fm:= v_yjtj|| ' and  kplb in(7,8,9)';
          --撤诉率
        when 1490 then
           v_fm:= v_yjtj|| ' and kplb in(1,2,3,7,8,9,13,14,15)';
          --裁判案件自动履行率
        when 1493 then
           v_fm :='1=2';
        --调解案件申请执行率
        when 1494 then
           v_fm :=v_yjtj|| ' and ((kplb=7 and jafs=7) or (kplb in(8,9) and jafs=9))' ;
         --再审审查率
        when 1499 then
           v_fm :='1=2';
         --涉诉信访
        when 1501 then
           v_fm :='1=2';
        --司法建议
        when 1502 then
           v_fm :='1=2';
    --信息录入错误率
        when 1503 then
           v_fm :='1=2';
        else
        v_fm:='out';
       end case;

       v_where:= 'ZBBS='||n_zbbs||' AND SJFWZ LIKE '''||sjqj||'%''';
       EXECUTE IMMEDIATE ('DELETE B_BTFYZXPGXX WHERE '||v_where);
       dbms_output.put_line(n_zbbs);
       if n_zbbs in(1475,1476,1477)
         then
             EXECUTE IMMEDIATE (' insert into B_BTFYZXPGXX(QYFWZ,SJFWZ,ZBBS) select dm,'''||v_sjfwz||''','||n_zbbs||' from  b_fy where fyjb=2 and dm between 4166 and 4208');
        end if;
       if v_fz='out' or v_fm='out'
         then
          -- dbms_output.put_line('tiaochu');
           continue;
         end if;
          --dbms_output.put_line(v_where);
        EXECUTE IMMEDIATE (' insert into B_BTFYZXPGXX(QYFWZ,SJFWZ,ZBBS) select dm,'''||v_sjfwz||''','||n_zbbs||' from  b_fy where fyjb=2 and dm between 4166 and 4208');

        -- 审判决案件改判发回重审率 生效案件改判发回重审率,
        IF n_zbbs IN(1478,1479)
        THEN

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*)AS FM,SCFY FROM B_AJZTXX WHERE '||v_fm||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fm=a.fm');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*) AS FZ,SCFY FROM (select (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) as SCFY from B_AJZTXX WHERE '||v_fz||') C GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz*0.4');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*) AS FZ,SCFY FROM (select (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) as SCFY from B_AJZTXX WHERE '||v_fz1||') C GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz= m.fz+a.fz*0.6');
      ELSIF n_zbbs IN(1494) --调解案件申请执行率
             THEN
              EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (select count(*)as fz,scfy from ( select (select jbfy from b_ysqk where b_ysqk.ajbs=b_ajztxx.ajbs and rownum=1) AS scfy
                    from b_ajztxx where '||v_fz||' and exists (select ajbs from b_ysqk where b_ysqk.ajbs=b_ajztxx.ajbs and rownum=1
                      and exists (select ajbs from b_ajztxx where ah=b_ysqk.ah and jarq is not null and ((KPLB in(7,13) AND JAFS=7) OR (KPLB in(8,9,14,15) and JAFS=9) OR(KPLB in(12) AND JAFS=6)))))b  group by scfy) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*)AS FM,SCFY FROM B_AJZTXX WHERE '||v_fm||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fm=a.fm');
     ELSIF n_zbbs IN(1480) --司法赔偿率
        THEN
              EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*) AS FZ,SCFY FROM (select (select (select dm from b_fy where fymc=b.mc) as dm from b_pcywjg a,b_yastml b where a.ajbs=b.ajbs and a.pcywjg=b.xh and a.ajbs=b_ajztxx.ajbs and ROWNUM=1 )  as SCFY from B_AJZTXX WHERE '||v_fz||') C GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');

    --一审服判息诉率
        ELSIF n_zbbs IN(1488)
        THEN
                EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*) AS FZ,SCFY FROM (select (SELECT JBFY  FROM B_YSQK WHERE B_AJZTXX.AJBS=B_YSQK.AJBS AND ROWNUM=1) as SCFY from B_AJZTXX WHERE '||v_fz||') C GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*)AS FM,SCFY FROM B_AJZTXX WHERE '||v_fm||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fm=a.fm');
        elsif n_zbbs IN(1482,1501,1503)    --涉诉信访/法官因审判执行案件被追究刑事责任/信息录入正确率
          then
            EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (select ZXPGJG AS FZ,CJFY FROM B_ZXPGINFO WHERE '|| v_where ||') A
             on(M.QYFWZ=A.CJFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');
       --法院年人均结案数
        ELSIF n_zbbs IN(1483)
        THEN
             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (SELECT COUNT(*)AS FZ,SCFY FROM B_AJZTXX WHERE '||v_fz||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*)AS FZ,SCFY FROM B_AJZTXX WHERE '||v_fz1||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz= m.fz+a.fz/5');


             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT COUNT(*)AS FZ,SCFY FROM B_AJZTXX WHERE '||v_fz2||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz= m.fz+a.fz/20');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
             using (SELECT DM,XZZBRS AS FM FROM B_FY WHERE DM BETWEEN 4166 AND 4208) A
             on(M.QYFWZ=A.DM AND '||v_where ||')
             WHEN matched then update set  m.fm= a.fm');
          --平均审理时间指数
         elsif n_zbbs=1486
         then
             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (SELECT sum((CASE WHEN sjslts/fdsxts >= 0 AND sjslts/fdsxts < 0.5 THEN 0.9  WHEN sjslts/fdsxts >= 0.5 AND sjslts/fdsxts < (0.667) THEN 0.8   WHEN sjslts/fdsxts >= 0.667  AND sjslts/fdsxts < 1 THEN 0.6  WHEN sjslts/fdsxts >= 1 AND sjslts/fdsxts < 1.5 THEN 0.3 WHEN sjslts/fdsxts >= 1.5 THEN 0 ELSE 0.6 END))AS FZ,SCFY FROM B_AJZTXX WHERE '||v_fz||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (SELECT COUNT(*)AS fm,SCFY FROM B_AJZTXX WHERE '||v_fm||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fm= a.fm');
         --结案均衡度
         elsif n_zbbs=1487
         then
              EXECUTE IMMEDIATE (' insert into B_TEMPSL(DM) select dm from  b_fy where fyjb=2 and dm between 4166 and 4208');
              execute immediate 'merge into B_TEMPSL  A
              using(select sum(jan)as Y1,sum(feb) as Y2,sum(mar)as Y3,sum(apr)as Y4,sum(may) as Y5,sum(jun) as Y6,sum(jul)as Y7,sum(aug)as Y8,sum(sep)as Y9,sum(oct)as Y10,sum(nov)as Y11,sum(DEC)as Y12,cjfy from b_tjhz where  sjqj like '''||sjqj||'%'' and kplb not in(4) group by cjfy) B
              on (A.DM=B.CJFY ) when matched then
               update set a.Y1=b.Y1,a.Y2=b.Y2,a.Y3=b.Y3,a.Y4=b.Y4,a.Y5=b.Y5,a.Y6=b.Y6,a.Y7=b.Y7,a.Y8=b.Y8,a.Y9=b.Y9,a.Y10=b.Y10,a.Y11=b.Y11,a.Y12=b.Y12';
              n_js:=0;
              v_avg:='0';
              v_bzc:='0';
              select sum(y1) into n_sz from B_TEMPSL;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y1';
                  v_bzc:=v_bzc||'+power(y1-fm,2)';
              end if;
              select sum(y2) into n_sz from B_TEMPSL;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y2';
                  v_bzc:=v_bzc||'+power(y2-fm,2)';
              end if;
              select sum(y3) into n_sz from B_TEMPSL ;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y3';
                  v_bzc:=v_bzc||'+power(y3-fm,2)';
              end if;
              select sum(y4) into n_sz from B_TEMPSL ;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y4';
                  v_bzc:=v_bzc||'+power(y4-fm,2)';
              end if;
              select sum(y5) into n_sz from B_TEMPSL ;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y5';
                  v_bzc:=v_bzc||'+power(y5-fm,2)';
              end if;
              select sum(y6) into n_sz from B_TEMPSL ;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y6';
                  v_bzc:=v_bzc||'+power(y6-fm,2)';
              end if;
              select sum(y7) into n_sz from B_TEMPSL;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y7';
                  v_bzc:=v_bzc||'+power(y7-fm,2)';
              end if;
              select sum(y8) into n_sz from B_TEMPSL ;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y8';
                  v_bzc:=v_bzc||'+power(y8-fm,2)';
              end if;
              select sum(y9) into n_sz from B_TEMPSL ;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y9';
                  v_bzc:=v_bzc||'+power(y9-fm,2)';
              end if;
              select sum(y10) into n_sz from B_TEMPSL;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y10';
                  v_bzc:=v_bzc||'+power(y10-fm,2)';
              end if;
              select sum(y11) into n_sz from B_TEMPSL;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y11';
                  v_bzc:=v_bzc||'+power(y11-fm,2)';
              end if;
              select sum(y12) into n_sz from B_TEMPSL;
              if  n_sz>0 then
                  n_js:=n_js+1;
                  v_avg:=v_avg||'+y12';
                  v_bzc:=v_bzc||'+power(y12-fm,2)';
              end if;
              EXECUTE IMMEDIATE ' update B_TEMPSL set FM=('|| v_avg || ')/'||n_js||' WHERE '||n_js||'>0';
              EXECUTE IMMEDIATE ' update B_TEMPSL set FZ=sqrt(('|| v_bzc || ')/'||n_js||') WHERE '||n_js||'>0';

              EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (SELECT FZ,FM,DM FROM B_TEMPSL) A
              on(M.QYFWZ=A.DM AND '||v_where ||')
              WHEN matched then update set  M.FZ=A.FZ,m.fm= a.fm');
         elsif n_zbbs=1493 --裁判自动履行率
          then
                execute immediate 'merge into B_BTFYZXPGXX  M
                using(select sum(sqzxajs) as fz,cjfy from b_tjhz where  sjqj like '''||sjqj||'%'' and kplb=16 group by cjfy) A
                on (A.cjfy=M.QYFWZ and zbbs=1493) when matched then
                update set M.FZ=A.FZ';
                execute immediate 'merge into B_BTFYZXPGXX  M
                using(select sum(yjs) as fm,cjfy from b_tjhz where  sjqj like '''||sjqj||'%'' and kplb in(1,2,3,7,8,9,13,14,15,12,21) group by cjfy) A
                on (A.cjfy=M.QYFWZ  and zbbs=1493) when matched then
                update set M.FM=A.FM';
         elsif n_zbbs=1499 --再审审查率
          then
                execute immediate 'merge into B_BTFYZXPGXX  M
                using(select sum(zsscs) as fz,cjfy from b_tjhz where  sjqj like '''||sjqj||'%'' and kplb in(23,24,25) group by cjfy) A
                on (A.cjfy=M.QYFWZ  and zbbs=1499) when matched then
                update set M.FZ=A.FZ';
                execute immediate 'merge into B_BTFYZXPGXX  M
                using(select sum(yjs) as fm,cjfy from b_tjhz where  sjqj like '''||sjqj||'%'' and kplb in(1,2,7,8,13,14) group by cjfy) A
                on (A.cjfy=M.QYFWZ and zbbs=1499) when matched then
                update set M.FM=A.FM';

          --审结率/法定期限内结案率
         ELSE
             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (SELECT COUNT(*)AS FZ,SCFY FROM B_AJZTXX WHERE '||v_fz||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fz=a.fz');

             EXECUTE IMMEDIATE ('merge into B_BTFYZXPGXX  M
              using (SELECT COUNT(*)AS fm,SCFY FROM B_AJZTXX WHERE '||v_fm||' GROUP BY SCFY) A
             on(M.QYFWZ=A.SCFY AND '||v_where ||')
             WHEN matched then update set  m.fm= a.fm');
        end if;

        if n_zbbs IN(1478,1479,1483,1484,1485,1486,1487,1488,1493,1494,1499,1501,1503)
        THEN
             IF n_zbbs=1483
              then
                   EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=round(fz/fm,2) where fm>0 and '|| v_where);
              ELSIF n_zbbs in(1487,1488,1493)
                then
                   EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=round(100-fz*100/fm,2) where fm>0 and '|| v_where);
              ELSIF n_zbbs in(1501,1502,1503)
                then
                   EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=nvl(fz,0) where  '|| v_where);
              else
                   EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=round(fz*100/fm,2) where fm>0 and '|| v_where);
              end if;
              if zbfx=1
                 then
                    v_sql:= 'select max(zbl)  from B_BTFYZXPGXX where '||v_where;
                   EXECUTE IMMEDIATE v_sql into n_zyz;
                    v_sql:= 'select min(zbl)  from B_BTFYZXPGXX where '||v_where;
                   EXECUTE IMMEDIATE v_sql into n_zcz;
              else
                   v_sql:= 'select max(zbl)  from B_BTFYZXPGXX where '||v_where;
                   EXECUTE IMMEDIATE v_sql into n_zcz;
                    v_sql:= 'select min(zbl)  from B_BTFYZXPGXX where '||v_where;
                   EXECUTE IMMEDIATE v_sql into n_zyz;
              end if;
              if n_zyz=n_zcz
                then
                  if zbfx=1
                      then
                       EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbdf=zbl*'||zbqs||'/100 where zbl is not null and '|| v_where);
                  else
                    dbms_output.put_line('update B_BTFYZXPGXX set zbdf=(100-zbl)*'||zbqs||'/100 where zbl is not null and '|| v_where);
                       EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbdf=(100-zbl)*'||zbqs||'/100 where zbl is not null and '|| v_where);
                  end if;
              else
                   if zbfx=1
                      then
                       EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbdf=zbl/'||n_zyz||'*'||zbqs||' where zbl is not null and '|| v_where);
                  else
                       EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbdf=(100-zbl)/(100-'||n_zyz||')*'||zbqs||' where zbl is not null and '|| v_where);
                  end if;
              end if;
            if n_zbbs=1494
              then
                  EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbdf=0 where  zbl is not null and zbl>10 and  '|| v_where);
              end if;
        ELSIF n_zbbs IN(1480,1482) --司法赔偿,法官因审判执行案件被追究刑事责任
          THEN
             EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set FZ=0 where FZ IS NULL AND  '|| v_where);
             EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=fz where '|| v_where);
             EXECUTE IMMEDIATE (' UPDATE B_BTFYZXPGXX SET zbdf = (CASE WHEN zbl <= 0 THEN '||zbqs||' ELSE 0 END)  WHERE zbl IS NOT NULL and '|| v_where);
        ELSIF n_zbbs IN(1502) --司法协助
          THEN
             EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set FZ=0 where FZ IS NULL AND  '|| v_where);
             EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=fz where '|| v_where);
             EXECUTE IMMEDIATE ('UPDATE B_BTFYZXPGXX SET zbdf = (CASE WHEN zbl > 0 THEN '||zbqs||' ELSE 0 END)  WHERE zbl IS NOT NULL and '|| v_where);
        ELSIF n_zbbs IN(1489,1490) --调解率、撤诉率
          THEN
            EXECUTE IMMEDIATE ('update B_BTFYZXPGXX set zbl=round(fz*100/fm,2) where fm>0 and '|| v_where);
            EXECUTE IMMEDIATE ('UPDATE B_BTFYZXPGXX a SET PJS=(select nvl(avg(zbl),0) from b_btfyzxpgxx where zbbs='||n_zbbs||' and a.qyfwz=qyfwz and (sjfwz like '''||v_sjqj1||'%'' or sjfwz like '''||v_sjqj2||'%'' or sjfwz like '''||v_sjqj3||'%'')) where ' || v_where);
            if n_zbbs =1489
              then
                 dbms_output.put_line(' UPDATE B_BTFYZXPGXX SET ZBDF=ROUND((CASE WHEN 3+ROUND((zbl-PJS),0)*0.2<0 THEN 0 WHEN 3+ROUND((zbl-PJZ),0)*0.2>'||zbqs||' THEN '||zbqs||' ELSE 3+ROUND((zbl-PJZ),0)*0.2 END),2) and '|| v_where);
                 EXECUTE IMMEDIATE (' UPDATE B_BTFYZXPGXX SET ZBDF=ROUND((CASE WHEN 3+ROUND((zbl-PJS),0)*0.2<0 THEN 0 WHEN 3+ROUND((zbl-PJS),0)*0.2>'||zbqs||' THEN '||zbqs||' ELSE 3+ROUND((zbl-PJS),0)*0.2 END),2) where '|| v_where);
             ELSE
                 EXECUTE IMMEDIATE (' UPDATE B_BTFYZXPGXX SET ZBDF=ROUND((CASE WHEN 3+ROUND((zbl-PJS),0)*0.2<1 THEN 1 WHEN 3+ROUND((zbl-PJS),0)*0.2>'||zbqs||' THEN '||zbqs||' ELSE 3+ROUND((zbl-PJS),0)*0.2 END),2)  where '|| v_where);
             end if;

        END IF;

        if n_zbbs IN(1478,1479)
          THEN
             EXECUTE IMMEDIATE ('UPDATE B_BTFYZXPGXX SET  ZBDF = (SELECT ROUND(SUM(ZBDF) / COUNT(ZBDF),2) FROM  B_BTFYZXPGXX WHERE  ZBDF IS NOT NULL AND '|| v_where ||' ) WHERE  ZBDF IS NULL AND '||v_where);
          END IF;


        EXECUTE IMMEDIATE ('update B_BTFYZXPGXX SET ZXPGJG=TO_CHAR(ROUND(ZBL,2),''fm9999990.0099'')||''#''||TO_CHAR(ROUND(ZBDF,2),''fm9999990.0099'') WHERE '||v_where);

       dbms_output.put_line(v_fz);
       dbms_output.put_line(v_fm);
       v_fz:='';
       v_fm:='';
       v_fz1:='';
       v_fz2:='';
       v_sql:='';
       v_where :='';
end loop;
    EXECUTE IMMEDIATE (' update B_BTFYZXPGXX a set ZXPGJG=(select sum(round(zbdf,2)) from B_BTFYZXPGXX where  a.qyfwz=qyfwz and sjfwz like '''|| sjqj || '%'' AND ZBBS IN(SELECT ZBBS FROM B_BTFYZXPGSM WHERE XSSX>0 AND MKMC=''GJDZJJXKHJZL'')) WHERE ZBBS=1475 AND SJFWZ LIKE '''||sjqj||'%''' );
    EXECUTE IMMEDIATE (' update B_BTFYZXPGXX a set ZXPGJG=(select sum(round(zbdf,2)) from B_BTFYZXPGXX where  a.qyfwz=qyfwz and sjfwz like '''|| sjqj || '%'' AND ZBBS IN(SELECT ZBBS FROM B_BTFYZXPGSM WHERE XSSX>0 AND MKMC=''GJDZJJXKHJXL'')) WHERE ZBBS=1476 AND SJFWZ LIKE '''||sjqj||'%''' );
    EXECUTE IMMEDIATE (' update B_BTFYZXPGXX a set ZXPGJG=(select sum(round(zbdf,2)) from B_BTFYZXPGXX where  a.qyfwz=qyfwz and sjfwz like '''|| sjqj || '%'' AND ZBBS IN(SELECT ZBBS FROM B_BTFYZXPGSM WHERE XSSX>0 AND MKMC=''GJDZJJXKHJXG'')) WHERE ZBBS=1477 AND SJFWZ LIKE '''||sjqj||'%''' );

 end P_ZXPG_GJDZJJXKH;
/

