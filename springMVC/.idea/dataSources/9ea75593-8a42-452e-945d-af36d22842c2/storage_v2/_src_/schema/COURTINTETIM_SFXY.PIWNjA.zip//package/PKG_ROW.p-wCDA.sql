create package pkg_ROW
as
type myRow is ref cursor;
end;

/

