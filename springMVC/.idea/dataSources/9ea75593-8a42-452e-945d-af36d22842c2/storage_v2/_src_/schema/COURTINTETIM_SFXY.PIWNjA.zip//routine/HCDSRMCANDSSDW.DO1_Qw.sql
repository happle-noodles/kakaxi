create procedure HcDsrMcAndSsDw(nAjbs in number:=16,nKplb in number:=3) as
/*合并当事人名称和当事人诉讼地位 杨元胜*/
/*根据sfbz合并mc  王斌*/
Begin
   UPDATE  B_AJZTXX SET DSRMC= (select max(mc)
        from (SELECT to_char(WMSYS.WM_CONCAT(MC) OVER(order by sfbz)) as mc
                FROM B_YASTML
               WHERE AJBS=nAjbs and js  in(4,6))) WHERE AJBS=nAjbs;
End HcDsrMcAndSsDw;


/

