create PROCEDURE P_TJFX_BTFYZXAJQKTJ(lx varchar2,nscfy varchar2,qsrq varchar2,jsrq varchar2,rt out pkg_row.myRow) as
/*兵团法院执行案件情况统计 杨元胜
nscfy 查询法院
qsrq 起始日期
jsrq 结束日期
rt   返回数据集
*/
v_xstj varchar2(200);
v_yjtj varchar2(200);
v_wjtj varchar2(200);
v_jctj varchar2(200);
v_scfy varchar2(200);
v_kplb varchar2(100);
v_tjs varchar2(200);

begin
   select gsnr into v_xstj  from b_tjfxgs where gsmc='新收A';
   select gsnr into v_yjtj  from b_tjfxgs where gsmc='已结A';
   select gsnr into v_wjtj  from b_tjfxgs where gsmc='未结A';
   select gsnr into v_jctj  from b_tjfxgs where gsmc='旧存A';
   select gsnr into v_tjs  from b_tjfxgs where gsmc='调解数';
   v_xstj :=replace(v_xstj,'＆QsRq＆',qsrq);
   v_xstj :=replace(v_xstj,'＆JsRq＆',jsrq);
   v_yjtj :=replace(v_yjtj,'＆QsRq＆',qsrq);
   v_yjtj :=replace(v_yjtj,'＆JsRq＆',jsrq);
   v_wjtj :=replace(v_wjtj,'＆JsRq＆',jsrq);
   v_jctj :=replace(v_jctj,'＆QsRq＆',qsrq);
   v_scfy :='scfy between 4166 and 4208 ';
   v_kplb :='kplb=16 and ah not like ''%执保%''';

   INSERT INTO B_TEMPTJFX(DM,MC,xssx,kplb,Ajlb) select dm,fyjc,xssx,sjdm,fyjb from b_fy where dm between 4166 and 4208 order by xssx;



   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_xstj ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.XS=B.SL ';--新收数

    execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(qsbdje)/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_xstj ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JCYJ=B.SL ';--新收申请标的金额

  execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_jctj ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JC=B.SL ';--旧存数

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(nvl(qsbdje,0))/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_jctj ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.XSYJ=B.SL ';--旧存标的金额


   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND ('|| v_xstj || 'or '|| v_jctj || ') and nvl(yscdlx,0)=3 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.JCWJ=B.SL ';--调解案件申请执行数

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(nvl(qsbdje,0))/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND ('|| v_xstj || 'or '|| v_jctj || ') and nvl(yscdlx,0)=3 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.WJ=B.SL ';--调解案件申请执行标的

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT count(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND kplb in(7,8,9) AND '|| v_yjtj || ' and '|| v_tjs ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.WJCSX=B.SL ';--民事调解案件


   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJ=B.SL ';--已结数

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(jabdje)/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJYC=B.SL ';--已结标的金额

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||'and jafs=1  and NVL(ZXFS,0) IN(1,3,4,5) group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJCSX=B.SL ';--自动履行

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||'and jafs=1  and NVL(ZXFS,0)=2 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJZZ=B.SL ';--强制执行

    execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' and jafs=1 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.tcs=B.SL ';--已结数执行完毕

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' and jafs=2 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.tjs=B.SL ';--已结数终结本次程序

   execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT COUNT(*) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' and jafs=3 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.css=B.SL ';--已结终结执行

    execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(jabdje)/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' and jafs=1 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.wjyc=B.SL ';--执结金额

    execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(jabdje)/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||' and jafs=2 group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.wjzz=B.SL ';--终本金额

     execute immediate ' merge into B_TEMPTJFX  A
   using(SELECT round(SUM(sjdwje)/10000,2) AS SL,scfy FROM  b_ajztxx  WHERE '||v_scfy||' AND '|| v_kplb||' AND '|| v_yjtj ||'  group by scfy)B
   ON(A.DM=nvl(B.scfy,-2))
   when matched then update set A.YJKT=B.SL ';--实际到位金额

   if lx=1
      then
     update B_TEMPTJFX b set xs=(select sum(xs) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set XSYJ=(select sum(XSYJ) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set JC=(select sum(JC) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set JCYJ=(select sum(JCYJ) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set JCWJ=(select sum(JCWJ) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set WJ=(select sum(WJ) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set WJCSX=(select sum(WJCSX) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;

     update B_TEMPTJFX b set YJ=(select sum(YJ) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set YJYC=(select sum(YJYC) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;

     update B_TEMPTJFX b set YJCSX=(select sum(YJCSX) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set YJZZ=(select sum(YJZZ) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
      update B_TEMPTJFX b set YJKT=(select sum(YJKT) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;

     update B_TEMPTJFX b set tcs=(select sum(tcs) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set tjs=(select sum(tjs) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set css=(select sum(css) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set wjyc=(select sum(wjyc) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     update B_TEMPTJFX b set wjzz=(select sum(wjzz) from B_TEMPTJFX a where b.dm =a.kplb or b.dm=a.dm) where Ajlb=2 ;
     delete B_TEMPTJFX where ajlb=1;
     update B_TEMPTJFX set mc=replace(mc,'中级人民','');
   elsif  lx=2
      then
        delete B_TEMPTJFX where ajlb=1 or ajlb=3;
   elsif lx=3
      then
      delete B_TEMPTJFX where ajlb=2 or ajlb=3;
   elsif lx=4
     then
     delete B_TEMPTJFX where dm<>nscfy and kplb<>nscfy;
   else
     delete B_TEMPTJFX where dm<>nscfy;
    end if;

    insert into B_TEMPTJFX  B_TEMPTJFX(DM,MC,xssx) values(-1,'合计',1000);
     update B_TEMPTJFX b set xs=(select sum(xs) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set XSYJ=(select sum(XSYJ) from B_TEMPTJFX a) where dm=-1 ;
     update B_TEMPTJFX b set JC=(select sum(JC) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set JCYJ=(select sum(JCYJ) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set JCWJ=(select sum(JCWJ) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set WJ=(select sum(WJ) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set WJCSX=(select sum(WJCSX) from B_TEMPTJFX a ) where dm=-1 ;

     update B_TEMPTJFX b set YJ=(select sum(YJ) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set YJYC=(select sum(YJYC) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set YJCSX=(select sum(YJCSX) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set YJZZ=(select sum(YJZZ) from B_TEMPTJFX a ) where dm=-1 ;
      update B_TEMPTJFX b set YJKT=(select sum(YJKT) from B_TEMPTJFX a ) where dm=-1 ;

     update B_TEMPTJFX b set tcs=(select sum(tcs) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set tjs=(select sum(tjs) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set css=(select sum(css) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set wjyc=(select sum(wjyc) from B_TEMPTJFX a ) where dm=-1 ;
     update B_TEMPTJFX b set wjzz=(select sum(wjzz) from B_TEMPTJFX a ) where dm=-1 ;

   update B_TEMPTJFX A SET A.SLS=NVL(A.XS,0)+NVL(A.JC,0);/*受理数*/
   update B_TEMPTJFX A SET A.XSWJ=NVL(A.XSYJ,0)+NVL(A.JCYJ,0);/*受理数标的金额*/
   update B_TEMPTJFX A SET A.hys=NVL(A.yj,0)-NVL(A.tcs,0)-NVL(A.tjs,0)-NVL(A.css,0);/*结案其他方式*/
   update B_TEMPTJFX A SET A.JAL=NVL(A.YJ,0)*100/NVL(A.SLS,0) WHERE SLS>0;/*结案率*/
   update B_TEMPTJFX A SET A.SXBGS=NVL(A.TCS,0);/*受理数标的金额*/
   update B_TEMPTJFX A SET A.XSJAL=NVL(A.SXBGS,0)*100/NVL(A.YJ,0) WHERE YJ>0;/*S实际执结率*/
   update B_TEMPTJFX A SET A.JCJAL=NVL(A.tjs,0)*100/NVL(A.YJ,0) WHERE YJ>0;/*终本率*/
   update B_TEMPTJFX A SET A.WJCSX=(CASE WHEN WJCSX=0 THEN NULL ELSE  round(NVL(A.JCWJ,0)*100/NVL(A.WJCSX,0),2) END);/*调解案件申请执行率*/
   update B_TEMPTJFX A SET A.SXNSJ=round(NVL(A.YJKT,0)*100/NVL(A.XSWJ,0),2) WHERE XSWJ>0;/*终本率*/


    open rt for SELECT  DM,MC,XS,XSYJ,JC,JCYJ,JCWJ,WJ,WJCSX,SLS,XSWJ,YJ,YJYC,YJCSX,YJZZ,YJKT,tcs,tjs,css,hys,JAL,SXBGS,XSJAL,JCJAL,WJYC,WJZZ,SXNSJ  FROM  B_TEMPTJFX order by xssx ;

end P_TJFX_BTFYZXAJQKTJ;
/

